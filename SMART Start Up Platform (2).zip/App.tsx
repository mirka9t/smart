import React, { useEffect } from "react";
import { Router } from "./components/Router";
import { ModalProvider } from "./components/modals/ModalSystem";
import { AuthProvider } from "./contexts/AuthContext";
import { Toaster } from "./components/ui/sonner";
import { telegramBot } from "./utils/telegramBot";
import { notificationSystem } from "./utils/notificationSystem";
import { chatManager } from "./utils/chatUtils";
import { locationTracker } from "./utils/locationTracker";
import { Landing } from "./pages/Landing";
import { Programs } from "./pages/Programs";
import { Curriculum } from "./pages/Curriculum";
import { DeckGenerator } from "./pages/DeckGenerator";
import { RehearsalStudio } from "./pages/RehearsalStudio";
import { Startups } from "./pages/Startups";
import { Mentors } from "./pages/Mentors";
import { Funding } from "./pages/Funding";
import { Resources } from "./pages/Resources";
import { Dashboard } from "./pages/Dashboard";
import { Admin } from "./pages/Admin";
import { Profile } from "./pages/Profile";
import { ProfileSettings } from "./pages/ProfileSettings";
import { MyFavorites } from "./pages/MyFavorites";
import { MyApplications } from "./pages/MyApplications";
import { ChatWithAdmin } from "./pages/ChatWithAdmin";
import { Chat } from "./pages/Chat";
import { CurriculumArticle } from "./pages/CurriculumArticle";

const routes = [
  { path: "/", component: Landing, title: "SMART Start Up" },
  { path: "/programs", component: Programs, title: "Programs" },
  {
    path: "/curriculum",
    component: Curriculum,
    title: "Curriculum",
  },
  {
    path: "/curriculum/article",
    component: CurriculumArticle,
    title: "Article",
  },
  {
    path: "/deck",
    component: DeckGenerator,
    title: "Deck Generator",
    requiresAuth: true,
  },
  {
    path: "/rehearsal",
    component: RehearsalStudio,
    title: "Rehearsal Studio",
    requiresAuth: true,
  },
  { path: "/startups", component: Startups, title: "Startups" },
  { path: "/mentors", component: Mentors, title: "Mentors" },
  { path: "/funding", component: Funding, title: "Funding" },
  {
    path: "/resources",
    component: Resources,
    title: "Resources",
  },
  {
    path: "/dashboard",
    component: Dashboard,
    title: "Dashboard",
    requiresAuth: true,
  },
  {
    path: "/profile",
    component: Profile,
    title: "Profile",
    requiresAuth: true,
  },
  {
    path: "/profile/settings",
    component: ProfileSettings,
    title: "Settings",
    requiresAuth: true,
  },
  {
    path: "/my-favorites",
    component: MyFavorites,
    title: "My Favorites",
    requiresAuth: true,
  },
  {
    path: "/my-applications",
    component: MyApplications,
    title: "My Applications",
    requiresAuth: true,
  },
  {
    path: "/chat-admin",
    component: ChatWithAdmin,
    title: "Chat with Admin",
    requiresAuth: true,
  },
  {
    path: "/chat",
    component: Chat,
    title: "Chat",
    requiresAuth: true,
  },
  {
    path: "/admin",
    component: Admin,
    title: "Admin Panel",
    requiresAuth: true,
    requiresAdmin: true,
  },
];

export default function App() {
  useEffect(() => {
    // Initialize all systems
    const initializeSystems = async () => {
      try {
        console.log(
          "🚀 Initializing SMART Start Up Platform...",
        );

        // Initialize location tracking (non-blocking)
        locationTracker
          .getCurrentLocation()
          .catch(console.error);
        console.log("📍 Location tracking initialized");

        // Initialize chat manager
        chatManager.initialize();
        console.log("💬 Chat system initialized");

        // Initialize notification system
        notificationSystem.test();
        console.log("🔔 Notification system initialized");

        // Verify Telegram integration (non-blocking)
        telegramBot
          .sendTestMessage()
          .then((status) => {
            if (status) {
              console.log(
                "✅ Telegram bot integration verified",
              );
            } else {
              console.warn(
                "⚠️ Telegram bot integration failed - running in offline mode",
              );
            }
          })
          .catch(console.error);

        // Set up real-time features
        setupRealtimeFeatures();

        // Set up automated systems
        setupAutomatedSystems();

        console.log("🎉 All systems initialized successfully!");
      } catch (error) {
        console.error("❌ Error initializing systems:", error);

        // Track initialization error
        const currentUser = JSON.parse(
          localStorage.getItem("smart-user") || "null",
        );
        telegramBot.trackError(
          currentUser,
          "System initialization failed",
          "App initialization",
          { error: error.message },
        );
      }
    };

    // Set up global error handlers
    const handleError = (event: ErrorEvent) => {
      console.error("Global error:", event.error);

      const currentUser = JSON.parse(
        localStorage.getItem("smart-user") || "null",
      );

      telegramBot.trackError(
        currentUser,
        event.error?.message || "Unknown error",
        window.location.pathname,
        {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          userAgent: navigator.userAgent,
        },
      );
    };

    const handleUnhandledRejection = (
      event: PromiseRejectionEvent,
    ) => {
      console.error(
        "Unhandled promise rejection:",
        event.reason,
      );

      const currentUser = JSON.parse(
        localStorage.getItem("smart-user") || "null",
      );

      telegramBot.trackError(
        currentUser,
        event.reason?.message || "Unhandled promise rejection",
        window.location.pathname,
        {
          reason: event.reason,
          userAgent: navigator.userAgent,
        },
      );
    };

    // Set up performance monitoring
    const setupPerformanceMonitoring = () => {
      // Monitor page load performance
      window.addEventListener("load", () => {
        if ("performance" in window) {
          const perfData = performance.getEntriesByType(
            "navigation",
          )[0] as PerformanceNavigationTiming;

          const loadTime =
            perfData.loadEventEnd - perfData.loadEventStart;
          const domContentLoaded =
            perfData.domContentLoadedEventEnd -
            perfData.domContentLoadedEventStart;

          // Track performance if load time is unusually long
          if (loadTime > 3000) {
            const currentUser = JSON.parse(
              localStorage.getItem("smart-user") || "null",
            );
            telegramBot.trackUserAction(
              currentUser
                ? {
                    id: currentUser.id,
                    name: currentUser.name,
                    email: currentUser.email,
                    role: currentUser.role,
                  }
                : {
                    id: "anonymous",
                    name: "Anonymous",
                    email: "anonymous",
                    role: "visitor",
                  },
              "performance_slow_load",
              {
                loadTime: Math.round(loadTime),
                domContentLoaded: Math.round(domContentLoaded),
                page: window.location.pathname,
              },
            );
          }
        }
      });
    };

    // Set up real-time features
    const setupRealtimeFeatures = () => {
      // Set up visibility change tracking
      document.addEventListener("visibilitychange", () => {
        const currentUser = JSON.parse(
          localStorage.getItem("smart-user") || "null",
        );
        if (currentUser) {
          if (document.visibilityState === "visible") {
            // User returned to the page
            chatManager.updateOnlineStatus?.();
          } else {
            // User left the page
            chatManager.setUserAway?.(currentUser.id);
          }
        }
      });

      // Set up beforeunload tracking
      window.addEventListener("beforeunload", () => {
        const currentUser = JSON.parse(
          localStorage.getItem("smart-user") || "null",
        );
        if (currentUser) {
          // Track session end
          const sessionStart = localStorage.getItem(
            "smart-session-start",
          );
          if (sessionStart) {
            const sessionDuration =
              Date.now() - parseInt(sessionStart);
            telegramBot.trackUserAction(
              {
                id: currentUser.id,
                name: currentUser.name,
                email: currentUser.email,
                role: currentUser.role,
              },
              "session_end",
              {
                duration: Math.round(sessionDuration / 1000), // in seconds
                page: window.location.pathname,
              },
            );
          }
        }
      });

      // Track session start
      const currentUser = JSON.parse(
        localStorage.getItem("smart-user") || "null",
      );
      if (
        currentUser &&
        !localStorage.getItem("smart-session-start")
      ) {
        localStorage.setItem(
          "smart-session-start",
          Date.now().toString(),
        );
      }
    };

    // Set up automated systems
    const setupAutomatedSystems = () => {
      // Daily health check
      const lastHealthCheck = localStorage.getItem(
        "smart-last-health-check",
      );
      const today = new Date().toDateString();

      if (lastHealthCheck !== today) {
        setTimeout(async () => {
          try {
            const healthData = await performHealthCheck();
            await telegramBot.sendSystemAlert(
              "Daily Health Check",
              `Platform health: ${healthData.status}. Score: ${healthData.score}%`,
              healthData.status === "critical"
                ? "critical"
                : "low",
            );
            localStorage.setItem(
              "smart-last-health-check",
              today,
            );
          } catch (error) {
            console.error("Health check failed:", error);
          }
        }, 5000); // Delay to avoid startup congestion
      }

      // Automated backup (daily)
      const lastBackup = localStorage.getItem(
        "smart-last-backup",
      );
      const oneDay = 24 * 60 * 60 * 1000;

      if (
        !lastBackup ||
        Date.now() - parseInt(lastBackup) > oneDay
      ) {
        setTimeout(async () => {
          try {
            await createAutomatedBackup();
            localStorage.setItem(
              "smart-last-backup",
              Date.now().toString(),
            );
          } catch (error) {
            console.error("Automated backup failed:", error);
          }
        }, 10000); // Delay to avoid startup congestion
      }

      // Cleanup old data (weekly)
      const lastCleanup = localStorage.getItem(
        "smart-last-cleanup",
      );
      const oneWeek = 7 * 24 * 60 * 60 * 1000;

      if (
        !lastCleanup ||
        Date.now() - parseInt(lastCleanup) > oneWeek
      ) {
        setTimeout(() => {
          try {
            performDataCleanup();
            localStorage.setItem(
              "smart-last-cleanup",
              Date.now().toString(),
            );
          } catch (error) {
            console.error("Data cleanup failed:", error);
          }
        }, 15000); // Delay to avoid startup congestion
      }
    };

    // Health check function
    const performHealthCheck = async () => {
      const checks = [
        {
          name: "Local Storage",
          status: checkLocalStorage(),
          message: "Local storage accessibility",
        },
        {
          name: "Chat System",
          status: typeof chatManager !== "undefined",
          message: "Chat manager availability",
        },
        {
          name: "Notification System",
          status: typeof notificationSystem !== "undefined",
          message: "Notification system availability",
        },
        {
          name: "Telegram Bot",
          status: await telegramBot.sendTestMessage(),
          message: "Telegram integration status",
        },
      ];

      const passedChecks = checks.filter(
        (c) => c.status,
      ).length;
      const score = Math.round(
        (passedChecks / checks.length) * 100,
      );

      let status: "healthy" | "warning" | "critical" =
        "healthy";
      if (score < 50) status = "critical";
      else if (score < 80) status = "warning";

      return { status, checks, score };
    };

    // Automated backup function
    const createAutomatedBackup = async () => {
      try {
        const backupData = {
          users: JSON.parse(
            localStorage.getItem("smart-platform-users") ||
              "[]",
          ),
          chatMessages: JSON.parse(
            localStorage.getItem("smart-chat-messages") || "[]",
          ),
          chatRooms: JSON.parse(
            localStorage.getItem("smart-chat-rooms") || "[]",
          ),
          settings: JSON.parse(
            localStorage.getItem("smart-platform-settings") ||
              "{}",
          ),
          notifications: JSON.parse(
            localStorage.getItem("smart-chat-notifications") ||
              "[]",
          ),
          timestamp: new Date().toISOString(),
          version: "1.0.0",
        };

        localStorage.setItem(
          "smart-automated-backup",
          JSON.stringify(backupData),
        );

        console.log("✅ Automated backup created successfully");
      } catch (error) {
        console.error("❌ Automated backup failed:", error);
        throw error;
      }
    };

    // Data cleanup function
    const performDataCleanup = () => {
      try {
        // Clean old notifications (keep last 1000)
        const notifications = JSON.parse(
          localStorage.getItem("smart-chat-notifications") ||
            "[]",
        );
        if (notifications.length > 1000) {
          const cleaned = notifications.slice(0, 1000);
          localStorage.setItem(
            "smart-chat-notifications",
            JSON.stringify(cleaned),
          );
        }

        // Clean old chat messages (keep last 10000)
        const messages = JSON.parse(
          localStorage.getItem("smart-chat-messages") || "[]",
        );
        if (messages.length > 10000) {
          const cleaned = messages.slice(0, 10000);
          localStorage.setItem(
            "smart-chat-messages",
            JSON.stringify(cleaned),
          );
        }

        // Clean old user actions (keep last 5000)
        const actions = JSON.parse(
          localStorage.getItem("smart-user-actions") || "[]",
        );
        if (actions.length > 5000) {
          const cleaned = actions.slice(0, 5000);
          localStorage.setItem(
            "smart-user-actions",
            JSON.stringify(cleaned),
          );
        }

        console.log("✅ Data cleanup completed successfully");
      } catch (error) {
        console.error("❌ Data cleanup failed:", error);
      }
    };

    // Helper function to check local storage
    const checkLocalStorage = () => {
      try {
        const test = "__test__";
        localStorage.setItem(test, test);
        localStorage.removeItem(test);
        return true;
      } catch {
        return false;
      }
    };

    // Initialize everything
    initializeSystems();
    setupPerformanceMonitoring();

    // Set up error listeners
    window.addEventListener("error", handleError);
    window.addEventListener(
      "unhandledrejection",
      handleUnhandledRejection,
    );

    // Cleanup
    return () => {
      window.removeEventListener("error", handleError);
      window.removeEventListener(
        "unhandledrejection",
        handleUnhandledRejection,
      );
    };
  }, []);

  return (
    <AuthProvider>
      <ModalProvider>
        <Router routes={routes}>
          <Toaster
            position="top-right"
            expand={true}
            richColors={true}
            closeButton={true}
            toastOptions={{
              style: {
                background: "var(--background)",
                border: "1px solid var(--border)",
                color: "var(--foreground)",
              },
              className: "text-sm",
              duration: 4000,
            }}
          />
        </Router>
      </ModalProvider>
    </AuthProvider>
  );
}