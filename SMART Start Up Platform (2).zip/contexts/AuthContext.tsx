import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { notifications } from '../utils/notifications';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin' | 'moderator';
  avatar?: string;
  bio?: string;
  university?: string;
  major?: string;
  graduationYear?: string;
  linkedinUrl?: string;
  interests?: string[];
  skills?: string[];
  startupExperience?: string;
  profileCompleteness: number;
  createdAt: string;
  lastLogin: string;
  location?: {
    country?: string;
    city?: string;
    region?: string;
    timezone?: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  deviceInfo?: {
    browser?: string;
    os?: string;
    device?: string;
    screen?: string;
  };
  sessionInfo?: {
    ipAddress?: string;
    userAgent?: string;
    sessionId?: string;
    loginCount?: number;
  };
  preferences: {
    notifications: boolean;
    emailUpdates: boolean;
    publicProfile: boolean;
    dataTracking: boolean;
    theme: 'light' | 'dark' | 'auto';
    language: string;
    timezone: string;
  };
  stats: {
    applicationsSubmitted: number;
    mentoringSessions: number;
    resourcesDownloaded: number;
    certificatesEarned: number;
    chatMessages: number;
    projectsCreated: number;
    eventsAttended: number;
  };
  security: {
    lastPasswordChange?: string;
    twoFactorEnabled: boolean;
    loginAttempts: number;
    accountLocked: boolean;
    lockUntil?: string;
  };
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  updatePreferences: (preferences: Partial<User['preferences']>) => void;
  updateStats: (stats: Partial<User['stats']>) => void;
  trackAction: (action: string, details?: any) => void;
  loading: boolean;
  allUsers: User[];
  refreshUsers: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Enhanced user database with comprehensive tracking
const STORAGE_KEYS = {
  USERS: 'smart-platform-users',
  SESSIONS: 'smart-user-sessions',
  ACTIONS: 'smart-user-actions'
};

// Admin credentials as specified
const ADMIN_CREDENTIALS = {
  email: 'admin2025@gmail.com',
  password: 'admin2025@)@%'
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [allUsers, setAllUsers] = useState<User[]>([]);

  // Debug mode for development
  const DEBUG_MODE = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

  // Initialize auth state and load all users
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        // Load users first (non-blocking)
        loadAllUsers();
        
        const savedUser = localStorage.getItem('smart-user');
        const savedSession = localStorage.getItem('smart-session');
        
        if (savedUser && savedSession) {
          try {
            const userData = JSON.parse(savedUser);
            const sessionData = JSON.parse(savedSession);
            
            // Check if session is still valid (24 hours)
            const sessionAge = Date.now() - sessionData.timestamp;
            if (sessionAge < 24 * 60 * 60 * 1000) {
              setUser(userData);
              // Update session in background (non-blocking)
              updateUserSession(userData).catch(console.error);
            } else {
              // Session expired
              localStorage.removeItem('smart-user');
              localStorage.removeItem('smart-session');
            }
          } catch (parseError) {
            console.error('Error parsing saved user data:', parseError);
            localStorage.removeItem('smart-user');
            localStorage.removeItem('smart-session');
          }
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const loadAllUsers = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.USERS) || '[]';
      const users = JSON.parse(stored);
      setAllUsers(users);
    } catch (error) {
      console.error('Error loading users:', error);
      setAllUsers([]);
    }
  };

  const refreshUsers = () => {
    loadAllUsers();
  };

  const updateUserSession = async (userData: User) => {
    try {
      const updatedUser = {
        ...userData,
        lastLogin: new Date().toISOString(),
        sessionInfo: {
          ...userData.sessionInfo,
          sessionId: `session-${Date.now()}`,
          loginCount: (userData.sessionInfo?.loginCount || 0) + 1
        }
      };

      setUser(updatedUser);
      localStorage.setItem('smart-user', JSON.stringify(updatedUser));
      
      // Update in users database
      await updateUserInDatabase(updatedUser);
    } catch (error) {
      console.error('Error updating user session:', error);
    }
  };

  const updateUserInDatabase = async (userData: User) => {
    try {
      const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      const userIndex = users.findIndex((u: User) => u.id === userData.id);
      
      if (userIndex >= 0) {
        users[userIndex] = userData;
      } else {
        users.push(userData);
      }
      
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      setAllUsers(users);
    } catch (error) {
      console.error('Error updating user in database:', error);
      // Don't throw - this is a background operation
    }
  };

  const trackAction = async (action: string, details: any = {}) => {
    if (!user) return;

    try {
      const actionRecord = {
        id: `action-${Date.now()}`,
        userId: user.id,
        userEmail: user.email,
        action,
        details,
        timestamp: new Date().toISOString(),
        location: user.location,
        deviceInfo: user.deviceInfo,
        sessionId: user.sessionInfo?.sessionId,
        page: window.location.pathname
      };

      // Store action locally (non-blocking)
      setTimeout(() => {
        try {
          const actions = JSON.parse(localStorage.getItem(STORAGE_KEYS.ACTIONS) || '[]');
          actions.unshift(actionRecord);
          // Keep only last 5000 actions for performance
          if (actions.length > 5000) {
            actions.splice(5000);
          }
          localStorage.setItem(STORAGE_KEYS.ACTIONS, JSON.stringify(actions));
        } catch (storageError) {
          console.error('Error storing action:', storageError);
        }
      }, 0);

      // Send to Telegram for important actions (non-blocking)
      const importantActions = [
        'user_signup', 'user_login', 'admin_login', 'user_logout'
      ];

      if (importantActions.includes(action)) {
        setTimeout(() => {
          telegramBot.trackUserAction(
            formatUserForTelegram(user),
            action,
            details
          ).catch(console.error);
        }, 0);
      }
    } catch (error) {
      console.error('Error tracking action:', error);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setLoading(true);
    
    try {
      if (DEBUG_MODE) console.log('🔑 Login attempt:', { email, passwordLength: password.length });
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Check admin credentials
      if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
        const adminUser: User = {
          id: 'admin-1',
          email: 'admin2025@gmail.com',
          name: 'SMART Admin',
          role: 'admin',
          profileCompleteness: 100,
          createdAt: '2024-01-01T00:00:00Z',
          lastLogin: new Date().toISOString(),
          location: { country: 'Unknown', city: 'Unknown', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
          deviceInfo: { browser: 'Unknown', os: 'Unknown', device: 'Unknown' },
          sessionInfo: {
            ipAddress: '0.0.0.0',
            userAgent: navigator.userAgent,
            sessionId: `session-${Date.now()}`,
            loginCount: 1
          },
          preferences: {
            notifications: true,
            emailUpdates: true,
            publicProfile: false,
            dataTracking: false,
            theme: 'light',
            language: 'en',
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
          },
          stats: {
            applicationsSubmitted: 0,
            mentoringSessions: 0,
            resourcesDownloaded: 0,
            certificatesEarned: 0,
            chatMessages: 0,
            projectsCreated: 0,
            eventsAttended: 0
          },
          security: {
            twoFactorEnabled: false,
            loginAttempts: 0,
            accountLocked: false
          }
        };
        
        setUser(adminUser);
        localStorage.setItem('smart-user', JSON.stringify(adminUser));
        localStorage.setItem('smart-session', JSON.stringify({ timestamp: Date.now() }));
        
        // Update users database
        await updateUserInDatabase(adminUser);
        
        notifications.success('Welcome back, Admin!', 'You have been successfully logged in.');
        return true;
      }

      // Check demo user
      if (email === 'test@example.com' && password === 'password123') {
        const demoUser: User = {
          id: 'demo-user-1',
          email: 'test@example.com',
          name: 'Demo User',
          role: 'user',
          profileCompleteness: 50,
          createdAt: '2024-01-01T00:00:00Z',
          lastLogin: new Date().toISOString(),
          location: { country: 'Demo', city: 'Demo City', timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
          deviceInfo: { browser: 'Demo Browser', os: 'Demo OS', device: 'Demo Device' },
          sessionInfo: {
            ipAddress: '127.0.0.1',
            userAgent: navigator.userAgent,
            sessionId: `session-${Date.now()}`,
            loginCount: 1
          },
          preferences: {
            notifications: true,
            emailUpdates: true,
            publicProfile: true,
            dataTracking: true,
            theme: 'light',
            language: 'en',
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
          },
          stats: {
            applicationsSubmitted: 5,
            mentoringSessions: 2,
            resourcesDownloaded: 10,
            certificatesEarned: 1,
            chatMessages: 25,
            projectsCreated: 3,
            eventsAttended: 4
          },
          security: {
            twoFactorEnabled: false,
            loginAttempts: 0,
            accountLocked: false
          }
        };
        
        setUser(demoUser);
        localStorage.setItem('smart-user', JSON.stringify(demoUser));
        localStorage.setItem('smart-session', JSON.stringify({ timestamp: Date.now() }));
        
        await updateUserInDatabase(demoUser);
        
        notifications.success('Welcome back!', 'You have been successfully logged in.');
        return true;
      }
      
      // Check regular user credentials in database
      const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      const userData = users.find((u: User & { password: string }) => 
        u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );
      
      if (userData) {
        const { password: _, ...userWithoutPassword } = userData;
        const updatedUser = {
          ...userWithoutPassword,
          lastLogin: new Date().toISOString(),
          sessionInfo: {
            ...userWithoutPassword.sessionInfo,
            sessionId: `session-${Date.now()}`,
            loginCount: (userWithoutPassword.sessionInfo?.loginCount || 0) + 1
          }
        };
        
        setUser(updatedUser);
        localStorage.setItem('smart-user', JSON.stringify(updatedUser));
        localStorage.setItem('smart-session', JSON.stringify({ timestamp: Date.now() }));
        
        // Update in database
        await updateUserInDatabase(updatedUser);
        
        notifications.success('Welcome back!', 'You have been successfully logged in.');
        return true;
      }
      
      notifications.error('Login failed', 'Invalid email or password.');
      return false;
      
    } catch (error) {
      console.error('Login error:', error);
      notifications.error('Login failed', 'An error occurred during login.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string): Promise<boolean> => {
    setLoading(true);
    
    try {
      if (DEBUG_MODE) console.log('✏️ Signup attempt:', { email, name, passwordLength: password.length });
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check if user already exists
      const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
      if (users.find((u: User) => u.email.toLowerCase() === email.toLowerCase())) {
        notifications.error('Signup failed', 'An account with this email already exists.');
        return false;
      }
      
      // Create new user
      const newUser: User = {
        id: `user-${Date.now()}`,
        email: email.toLowerCase(),
        name,
        role: 'user',
        profileCompleteness: 30,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        location: { 
          country: 'New User', 
          city: 'Welcome City', 
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone 
        },
        deviceInfo: { 
          browser: 'New Browser', 
          os: 'New OS', 
          device: 'New Device' 
        },
        sessionInfo: {
          ipAddress: '0.0.0.0',
          userAgent: navigator.userAgent,
          sessionId: `session-${Date.now()}`,
          loginCount: 1
        },
        preferences: {
          notifications: true,
          emailUpdates: true,
          publicProfile: true,
          dataTracking: true,
          theme: 'light',
          language: 'en',
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
        },
        stats: {
          applicationsSubmitted: 0,
          mentoringSessions: 0,
          resourcesDownloaded: 0,
          certificatesEarned: 0,
          chatMessages: 0,
          projectsCreated: 0,
          eventsAttended: 0
        },
        security: {
          twoFactorEnabled: false,
          loginAttempts: 0,
          accountLocked: false
        }
      };
      
      try {
        // Store with password in database
        const userWithPassword = { ...newUser, password };
        users.push(userWithPassword);
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
        
        setUser(newUser);
        setAllUsers(users);
        localStorage.setItem('smart-user', JSON.stringify(newUser));
        localStorage.setItem('smart-session', JSON.stringify({ timestamp: Date.now() }));
        
        notifications.success('Account created!', 'Welcome to SMART Start Up! Your account has been created successfully.');
        return true;
      } catch (storageError) {
        console.error('Error storing user data:', storageError);
        notifications.error('Storage Error', 'Failed to save your account. Please try again.');
        return false;
      }
      
    } catch (error) {
      console.error('Signup error:', error);
      notifications.error('Signup failed', 'An error occurred during signup.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    if (user) {
      // Track user logout before clearing user data
      await trackAction('user_logout', {
        sessionDuration: Date.now() - new Date(user.lastLogin).getTime()
      });
    }
    
    setUser(null);
    localStorage.removeItem('smart-user');
    localStorage.removeItem('smart-session');
    notifications.info('Logged out', 'You have been logged out successfully.');
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...data };
    
    // Calculate profile completeness
    const fields = [
      updatedUser.name,
      updatedUser.bio,
      updatedUser.university,
      updatedUser.major,
      updatedUser.graduationYear,
      updatedUser.linkedinUrl,
      updatedUser.interests?.length,
      updatedUser.skills?.length,
      updatedUser.startupExperience
    ];
    
    const completedFields = fields.filter(field => field && (Array.isArray(field) ? field.length > 0 : true)).length;
    updatedUser.profileCompleteness = Math.round((completedFields / fields.length) * 100);
    
    setUser(updatedUser);
    localStorage.setItem('smart-user', JSON.stringify(updatedUser));
    
    // Update in database
    await updateUserInDatabase(updatedUser);
    
    // Track profile update
    await trackAction('profile_update', {
      updatedFields: Object.keys(data),
      completeness: updatedUser.profileCompleteness
    });
    
    notifications.success('Profile updated!', 'Your changes have been saved.');
  };

  const updatePreferences = async (preferences: Partial<User['preferences']>) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      preferences: { ...user.preferences, ...preferences }
    };
    
    setUser(updatedUser);
    localStorage.setItem('smart-user', JSON.stringify(updatedUser));
    
    // Update in database
    await updateUserInDatabase(updatedUser);
    
    // Track preferences update
    await trackAction('preferences_update', {
      updatedPreferences: Object.keys(preferences)
    });
    
    notifications.success('Preferences updated!', 'Your settings have been saved.');
  };

  const updateStats = async (stats: Partial<User['stats']>) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      stats: { ...user.stats, ...stats }
    };
    
    setUser(updatedUser);
    localStorage.setItem('smart-user', JSON.stringify(updatedUser));
    
    // Update in database
    await updateUserInDatabase(updatedUser);
  };

  // Memoize the context value
  const contextValue: AuthContextType = React.useMemo(() => ({
    user,
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
    login,
    signup,
    logout,
    updateProfile,
    updatePreferences,
    updateStats,
    trackAction,
    loading,
    allUsers,
    refreshUsers
  }), [user, loading, allUsers]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}