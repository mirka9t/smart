// localStorage utilities for SMART platform
import { telegramBot, formatUserForTelegram } from './telegramBot';

export interface UserProgress {
  modules: Record<string, boolean>;
  lastAccessed: string;
}

export interface DeckData {
  slides: Record<string, {
    headline: string;
    keyPoints: string[];
    metrics?: Record<string, string>;
    notes?: string;
  }>;
  enhancers: Record<string, boolean>;
  lastModified: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  team: string[];
  stage: 'idea' | 'mvp' | 'scaling';
  links: string[];
  currentMilestone: string;
  deckId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RehearsalLog {
  id: string;
  date: string;
  duration: number;
  mode: '5min' | '7min' | '10min';
  notes: string;
  questions: Array<{
    question: string;
    notes: string;
  }>;
}

export interface Application {
  id: string;
  type: 'program' | 'funding';
  programId?: string;
  fundingId?: string;
  data: Record<string, any>;
  submittedAt: string;
  status: 'submitted' | 'pending' | 'accepted' | 'rejected';
}

export interface UserData {
  visitorId: string;
  profile: {
    name?: string;
    email?: string;
    school?: string;
  };
  progress: UserProgress;
  deck: DeckData;
  projects: Project[];
  rehearsals: RehearsalLog[];
  applications: Application[];
  favorites: {
    startups: string[];
    mentors: string[];
  };
  notes: Array<{
    id: string;
    content: string;
    completed: boolean;
    createdAt: string;
  }>;
}

const STORAGE_PREFIX = 'smart.';

// Generate a simple UUID
function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Initialize user data structure
function initializeUserData(): UserData {
  const visitorId = generateId();
  return {
    visitorId,
    profile: {},
    progress: {
      modules: {},
      lastAccessed: new Date().toISOString(),
    },
    deck: {
      slides: {},
      enhancers: {},
      lastModified: new Date().toISOString(),
    },
    projects: [],
    rehearsals: [],
    applications: [],
    favorites: {
      startups: [],
      mentors: [],
    },
    notes: [],
  };
}

// Get user data from localStorage
export function getUserData(): UserData {
  try {
    const stored = localStorage.getItem(`${STORAGE_PREFIX}user`);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.warn('Failed to load user data from localStorage:', error);
  }
  
  // Initialize new user data
  const userData = initializeUserData();
  saveUserData(userData);
  return userData;
}

// Save user data to localStorage
export function saveUserData(userData: UserData): void {
  try {
    localStorage.setItem(`${STORAGE_PREFIX}user`, JSON.stringify(userData));
  } catch (error) {
    console.error('Failed to save user data to localStorage:', error);
  }
}

// Update specific parts of user data
export function updateUserData<K extends keyof UserData>(
  key: K,
  value: UserData[K]
): void {
  const userData = getUserData();
  userData[key] = value;
  saveUserData(userData);
}

// Curriculum progress utilities
export function markModuleComplete(moduleId: string): void {
  const userData = getUserData();
  userData.progress.modules[moduleId] = true;
  userData.progress.lastAccessed = new Date().toISOString();
  saveUserData(userData);
}

export function isModuleComplete(moduleId: string): boolean {
  const userData = getUserData();
  return userData.progress.modules[moduleId] || false;
}

export function getProgressPercentage(): number {
  const userData = getUserData();
  const totalModules = 8; // M1-M8
  const completedModules = Object.values(userData.progress.modules).filter(Boolean).length;
  return Math.round((completedModules / totalModules) * 100);
}

// Deck utilities
export function saveDeckSlide(slideId: string, data: DeckData['slides'][string]): void {
  const userData = getUserData();
  userData.deck.slides[slideId] = data;
  userData.deck.lastModified = new Date().toISOString();
  saveUserData(userData);
}

export function toggleDeckEnhancer(enhancer: string, enabled: boolean): void {
  const userData = getUserData();
  userData.deck.enhancers[enhancer] = enabled;
  userData.deck.lastModified = new Date().toISOString();
  saveUserData(userData);
}

// Project utilities
export function createProject(project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Project {
  const newProject: Project = {
    ...project,
    id: generateId(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  
  const userData = getUserData();
  userData.projects.push(newProject);
  saveUserData(userData);
  
  return newProject;
}

export function updateProject(projectId: string, updates: Partial<Project>): void {
  const userData = getUserData();
  const projectIndex = userData.projects.findIndex(p => p.id === projectId);
  if (projectIndex !== -1) {
    userData.projects[projectIndex] = {
      ...userData.projects[projectIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    saveUserData(userData);
  }
}

// Rehearsal utilities
export function saveRehearsalLog(log: Omit<RehearsalLog, 'id'>): void {
  const userData = getUserData();
  const newLog: RehearsalLog = {
    ...log,
    id: generateId(),
  };
  userData.rehearsals.push(newLog);
  saveUserData(userData);
}

// Application utilities
export function submitApplication(application: Omit<Application, 'id' | 'submittedAt' | 'status'>): void {
  const userData = getUserData();
  const newApplication: Application = {
    ...application,
    id: generateId(),
    submittedAt: new Date().toISOString(),
    status: 'submitted',
  };
  userData.applications.push(newApplication);
  saveUserData(userData);
}

// Favorites utilities
export function toggleFavorite(type: 'startups' | 'mentors', id: string): boolean {
  const userData = getUserData();
  const favorites = userData.favorites[type];
  const index = favorites.indexOf(id);
  
  if (index === -1) {
    favorites.push(id);
    saveUserData(userData);
    return true;
  } else {
    favorites.splice(index, 1);
    saveUserData(userData);
    return false;
  }
}

export function isFavorite(type: 'startups' | 'mentors', id: string): boolean {
  const userData = getUserData();
  return userData.favorites[type].includes(id);
}

// Notes utilities
export function addNote(content: string): void {
  const userData = getUserData();
  userData.notes.push({
    id: generateId(),
    content,
    completed: false,
    createdAt: new Date().toISOString(),
  });
  saveUserData(userData);
}

export function toggleNote(noteId: string): void {
  const userData = getUserData();
  const note = userData.notes.find(n => n.id === noteId);
  if (note) {
    note.completed = !note.completed;
    saveUserData(userData);
  }
}

export function deleteNote(noteId: string): void {
  const userData = getUserData();
  const index = userData.notes.findIndex(n => n.id === noteId);
  if (index !== -1) {
    userData.notes.splice(index, 1);
    saveUserData(userData);
  }
}

// Data export utilities
export function exportUserData(): string {
  const userData = getUserData();
  return JSON.stringify(userData, null, 2);
}

export function clearAllData(): void {
  Object.keys(localStorage).forEach(key => {
    if (key.startsWith(STORAGE_PREFIX)) {
      localStorage.removeItem(key);
    }
  });
}