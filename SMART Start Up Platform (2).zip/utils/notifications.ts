import { toast } from 'sonner@2.0.3';

type NotificationType = 'success' | 'error' | 'info' | 'warning';

interface NotificationOptions {
  duration?: number;
  description?: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

class NotificationManager {
  private lastNotifications = new Map<string, number>();
  private readonly DEBOUNCE_TIME = 3000; // 3 seconds

  private shouldShowNotification(type: string, message: string): boolean {
    const key = `${type}-${message}`;
    const now = Date.now();
    const lastShown = this.lastNotifications.get(key);
    
    if (lastShown && now - lastShown < this.DEBOUNCE_TIME) {
      return false;
    }
    
    this.lastNotifications.set(key, now);
    return true;
  }

  success(title: string, description?: string, options?: NotificationOptions) {
    if (!this.shouldShowNotification('success', title)) return;
    
    toast.success(title, {
      description: description || options?.description,
      duration: options?.duration || 4000,
      action: options?.action ? {
        label: options.action.label,
        onClick: options.action.onClick,
      } : undefined,
    });
  }

  error(title: string, description?: string, options?: NotificationOptions) {
    if (!this.shouldShowNotification('error', title)) return;
    
    toast.error(title, {
      description: description || options?.description,
      duration: options?.duration || 6000,
      action: options?.action ? {
        label: options.action.label,
        onClick: options.action.onClick,
      } : undefined,
    });
  }

  info(title: string, description?: string, options?: NotificationOptions) {
    // Only show info notifications for important messages
    if (title === 'Demo Mode' && !this.shouldShowNotification('info', title)) return;
    
    toast.info(title, {
      description: description || options?.description,
      duration: options?.duration || 3000,
      action: options?.action ? {
        label: options.action.label,
        onClick: options.action.onClick,
      } : undefined,
    });
  }

  warning(title: string, description?: string, options?: NotificationOptions) {
    if (!this.shouldShowNotification('warning', title)) return;
    
    toast.warning(title, {
      description: description || options?.description,
      duration: options?.duration || 5000,
      action: options?.action ? {
        label: options.action.label,
        onClick: options.action.onClick,
      } : undefined,
    });
  }

  // Convenience methods for common use cases
  applicationSubmitted(programName: string) {
    this.success(
      'Application Submitted!',
      `Your application to ${programName} has been submitted successfully.`,
      { duration: 5000 }
    );
  }

  mentorBooked(mentorName: string) {
    this.success(
      'Session Booked!',
      `Your mentoring session with ${mentorName} has been scheduled.`,
      { duration: 5000 }
    );
  }

  resourceDownloaded(resourceName: string) {
    this.success(
      'Download Started',
      `${resourceName} is being downloaded.`,
      { duration: 3000 }
    );
  }

  formSaved() {
    this.success(
      'Progress Saved',
      'Your form has been automatically saved.',
      { duration: 2000 }
    );
  }

  networkError() {
    this.error(
      'Connection Error',
      'Please check your internet connection and try again.',
      { 
        duration: 6000,
        action: {
          label: 'Retry',
          onClick: () => window.location.reload()
        }
      }
    );
  }
}

export const notifications = new NotificationManager();

// Backward compatibility for existing code
export const showSuccess = (title: string, description?: string) => {
  notifications.success(title, description);
};

export const showError = (title: string, description?: string) => {
  notifications.error(title, description);
};

export const showInfo = (title: string, description?: string) => {
  notifications.info(title, description);
};

export const showWarning = (title: string, description?: string) => {
  notifications.warning(title, description);
};

// Specific notification functions for different pages
export const fundingNotifications = {
  applicationStarted: (programName: string) => {
    notifications.success(
      'Application Started',
      `You've started your application for ${programName}. Your progress is automatically saved.`
    );
  },
  
  applied: (programName: string) => {
    notifications.success(
      'Application Submitted!',
      `Your application to ${programName} has been submitted successfully. You'll receive updates via email.`
    );
  },
  
  deadlineReminder: (programName: string, daysLeft: number) => {
    notifications.warning(
      'Application Deadline Approaching',
      `${programName} deadline is in ${daysLeft} days. Don't miss out!`
    );
  },
  
  eligibilityCheck: (programName: string, eligible: boolean) => {
    if (eligible) {
      notifications.success(
        'You\'re Eligible!',
        `Great news! You meet the requirements for ${programName}.`
      );
    } else {
      notifications.warning(
        'Check Requirements',
        `Please review the eligibility requirements for ${programName}.`
      );
    }
  },
  
  bookmarked: (programName: string) => {
    notifications.success(
      'Added to Favorites',
      `${programName} has been saved to your favorites.`
    );
  }
};

export const resourceNotifications = {
  downloaded: (resourceName: string) => {
    notifications.success(
      'Download Started',
      `${resourceName} is being downloaded to your device.`
    );
  },
  
  accessed: (resourceName: string) => {
    notifications.info(
      'Resource Accessed',
      `Opening ${resourceName}...`
    );
  },
  
  bookmarked: (resourceName: string) => {
    notifications.success(
      'Resource Bookmarked',
      `${resourceName} has been added to your bookmarks.`
    );
  },
  
  shared: (resourceName: string) => {
    notifications.success(
      'Resource Shared',
      `${resourceName} link has been copied to your clipboard.`
    );
  },
  
  accessDenied: () => {
    notifications.error(
      'Access Required',
      'Please sign in to download resources and track your progress.'
    );
  }
};

export const mentorNotifications = {
  booked: (mentorName: string) => {
    notifications.success(
      'Session Booked!',
      `Your mentoring session with ${mentorName} has been scheduled. Check your email for details.`
    );
  },
  
  contacted: (mentorName: string) => {
    notifications.success(
      'Message Sent',
      `Your message has been sent to ${mentorName}. They'll respond within 24 hours.`
    );
  },
  
  applied: () => {
    notifications.success(
      'Application Submitted',
      'Your mentor application has been submitted. We\'ll review it within 5 business days.'
    );
  },
  
  sessionCancelled: (mentorName: string) => {
    notifications.info(
      'Session Cancelled',
      `Your session with ${mentorName} has been cancelled. You can reschedule anytime.`
    );
  },
  
  sessionReminder: (mentorName: string, timeLeft: string) => {
    notifications.info(
      'Session Reminder',
      `Your mentoring session with ${mentorName} starts in ${timeLeft}.`
    );
  },
  
  profileViewed: (mentorName: string) => {
    notifications.info(
      'Mentor Profile',
      `Viewing ${mentorName}'s profile and availability.`
    );
  },
  
  availabilityCheck: (mentorName: string, available: boolean) => {
    if (available) {
      notifications.success(
        'Mentor Available',
        `${mentorName} has open slots this week. Book now!`
      );
    } else {
      notifications.warning(
        'Limited Availability',
        `${mentorName} is currently booked. Check back next week or join the waitlist.`
      );
    }
  }
};

export const generalNotifications = {
  welcome: (userName: string) => {
    notifications.success(
      `Welcome, ${userName}!`,
      'You\'ve successfully joined SMART Start Up. Let\'s get started!'
    );
  },
  
  profileIncomplete: (completionPercentage: number) => {
    notifications.warning(
      'Complete Your Profile',
      `Your profile is ${completionPercentage}% complete. Finish it to unlock all features.`
    );
  },
  
  featureUnlocked: (featureName: string) => {
    notifications.success(
      'New Feature Unlocked!',
      `You now have access to ${featureName}. Check it out!`
    );
  },
  
  maintenanceMode: () => {
    notifications.warning(
      'Scheduled Maintenance',
      'The platform will be under maintenance tonight from 2-4 AM EST.'
    );
  },
  
  offlineMode: () => {
    notifications.error(
      'Connection Lost',
      'You\'re currently offline. Some features may be limited.'
    );
  },
  
  dataSync: () => {
    notifications.info(
      'Data Synced',
      'Your data has been synchronized successfully.'
    );
  },
  
  sessionExpiring: (minutesLeft: number) => {
    notifications.warning(
      'Session Expiring',
      `Your session will expire in ${minutesLeft} minutes. Save your work!`
    );
  },
  
  error: (type: string) => {
    notifications.error(
      'Error Loading Data',
      `Failed to load ${type}. Using demo data instead.`
    );
  }
};

// Program-specific notifications
export const programNotifications = {
  applicationDeadline: (programName: string, daysLeft: number) => {
    const urgency = daysLeft <= 3 ? 'error' : daysLeft <= 7 ? 'warning' : 'info';
    const message = daysLeft === 1 ? 'Tomorrow is the last day!' : `${daysLeft} days remaining.`;
    
    notifications[urgency](
      `${programName} Deadline`,
      message
    );
  },
  
  statusUpdate: (programName: string, status: string) => {
    const statusMessages = {
      'accepted': 'Congratulations! Your application has been accepted.',
      'rejected': 'Unfortunately, your application was not selected this time.',
      'waitlisted': 'You\'ve been placed on the waitlist. We\'ll notify you of any updates.',
      'interview': 'You\'ve been selected for an interview! Check your email for details.'
    };
    
    const type = status === 'accepted' ? 'success' : 
                 status === 'rejected' ? 'error' : 'info';
    
    notifications[type](
      `${programName} Update`,
      statusMessages[status as keyof typeof statusMessages] || `Status updated to: ${status}`
    );
  }
};

// Analytics and tracking notifications
export const analyticsNotifications = {
  milestoneReached: (milestone: string) => {
    notifications.success(
      'Milestone Achieved!',
      `Congratulations! You've reached: ${milestone}`
    );
  },
  
  weeklyReport: (stats: { applications: number; sessions: number; resources: number }) => {
    notifications.info(
      'Weekly Summary',
      `This week: ${stats.applications} applications, ${stats.sessions} sessions, ${stats.resources} resources downloaded.`
    );
  }
};