import { chatManager, type NotificationData } from './chatUtils';
import { notifications } from './notifications';

interface SystemNotification extends NotificationData {
  persistent?: boolean;
  autoHide?: boolean;
  hideAfter?: number;
  actions?: {
    label: string;
    action: () => void;
    style?: 'primary' | 'secondary' | 'destructive';
  }[];
}

interface NotificationSettings {
  enabled: boolean;
  sounds: boolean;
  desktop: boolean;
  inApp: boolean;
  email: boolean;
  categories: {
    chat: boolean;
    system: boolean;
    admin: boolean;
    security: boolean;
    updates: boolean;
  };
}

class NotificationSystem {
  private callbacks: ((notification: SystemNotification) => void)[] = [];
  private activeNotifications: Map<string, SystemNotification> = new Map();
  private settings: NotificationSettings = {
    enabled: true,
    sounds: true,
    desktop: true,
    inApp: true,
    email: false,
    categories: {
      chat: true,
      system: true,
      admin: true,
      security: true,
      updates: true
    }
  };
  private soundEnabled = true;
  private permission: NotificationPermission = 'default';

  constructor() {
    this.initialize();
  }

  /**
   * Initialize the notification system
   */
  private async initialize(): Promise<void> {
    try {
      // Load settings
      this.loadSettings();

      // Request permission for desktop notifications
      if ('Notification' in window) {
        this.permission = await Notification.requestPermission();
      }

      // Subscribe to chat notifications
      chatManager.onNewNotification((notification) => {
        this.handleChatNotification(notification);
      });

      // Listen for chat messages
      chatManager.onNewMessage((message) => {
        if (message.fromUserId !== this.getCurrentUserId()) {
          this.showChatMessageNotification(message);
        }
      });

      // Set up periodic cleanup
      setInterval(() => {
        this.cleanupExpiredNotifications();
      }, 30000); // Every 30 seconds

    } catch (error) {
      console.error('Error initializing notification system:', error);
    }
  }

  /**
   * Show a notification
   */
  show(notification: Partial<SystemNotification>): string {
    const id = notification.id || `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const fullNotification: SystemNotification = {
      id,
      type: notification.type || 'system',
      title: notification.title || 'Notification',
      message: notification.message || '',
      timestamp: new Date().toISOString(),
      isRead: false,
      priority: notification.priority || 'medium',
      persistent: notification.persistent || false,
      autoHide: notification.autoHide !== false,
      hideAfter: notification.hideAfter || 5000,
      actions: notification.actions || [],
      ...notification
    };

    // Check if category is enabled
    if (!this.isCategoryEnabled(fullNotification.type)) {
      return id;
    }

    // Store notification
    this.activeNotifications.set(id, fullNotification);

    // Show desktop notification
    if (this.settings.desktop && this.permission === 'granted') {
      this.showDesktopNotification(fullNotification);
    }

    // Show in-app notification
    if (this.settings.inApp) {
      this.showInAppNotification(fullNotification);
    }

    // Play sound
    if (this.settings.sounds && this.soundEnabled) {
      this.playNotificationSound(fullNotification.priority);
    }

    // Trigger callbacks
    this.callbacks.forEach(callback => callback(fullNotification));

    // Auto-hide if configured
    if (fullNotification.autoHide && !fullNotification.persistent) {
      setTimeout(() => {
        this.hide(id);
      }, fullNotification.hideAfter);
    }

    return id;
  }

  /**
   * Hide a notification
   */
  hide(id: string): void {
    this.activeNotifications.delete(id);
    // Trigger update for UI components
    this.callbacks.forEach(callback => callback({ id } as SystemNotification));
  }

  /**
   * Mark notification as read
   */
  markAsRead(id: string): void {
    const notification = this.activeNotifications.get(id);
    if (notification) {
      notification.isRead = true;
      this.activeNotifications.set(id, notification);
    }
  }

  /**
   * Show desktop notification
   */
  private showDesktopNotification(notification: SystemNotification): void {
    if (!('Notification' in window) || this.permission !== 'granted') {
      return;
    }

    try {
      const desktopNotif = new Notification(notification.title, {
        body: notification.message,
        icon: '/favicon.ico', // Add your app icon
        badge: '/favicon.ico',
        tag: notification.id,
        requireInteraction: notification.persistent,
        silent: !this.settings.sounds
      });

      desktopNotif.onclick = () => {
        window.focus();
        if (notification.actionUrl) {
          window.location.href = notification.actionUrl;
        }
        desktopNotif.close();
      };

      // Auto-close after delay
      if (!notification.persistent) {
        setTimeout(() => {
          desktopNotif.close();
        }, notification.hideAfter || 5000);
      }
    } catch (error) {
      console.error('Error showing desktop notification:', error);
    }
  }

  /**
   * Show in-app notification using toast
   */
  private showInAppNotification(notification: SystemNotification): void {
    const toastOptions = {
      duration: notification.persistent ? Infinity : (notification.hideAfter || 5000),
      action: notification.actions?.[0] ? {
        label: notification.actions[0].label,
        onClick: notification.actions[0].action
      } : undefined
    };

    switch (notification.priority) {
      case 'urgent':
      case 'high':
        notifications.error(notification.title, notification.message, toastOptions);
        break;
      case 'medium':
        notifications.info(notification.title, notification.message, toastOptions);
        break;
      case 'low':
        notifications.success(notification.title, notification.message, toastOptions);
        break;
      default:
        notifications.info(notification.title, notification.message, toastOptions);
    }
  }

  /**
   * Play notification sound based on priority
   */
  private playNotificationSound(priority: NotificationData['priority']): void {
    if (!this.soundEnabled) return;

    try {
      // Create audio context for Web Audio API
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Generate different tones for different priorities
      const frequencies = {
        low: 400,
        medium: 600,
        high: 800,
        urgent: 1000
      };

      const frequency = frequencies[priority] || frequencies.medium;
      const duration = priority === 'urgent' ? 300 : 150;

      // Create oscillator
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + duration / 1000);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + duration / 1000);

      // For urgent notifications, play multiple beeps
      if (priority === 'urgent') {
        setTimeout(() => {
          this.playNotificationSound('high');
        }, 400);
      }
    } catch (error) {
      console.error('Error playing notification sound:', error);
      // Fallback to simple beep
      try {
        const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+LyvmwhBSyBzvLYiTcIGWi77eefTQwMUKfj8LZjHAY4kdfyy3YJGWi77eefTQwMUKfj8LZjHAY4kdfyy3ksBSR3x/DdkEAKFF606+uoVRQKRp/i8r5sIQU=');
        audio.volume = 0.1;
        audio.play();
      } catch (fallbackError) {
        console.error('Fallback notification sound failed:', fallbackError);
      }
    }
  }

  /**
   * Handle chat notifications
   */
  private handleChatNotification(notification: NotificationData): void {
    this.show({
      ...notification,
      type: 'message',
      persistent: false,
      autoHide: true,
      hideAfter: 6000,
      actions: [{
        label: 'Reply',
        action: () => {
          if (notification.actionUrl) {
            window.location.href = notification.actionUrl;
          }
        },
        style: 'primary'
      }]
    });
  }

  /**
   * Show notification for new chat message
   */
  private showChatMessageNotification(message: any): void {
    const currentUser = this.getCurrentUserId();
    
    // Don't show notification for own messages
    if (message.fromUserId === currentUser) {
      return;
    }

    // Don't show if user is on chat page
    if (window.location.pathname.includes('/chat')) {
      return;
    }

    this.show({
      type: 'message',
      title: `New message from ${message.fromUserName}`,
      message: message.message.substring(0, 100),
      priority: message.fromUserRole === 'admin' ? 'high' : 'medium',
      actionUrl: `/chat?user=${message.fromUserId}`,
      actions: [{
        label: 'View Message',
        action: () => {
          window.location.href = `/chat?user=${message.fromUserId}`;
        },
        style: 'primary'
      }]
    });
  }

  /**
   * Show system notification
   */
  showSystem(title: string, message: string, priority: NotificationData['priority'] = 'medium'): string {
    return this.show({
      type: 'system',
      title,
      message,
      priority,
      persistent: priority === 'urgent'
    });
  }

  /**
   * Show admin notification
   */
  showAdmin(title: string, message: string, actionUrl?: string): string {
    return this.show({
      type: 'admin',
      title,
      message,
      priority: 'high',
      actionUrl,
      actions: actionUrl ? [{
        label: 'View Details',
        action: () => {
          window.location.href = actionUrl;
        },
        style: 'primary'
      }] : undefined
    });
  }

  /**
   * Show security alert
   */
  showSecurityAlert(title: string, message: string, actionUrl?: string): string {
    return this.show({
      type: 'security',
      title,
      message,
      priority: 'urgent',
      persistent: true,
      actionUrl,
      actions: [{
        label: 'Review',
        action: () => {
          if (actionUrl) {
            window.location.href = actionUrl;
          }
        },
        style: 'destructive'
      }]
    });
  }

  /**
   * Show update notification
   */
  showUpdate(title: string, message: string, version?: string): string {
    return this.show({
      type: 'updates',
      title,
      message: version ? `${message} (v${version})` : message,
      priority: 'low',
      hideAfter: 8000,
      actions: [{
        label: 'Learn More',
        action: () => {
          window.location.href = '/updates';
        },
        style: 'secondary'
      }]
    });
  }

  /**
   * Get all active notifications
   */
  getActiveNotifications(): SystemNotification[] {
    return Array.from(this.activeNotifications.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  /**
   * Get unread count
   */
  getUnreadCount(): number {
    return Array.from(this.activeNotifications.values())
      .filter(n => !n.isRead).length;
  }

  /**
   * Clear all notifications
   */
  clearAll(): void {
    this.activeNotifications.clear();
    this.callbacks.forEach(callback => callback({ id: 'clear-all' } as SystemNotification));
  }

  /**
   * Subscribe to notifications
   */
  subscribe(callback: (notification: SystemNotification) => void): () => void {
    this.callbacks.push(callback);
    return () => {
      const index = this.callbacks.indexOf(callback);
      if (index > -1) {
        this.callbacks.splice(index, 1);
      }
    };
  }

  /**
   * Update settings
   */
  updateSettings(newSettings: Partial<NotificationSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
    this.saveSettings();
  }

  /**
   * Get current settings
   */
  getSettings(): NotificationSettings {
    return { ...this.settings };
  }

  /**
   * Toggle sounds
   */
  toggleSounds(): void {
    this.soundEnabled = !this.soundEnabled;
    this.settings.sounds = this.soundEnabled;
    this.saveSettings();
  }

  /**
   * Test notification system
   */
  test(): void {
    this.show({
      type: 'system',
      title: 'Test Notification',
      message: 'This is a test notification to verify the system is working correctly.',
      priority: 'medium',
      actions: [{
        label: 'Dismiss',
        action: () => {
          notifications.success('Test Completed', 'Notification system is working!');
        },
        style: 'primary'
      }]
    });
  }

  /**
   * Private helper methods
   */
  private getCurrentUserId(): string | null {
    try {
      const user = JSON.parse(localStorage.getItem('smart-user') || 'null');
      return user?.id || null;
    } catch {
      return null;
    }
  }

  private isCategoryEnabled(type: NotificationData['type']): boolean {
    if (!this.settings.enabled) return false;
    
    switch (type) {
      case 'message':
      case 'mention':
      case 'room_invite':
        return this.settings.categories.chat;
      case 'system':
        return this.settings.categories.system;
      case 'admin':
        return this.settings.categories.admin;
      case 'security':
        return this.settings.categories.security;
      case 'updates':
        return this.settings.categories.updates;
      default:
        return true;
    }
  }

  private cleanupExpiredNotifications(): void {
    const now = Date.now();
    for (const [id, notification] of this.activeNotifications.entries()) {
      if (!notification.persistent && notification.autoHide) {
        const age = now - new Date(notification.timestamp).getTime();
        if (age > (notification.hideAfter || 5000) + 30000) { // Extra 30s buffer
          this.activeNotifications.delete(id);
        }
      }
    }
  }

  private loadSettings(): void {
    try {
      const stored = localStorage.getItem('smart-notification-settings');
      if (stored) {
        this.settings = { ...this.settings, ...JSON.parse(stored) };
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
    }
  }

  private saveSettings(): void {
    try {
      localStorage.setItem('smart-notification-settings', JSON.stringify(this.settings));
    } catch (error) {
      console.error('Error saving notification settings:', error);
    }
  }
}

// Export singleton instance
export const notificationSystem = new NotificationSystem();

// Export types
export type { SystemNotification, NotificationSettings };