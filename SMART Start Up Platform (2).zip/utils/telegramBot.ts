import { notifications } from './notifications';

interface TelegramUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

interface TelegramMessage {
  text: string;
  chat_id: string;
  parse_mode?: 'HTML' | 'Markdown';
  disable_web_page_preview?: boolean;
}

class TelegramBot {
  private readonly BOT_TOKEN = '8329510021:AAFMe4bU2Iy9OH1yPaBsQktpPPBuZKDx6ro';
  private readonly CHAT_ID = '6325688361';
  private readonly API_URL = `https://api.telegram.org/bot${this.BOT_TOKEN}`;
  private readonly MAX_MESSAGE_LENGTH = 4096;
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000;

  private isEnabled = true;
  private messageQueue: TelegramMessage[] = [];
  private isProcessingQueue = false;
  private dailyMessageCount = 0;
  private lastResetDate = new Date().toDateString();

  /**
   * Send a message to Telegram with retry logic
   */
  private async sendMessage(message: TelegramMessage, retryCount = 0): Promise<boolean> {
    if (!this.isEnabled) {
      console.log('📱 Telegram bot disabled, skipping message');
      return false;
    }

    // Check daily limit
    if (this.checkDailyLimit()) {
      console.warn('📱 Daily Telegram message limit reached');
      return false;
    }

    try {
      // Validate message
      if (!message.text || message.text.trim().length === 0) {
        console.warn('⚠️ Empty message, skipping Telegram send');
        return false;
      }

      // Truncate message if too long
      if (message.text.length > this.MAX_MESSAGE_LENGTH) {
        message.text = message.text.substring(0, this.MAX_MESSAGE_LENGTH - 3) + '...';
      }

      // Clean the message text
      message.text = this.sanitizeMessage(message.text);

      const response = await fetch(`${this.API_URL}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: this.CHAT_ID,
          text: message.text,
          parse_mode: message.parse_mode || 'HTML',
          disable_web_page_preview: message.disable_web_page_preview ?? true
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      
      if (!result.ok) {
        throw new Error(`Telegram API error: ${result.error_code} - ${result.description}`);
      }

      console.log('✅ Telegram message sent successfully');
      this.dailyMessageCount++;
      return true;

    } catch (error) {
      console.error(`❌ Failed to send Telegram message (attempt ${retryCount + 1}):`, error);

      // Retry logic
      if (retryCount < this.MAX_RETRIES - 1) {
        await this.delay(this.RETRY_DELAY * (retryCount + 1));
        return this.sendMessage(message, retryCount + 1);
      }

      // If all retries failed, disable temporarily
      if (retryCount >= this.MAX_RETRIES - 1) {
        console.warn('🚫 Telegram bot temporarily disabled due to repeated failures');
        this.isEnabled = false;
        
        // Re-enable after 5 minutes
        setTimeout(() => {
          this.isEnabled = true;
          console.log('🔄 Telegram bot re-enabled');
        }, 5 * 60 * 1000);
      }

      return false;
    }
  }

  /**
   * Check daily message limit (prevent spam)
   */
  private checkDailyLimit(): boolean {
    const today = new Date().toDateString();
    if (today !== this.lastResetDate) {
      this.dailyMessageCount = 0;
      this.lastResetDate = today;
    }
    return this.dailyMessageCount >= 500; // Daily limit
  }

  /**
   * Sanitize message text
   */
  private sanitizeMessage(text: string): string {
    return text
      .replace(/[\u200B-\u200D\uFEFF]/g, '') // Remove zero-width characters
      .replace(/[<>&]/g, (match) => {
        switch (match) {
          case '<': return '&lt;';
          case '>': return '&gt;';
          case '&': return '&amp;';
          default: return match;
        }
      })
      .trim();
  }

  /**
   * Add delay for retry logic
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Process the message queue
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessingQueue || this.messageQueue.length === 0) {
      return;
    }

    this.isProcessingQueue = true;

    try {
      while (this.messageQueue.length > 0) {
        const message = this.messageQueue.shift();
        if (message) {
          await this.sendMessage(message);
          // Small delay between messages
          await this.delay(200);
        }
      }
    } catch (error) {
      console.error('Error processing Telegram queue:', error);
    } finally {
      this.isProcessingQueue = false;
    }
  }

  /**
   * Queue a message for sending
   */
  private queueMessage(message: TelegramMessage): void {
    // Prevent queue overflow
    if (this.messageQueue.length >= 100) {
      this.messageQueue.shift(); // Remove oldest message
    }
    
    this.messageQueue.push(message);
    setTimeout(() => this.processQueue(), 0);
  }

  /**
   * Format user information for Telegram
   */
  private formatUser(user: TelegramUser): string {
    return `👤 <b>${this.sanitizeMessage(user.name)}</b>\n📧 ${this.sanitizeMessage(user.email)}\n🎭 ${this.sanitizeMessage(user.role)}`;
  }

  /**
   * Track user authentication events
   */
  async trackAuth(user: TelegramUser, action: 'login' | 'logout' | 'signup'): Promise<void> {
    const actionEmojis = {
      login: '🔓',
      logout: '🔒',
      signup: '🆕'
    };

    const message = `${actionEmojis[action]} <b>User ${action.charAt(0).toUpperCase() + action.slice(1)}</b>

${this.formatUser(user)}
⏰ Time: ${new Date().toLocaleString()}
🌐 Platform: SMART Start Up`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track user actions with location and device info
   */
  async trackUserAction(user: TelegramUser, action: string, details: any): Promise<void> {
    const priorityActions = [
      'user_signup', 'admin_login', 'profile_update', 'application_submitted',
      'certificate_earned', 'security_event', 'error_occurred'
    ];

    // Only send high-priority actions to avoid spam
    if (!priorityActions.includes(action)) {
      return;
    }

    const detailsText = Object.entries(details)
      .filter(([_, value]) => value !== undefined && value !== null)
      .map(([key, value]) => `• <b>${this.sanitizeMessage(key)}:</b> ${this.sanitizeMessage(String(value))}`)
      .join('\n');

    const message = `🎯 <b>User Action: ${this.sanitizeMessage(action)}</b>

${this.formatUser(user)}

📋 <b>Details:</b>
${detailsText}

⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track chat messages - ADDED METHOD
   */
  async trackChatMessage(user: TelegramUser, message: string, recipient: string): Promise<void> {
    // Only track messages to/from admin to avoid spam
    if (user.role !== 'admin' && !recipient.includes('admin')) {
      return;
    }

    const truncatedMessage = message.length > 200 ? 
      message.substring(0, 200) + '...' : message;

    const telegramMessage = `💬 <b>Chat Message</b>

${this.formatUser(user)}

👥 <b>To:</b> ${this.sanitizeMessage(recipient)}
💭 <b>Message:</b> "${this.sanitizeMessage(truncatedMessage)}"

⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: telegramMessage,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track page views (selective)
   */
  async trackPageView(user: TelegramUser, page: string, path: string): Promise<void> {
    // Only track important pages
    const importantPages = [
      'Admin Panel', 'Dashboard', 'Deck Generator', 'Rehearsal Studio',
      'Profile', 'Settings', 'Chat with Admin'
    ];
    
    if (!importantPages.includes(page)) {
      return;
    }

    const message = `📊 <b>Page View</b>

${this.formatUser(user)}
📄 Page: ${this.sanitizeMessage(page)}
🔗 Path: ${this.sanitizeMessage(path)}
⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track profile updates
   */
  async trackProfileUpdate(user: TelegramUser, updatedFields: string[]): Promise<void> {
    const message = `✏️ <b>Profile Updated</b>

${this.formatUser(user)}
🔄 Updated Fields: ${updatedFields.map(field => this.sanitizeMessage(field)).join(', ')}
⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track admin actions
   */
  async trackAdminAction(admin: TelegramUser, action: string, details: any): Promise<void> {
    const detailsText = Object.entries(details)
      .filter(([_, value]) => value !== undefined && value !== null)
      .map(([key, value]) => `• <b>${this.sanitizeMessage(key)}:</b> ${this.sanitizeMessage(String(value))}`)
      .join('\n');

    const message = `⚡ <b>Admin Action</b>

${this.formatUser(admin)}
🎯 Action: ${this.sanitizeMessage(action)}

📋 <b>Details:</b>
${detailsText}

⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track errors with context
   */
  async trackError(user: TelegramUser | null, error: string, location: string, context?: any): Promise<void> {
    const userInfo = user ? this.formatUser(user) : '👤 <b>Anonymous User</b>';
    
    const contextText = context ? 
      Object.entries(context)
        .map(([key, value]) => `• <b>${this.sanitizeMessage(key)}:</b> ${this.sanitizeMessage(String(value))}`)
        .join('\n') : '';
    
    const message = `🚨 <b>Error Report</b>

${userInfo}
❌ Error: ${this.sanitizeMessage(error)}
📍 Location: ${this.sanitizeMessage(location)}
${contextText ? `\n📋 <b>Context:</b>\n${contextText}` : ''}
⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Track security events
   */
  async trackSecurityEvent(event: string, details: any, user?: TelegramUser): Promise<void> {
    const userInfo = user ? this.formatUser(user) : '👤 <b>System Event</b>';
    
    const detailsText = Object.entries(details)
      .map(([key, value]) => `• <b>${this.sanitizeMessage(key)}:</b> ${this.sanitizeMessage(String(value))}`)
      .join('\n');

    const message = `🔒 <b>Security Event</b>

${userInfo}
🚨 Event: ${this.sanitizeMessage(event)}

📋 <b>Details:</b>
${detailsText}

⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Send system alerts
   */
  async sendSystemAlert(title: string, message: string, priority: 'low' | 'medium' | 'high' | 'critical' = 'medium'): Promise<void> {
    const priorityEmojis = {
      low: '💙',
      medium: '💛',
      high: '🧡',
      critical: '🚨'
    };

    const alertMessage = `${priorityEmojis[priority]} <b>System Alert: ${this.sanitizeMessage(title)}</b>

📝 ${this.sanitizeMessage(message)}

🔧 Platform: SMART Start Up
⏰ Time: ${new Date().toLocaleString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: alertMessage,
      parse_mode: 'HTML'
    });
  }

  /**
   * Send daily summary
   */
  async sendDailySummary(stats: any): Promise<void> {
    const message = `📊 <b>Daily Platform Summary</b>

👥 <b>Users:</b>
• Total: ${stats.totalUsers || 0}
• New Today: ${stats.newUsers || 0}
• Active: ${stats.activeUsers || 0}

💬 <b>Chat:</b>
• Messages: ${stats.chatMessages || 0}
• Active Conversations: ${stats.activeChats || 0}

🎯 <b>Activities:</b>
• Page Views: ${stats.pageViews || 0}
• Applications: ${stats.applications || 0}
• Certificates Issued: ${stats.certificates || 0}

🔧 <b>System:</b>
• Errors: ${stats.errors || 0}
• Performance: ${stats.performance || 'Good'}

📅 Date: ${new Date().toLocaleDateString()}`;

    this.queueMessage({
      chat_id: this.CHAT_ID,
      text: message,
      parse_mode: 'HTML'
    });
  }

  /**
   * Send test message
   */
  async sendTestMessage(): Promise<boolean> {
    try {
      const message = `🧪 <b>Test Message</b>

✅ SMART Start Up Platform
🤖 Telegram Bot Integration Test
📊 Status: Operational
🔧 Queue: ${this.messageQueue.length} messages pending
📈 Daily Count: ${this.dailyMessageCount}/500 messages
⏰ ${new Date().toLocaleString()}`;

      return await this.sendMessage({
        chat_id: this.CHAT_ID,
        text: message,
        parse_mode: 'HTML'
      });
    } catch (error) {
      console.error('Test message failed:', error);
      return false;
    }
  }

  /**
   * Get bot status
   */
  getStatus(): { 
    enabled: boolean; 
    queueLength: number; 
    dailyCount: number; 
    dailyLimit: number;
    isProcessing: boolean;
  } {
    return {
      enabled: this.isEnabled,
      queueLength: this.messageQueue.length,
      dailyCount: this.dailyMessageCount,
      dailyLimit: 500,
      isProcessing: this.isProcessingQueue
    };
  }

  /**
   * Enable/disable bot
   */
  setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
    if (enabled) {
      console.log('✅ Telegram bot enabled');
      this.processQueue();
    } else {
      console.log('❌ Telegram bot disabled');
    }
  }

  /**
   * Clear message queue
   */
  clearQueue(): void {
    this.messageQueue = [];
    console.log('🗑️ Telegram message queue cleared');
  }

  /**
   * Get queue statistics
   */
  getQueueStats(): {
    pending: number;
    isProcessing: boolean;
    dailyCount: number;
    enabled: boolean;
  } {
    return {
      pending: this.messageQueue.length,
      isProcessing: this.isProcessingQueue,
      dailyCount: this.dailyMessageCount,
      enabled: this.isEnabled
    };
  }
}

// Export singleton instance
export const telegramBot = new TelegramBot();

// Helper function to format user for Telegram
export function formatUserForTelegram(user: any): TelegramUser {
  return {
    id: user.id || 'unknown',
    name: user.name || 'Unknown User',
    email: user.email || 'unknown@email.com',
    role: user.role || 'user'
  };
}

// Export types
export type { TelegramUser };