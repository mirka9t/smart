import { notifications } from './notifications';

export interface Program {
  id: string;
  name: string;
  type: 'Accelerator' | 'Incubator' | 'Fellowship' | 'Competition';
  description: string;
  duration: string;
  location: string;
  stage: string;
  applicationDeadline: string;
  website: string;
  logo?: string;
  funding?: string;
  equity?: string;
  features: string[];
  requirements: string[];
  benefits: string[];
  successStories?: string[];
  rating?: number;
  reviews?: number;
}

export interface Mentor {
  id: string;
  name: string;
  title: string;
  company: string;
  expertise: string[];
  bio: string;
  avatar?: string;
  linkedin?: string;
  twitter?: string;
  calendar?: string;
  rating: number;
  reviews: number;
  price?: string;
  availability: string;
  location: string;
  languages: string[];
  experience: number;
  sessions: number;
}

export interface Startup {
  id: string;
  name: string;
  tagline: string;
  description: string;
  stage: 'Idea' | 'MVP' | 'Scaling';
  industry: string;
  founded: string;
  location: string;
  website?: string;
  logo?: string;
  founders: string[];
  funding?: string;
  employees?: string;
  tags: string[];
  socialLinks?: {
    linkedin?: string;
    twitter?: string;
    instagram?: string;
  };
}

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  type: 'Workshop' | 'Webinar' | 'Networking' | 'Competition' | 'Masterclass';
  speaker?: string;
  capacity?: number;
  registered?: number;
  price?: string;
  tags: string[];
  image?: string;
}

export interface Question {
  id: string;
  category: string;
  question: string;
  type: 'text' | 'multiple-choice' | 'yes-no' | 'scale' | 'file';
  required: boolean;
  options?: string[];
  placeholder?: string;
  helpText?: string;
}

// Comprehensive fallback data
const FALLBACK_PROGRAMS: Program[] = [
  {
    id: 'techstars-2024',
    name: 'Techstars Accelerator',
    type: 'Accelerator',
    description: 'Global startup accelerator providing mentorship, funding, and lifelong network access to entrepreneurs worldwide.',
    duration: '3 months',
    location: 'Multiple Cities',
    stage: 'Early-stage startups with MVP',
    applicationDeadline: '2024-03-15',
    website: 'https://techstars.com',
    funding: '$120K',
    equity: '6%',
    features: ['3-month accelerator program', 'Global mentor network', 'Demo day presentation', 'Alumni network access'],
    requirements: ['Working MVP or prototype', 'Committed founding team', 'Scalable business model', 'Clear market opportunity'],
    benefits: ['$120K investment', 'World-class mentorship', 'Global network access', 'Lifetime alumni support'],
    rating: 4.8,
    reviews: 156
  },
  {
    id: 'ycombinator-2024',
    name: 'Y Combinator',
    type: 'Accelerator',
    description: 'The most successful startup accelerator in the world, having funded companies like Airbnb, Dropbox, and Stripe.',
    duration: '3 months',
    location: 'San Francisco, CA',
    stage: 'Early-stage startups',
    applicationDeadline: '2024-04-01',
    website: 'https://ycombinator.com',
    funding: '$500K',
    equity: '7%',
    features: ['3-month program', 'Weekly partner meetings', 'Demo Day', 'YC alumni network'],
    requirements: ['Strong founding team', 'Clear product vision', 'Willingness to relocate to SF'],
    benefits: ['$500K investment', 'YC alumni network', 'Investor introductions', 'Ongoing partner support'],
    rating: 4.9,
    reviews: 289
  },
  {
    id: 'student-fellowship-2024',
    name: 'Student Founder Fellowship',
    type: 'Fellowship',
    description: 'A 6-month fellowship program designed specifically for student entrepreneurs building their first startup.',
    duration: '6 months',
    location: 'Virtual + Boston',
    stage: 'Student founders (age 18-25)',
    applicationDeadline: '2024-05-01',
    website: 'https://studentfounders.org',
    funding: '$50K',
    equity: '0%',
    features: ['Monthly mentorship sessions', 'Peer founder cohort', 'Industry expert talks', 'Pitch competition'],
    requirements: ['Currently enrolled student', 'Early-stage idea or prototype', 'Commitment to program'],
    benefits: ['$50K grant funding', 'Expert mentorship', 'Founder community', 'Industry connections'],
    rating: 4.7,
    reviews: 92
  },
  {
    id: 'climate-tech-incubator',
    name: 'Climate Tech Incubator',
    type: 'Incubator',
    description: 'Supporting climate technology startups with funding, mentorship, and industry partnerships.',
    duration: '12 months',
    location: 'Austin, TX',
    stage: 'Climate tech startups',
    applicationDeadline: '2024-06-15',
    website: 'https://climatetechincubator.com',
    funding: '$250K',
    equity: '8%',
    features: ['12-month incubation', 'Climate industry focus', 'Corporate partnerships', 'Sustainability mentorship'],
    requirements: ['Climate-focused solution', 'Technical team', 'Market validation', 'Environmental impact potential'],
    benefits: ['$250K investment', 'Industry partnerships', 'Sustainability expertise', 'Market access'],
    rating: 4.6,
    reviews: 73
  }
];

const FALLBACK_MENTORS: Mentor[] = [
  {
    id: 'sarah-chen',
    name: 'Sarah Chen',
    title: 'Senior Product Manager',
    company: 'Google',
    expertise: ['Product Management', 'User Experience', 'Growth Strategy', 'Mobile Apps'],
    bio: 'Former startup founder turned product leader at Google. Passionate about helping early-stage startups build products that users love. 8+ years of experience in product development and growth.',
    rating: 4.9,
    reviews: 47,
    price: '$150/hour',
    availability: 'Weekdays 2-6 PM PST',
    location: 'San Francisco, CA',
    languages: ['English', 'Mandarin'],
    experience: 8,
    sessions: 156
  },
  {
    id: 'marcus-johnson',
    name: 'Marcus Johnson',
    title: 'Venture Partner',
    company: 'Andreessen Horowitz',
    expertise: ['Fundraising', 'Business Strategy', 'Market Analysis', 'Venture Capital'],
    bio: 'Venture partner with 12+ years of experience in startup funding and strategy. Former CEO of two successful exits, now helping founders navigate the funding landscape.',
    rating: 4.8,
    reviews: 93,
    price: '$200/hour',
    availability: 'Flexible',
    location: 'New York, NY',
    languages: ['English', 'Spanish'],
    experience: 12,
    sessions: 284
  },
  {
    id: 'elena-rodriguez',
    name: 'Elena Rodriguez',
    title: 'Head of Marketing',
    company: 'Stripe',
    expertise: ['Digital Marketing', 'Brand Strategy', 'Customer Acquisition', 'Content Marketing'],
    bio: 'Marketing executive with expertise in scaling B2B and B2C companies. Led marketing teams at Stripe, Airbnb, and several successful startups.',
    rating: 4.7,
    reviews: 62,
    price: '$175/hour',
    availability: 'Evenings & Weekends',
    location: 'Seattle, WA',
    languages: ['English', 'Spanish', 'Portuguese'],
    experience: 10,
    sessions: 198
  },
  {
    id: 'david-kim',
    name: 'David Kim',
    title: 'CTO & Co-founder',
    company: 'TechFlow Solutions',
    expertise: ['Technical Architecture', 'Team Building', 'Startup CTO', 'AI/ML'],
    bio: 'Serial entrepreneur and technical leader. Built and scaled engineering teams from 2 to 50+ developers. Expert in modern tech stack and AI implementation.',
    rating: 4.9,
    reviews: 81,
    price: '$180/hour',
    availability: 'Weekdays 9 AM - 5 PM PST',
    location: 'Austin, TX',
    languages: ['English', 'Korean'],
    experience: 15,
    sessions: 312
  }
];

const FALLBACK_STARTUPS: Startup[] = [
  {
    id: 'ecotrack',
    name: 'EcoTrack',
    tagline: 'Sustainable supply chain management for modern businesses',
    description: 'AI-powered platform helping companies track and reduce their environmental impact across their entire supply chain with real-time monitoring and actionable insights.',
    stage: 'MVP',
    industry: 'Sustainability',
    founded: '2023',
    location: 'Austin, TX',
    website: 'https://ecotrack.com',
    founders: ['Alex Rivera', 'Sam Kim'],
    funding: 'Seed - $2M',
    employees: '8-15',
    tags: ['AI', 'Sustainability', 'B2B', 'SaaS', 'Supply Chain']
  },
  {
    id: 'medisync',
    name: 'MediSync',
    tagline: 'Revolutionizing patient care with AI-driven health monitoring',
    description: 'IoT-enabled health monitoring system that provides real-time patient data to healthcare providers, enabling proactive care and better health outcomes.',
    stage: 'Scaling',
    industry: 'Healthcare',
    founded: '2022',
    location: 'Boston, MA',
    website: 'https://medisync.com',
    founders: ['Dr. Emily Watson', 'David Chang'],
    funding: 'Series A - $8M',
    employees: '25-50',
    tags: ['Healthcare', 'IoT', 'AI', 'B2B', 'Medical Devices']
  },
  {
    id: 'learnfast',
    name: 'LearnFast',
    tagline: 'Personalized learning for the next generation',
    description: 'AI-powered educational platform that adapts to each student\'s learning style and pace, making education more effective and engaging.',
    stage: 'MVP',
    industry: 'EdTech',
    founded: '2023',
    location: 'San Francisco, CA',
    website: 'https://learnfast.io',
    founders: ['Maria Gonzalez', 'James Liu'],
    funding: 'Pre-seed - $500K',
    employees: '3-10',
    tags: ['EdTech', 'AI', 'B2C', 'Mobile', 'Personalization']
  },
  {
    id: 'cryptovault',
    name: 'CryptoVault',
    tagline: 'Secure crypto custody for institutions',
    description: 'Enterprise-grade cryptocurrency custody solution with advanced security features and institutional-level compliance.',
    stage: 'Scaling',
    industry: 'Fintech',
    founded: '2021',
    location: 'New York, NY',
    website: 'https://cryptovault.pro',
    founders: ['Michael Chen', 'Sarah Taylor'],
    funding: 'Series B - $25M',
    employees: '50-100',
    tags: ['Fintech', 'Cryptocurrency', 'Security', 'B2B', 'Blockchain']
  }
];

const FALLBACK_EVENTS: Event[] = [
  {
    id: 'startup-pitch-night',
    title: 'Monthly Startup Pitch Night',
    description: 'Network with fellow entrepreneurs and pitch your startup to a panel of investors and mentors. Great opportunity for feedback and connections.',
    date: '2024-02-15',
    time: '6:00 PM',
    location: 'Innovation Hub, Downtown',
    type: 'Networking',
    speaker: 'Panel of Local VCs',
    capacity: 100,
    registered: 67,
    price: 'Free',
    tags: ['Networking', 'Pitching', 'Investors', 'Feedback']
  },
  {
    id: 'fundraising-masterclass',
    title: 'Fundraising Masterclass',
    description: 'Learn the ins and outs of raising capital from seed to Series A with successful founders and VCs. Includes Q&A and networking.',
    date: '2024-02-22',
    time: '2:00 PM',
    location: 'Virtual Event',
    type: 'Masterclass',
    speaker: 'Sarah Goldman, Partner at XYZ Ventures',
    capacity: 500,
    registered: 234,
    price: '$49',
    tags: ['Fundraising', 'Education', 'Virtual', 'VC']
  },
  {
    id: 'product-development-workshop',
    title: 'Product Development Workshop',
    description: 'Hands-on workshop covering product-market fit, user research, and rapid prototyping techniques for early-stage startups.',
    date: '2024-03-05',
    time: '10:00 AM',
    location: 'Tech Campus, Building A',
    type: 'Workshop',
    speaker: 'Mike Johnson, Former Head of Product at Uber',
    capacity: 50,
    registered: 32,
    price: '$99',
    tags: ['Product', 'Workshop', 'PMF', 'UX']
  }
];

const FALLBACK_QUESTIONS: Question[] = [
  {
    id: 'company-name',
    category: 'Basic Information',
    question: 'What is your company name?',
    type: 'text',
    required: true,
    placeholder: 'Enter your company name',
    helpText: 'This will be displayed on your application'
  },
  {
    id: 'founder-background',
    category: 'Team',
    question: 'Please describe your background and why you\'re the right person to solve this problem.',
    type: 'text',
    required: true,
    placeholder: 'Tell us about your experience, skills, and passion for this problem...',
    helpText: 'Focus on relevant experience and unique insights'
  },
  {
    id: 'problem-statement',
    category: 'Business Model',
    question: 'What problem are you solving?',
    type: 'text',
    required: true,
    placeholder: 'Describe the problem your startup addresses...',
    helpText: 'Be specific about the pain point and target audience'
  },
  {
    id: 'solution-description',
    category: 'Business Model',
    question: 'How does your solution address this problem?',
    type: 'text',
    required: true,
    placeholder: 'Explain your solution and its unique value proposition...',
    helpText: 'Focus on what makes your solution different and better'
  },
  {
    id: 'funding-stage',
    category: 'Funding',
    question: 'What funding stage are you currently in?',
    type: 'multiple-choice',
    required: true,
    options: ['Pre-seed', 'Seed', 'Series A', 'Series B', 'Later stage', 'Not seeking funding'],
    helpText: 'Select the stage that best describes your current funding status'
  },
  {
    id: 'team-size',
    category: 'Team',
    question: 'How many people are on your founding team?',
    type: 'multiple-choice',
    required: true,
    options: ['Just me (solo founder)', '2 founders', '3 founders', '4+ founders'],
    helpText: 'Include only founding team members, not employees'
  }
];

// Improved data loader with better error handling
async function loadDataWithFallback<T>(
  dataType: string,
  fallbackData: T[]
): Promise<T[]> {
  try {
    // Always use fallback data for now since we don't have a real backend
    console.log(`Loading ${dataType} data...`);
    
    // Simulate a small delay to make it feel more realistic
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Show a subtle notification that we're using demo data
    if (dataType === 'programs') {
      notifications.info(
        'Demo Mode',
        'Showing sample data. In production, this would load from your database.'
      );
    }
    
    return fallbackData;
  } catch (error) {
    console.warn(`Error loading ${dataType}:`, error);
    return fallbackData;
  }
}

export async function loadPrograms(): Promise<Program[]> {
  return loadDataWithFallback('programs', FALLBACK_PROGRAMS);
}

export async function loadMentors(): Promise<Mentor[]> {
  return loadDataWithFallback('mentors', FALLBACK_MENTORS);
}

export async function loadStartups(): Promise<Startup[]> {
  return loadDataWithFallback('startups', FALLBACK_STARTUPS);
}

export async function loadEvents(): Promise<Event[]> {
  return loadDataWithFallback('events', FALLBACK_EVENTS);
}

export async function loadQuestions(): Promise<Question[]> {
  return loadDataWithFallback('questions', FALLBACK_QUESTIONS);
}

// Search and filter utilities
export function searchPrograms(programs: Program[], query: string): Program[] {
  if (!query.trim()) return programs;
  
  const searchTerm = query.toLowerCase();
  return programs.filter(program =>
    program.name.toLowerCase().includes(searchTerm) ||
    program.description.toLowerCase().includes(searchTerm) ||
    program.type.toLowerCase().includes(searchTerm) ||
    program.location.toLowerCase().includes(searchTerm) ||
    program.features.some(feature => feature.toLowerCase().includes(searchTerm))
  );
}

export function filterProgramsByType(programs: Program[], type: string): Program[] {
  if (type === 'All') return programs;
  return programs.filter(program => program.type === type);
}

export function searchMentors(mentors: Mentor[], query: string): Mentor[] {
  if (!query.trim()) return mentors;
  
  const searchTerm = query.toLowerCase();
  return mentors.filter(mentor =>
    mentor.name.toLowerCase().includes(searchTerm) ||
    mentor.title.toLowerCase().includes(searchTerm) ||
    mentor.company.toLowerCase().includes(searchTerm) ||
    mentor.expertise.some(skill => skill.toLowerCase().includes(searchTerm))
  );
}

export function filterMentorsByExpertise(mentors: Mentor[], expertise: string): Mentor[] {
  if (expertise === 'All') return mentors;
  return mentors.filter(mentor => mentor.expertise.includes(expertise));
}

export function searchStartups(startups: Startup[], query: string): Startup[] {
  if (!query.trim()) return startups;
  
  const searchTerm = query.toLowerCase();
  return startups.filter(startup =>
    startup.name.toLowerCase().includes(searchTerm) ||
    startup.tagline.toLowerCase().includes(searchTerm) ||
    startup.description.toLowerCase().includes(searchTerm) ||
    startup.industry.toLowerCase().includes(searchTerm) ||
    startup.tags.some(tag => tag.toLowerCase().includes(searchTerm))
  );
}

export function filterStartupsByStage(startups: Startup[], stage: string): Startup[] {
  if (stage === 'All') return startups;
  return startups.filter(startup => startup.stage === stage);
}