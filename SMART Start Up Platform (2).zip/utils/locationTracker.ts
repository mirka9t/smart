interface LocationData {
  country?: string;
  city?: string;
  region?: string;
  timezone?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  isp?: string;
  org?: string;
}

interface DeviceInfo {
  browser?: string;
  os?: string;
  device?: string;
  screen?: string;
  mobile?: boolean;
  platform?: string;
}

class LocationTracker {
  private cachedLocation: LocationData | null = null;
  private cachedIP: string | null = null;
  private readonly CACHE_DURATION = 60 * 60 * 1000; // 1 hour
  private lastLocationFetch = 0;

  /**
   * Get current location using IP-based detection
   */
  async getCurrentLocation(): Promise<LocationData | null> {
    try {
      // Return cached location if still valid
      if (this.cachedLocation && Date.now() - this.lastLocationFetch < this.CACHE_DURATION) {
        return this.cachedLocation;
      }

      // Try multiple IP geolocation services
      const services = [
        'https://ipapi.co/json/',
        'https://ipinfo.io/json',
        'https://api.ipify.org?format=json'
      ];

      for (const service of services) {
        try {
          const response = await fetch(service);
          if (!response.ok) continue;
          
          const data = await response.json();
          
          let location: LocationData = {};
          
          // Parse response based on service
          if (service.includes('ipapi.co')) {
            location = {
              country: data.country_name,
              city: data.city,
              region: data.region,
              timezone: data.timezone,
              coordinates: data.latitude && data.longitude ? {
                lat: parseFloat(data.latitude),
                lng: parseFloat(data.longitude)
              } : undefined,
              isp: data.org
            };
          } else if (service.includes('ipinfo.io')) {
            location = {
              country: data.country,
              city: data.city,
              region: data.region,
              timezone: data.timezone,
              coordinates: data.loc ? {
                lat: parseFloat(data.loc.split(',')[0]),
                lng: parseFloat(data.loc.split(',')[1])
              } : undefined,
              isp: data.org
            };
          }

          // If we got valid data, cache it and return
          if (location.country || location.city) {
            this.cachedLocation = location;
            this.lastLocationFetch = Date.now();
            return location;
          }
        } catch (error) {
          console.warn(`Location service ${service} failed:`, error);
          continue;
        }
      }

      // Fallback: try to get timezone from browser
      const fallbackLocation: LocationData = {
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        country: this.getCountryFromTimezone(Intl.DateTimeFormat().resolvedOptions().timeZone)
      };

      this.cachedLocation = fallbackLocation;
      this.lastLocationFetch = Date.now();
      return fallbackLocation;

    } catch (error) {
      console.error('Error getting location:', error);
      return null;
    }
  }

  /**
   * Get user's IP address
   */
  async getIPAddress(): Promise<string | null> {
    try {
      if (this.cachedIP) {
        return this.cachedIP;
      }

      const services = [
        'https://api.ipify.org?format=json',
        'https://ipapi.co/ip/',
        'https://ipinfo.io/ip'
      ];

      for (const service of services) {
        try {
          const response = await fetch(service);
          if (!response.ok) continue;
          
          let ip: string;
          
          if (service.includes('ipify.org')) {
            const data = await response.json();
            ip = data.ip;
          } else {
            ip = await response.text();
            ip = ip.trim();
          }

          if (ip && this.isValidIP(ip)) {
            this.cachedIP = ip;
            return ip;
          }
        } catch (error) {
          console.warn(`IP service ${service} failed:`, error);
          continue;
        }
      }

      return null;
    } catch (error) {
      console.error('Error getting IP address:', error);
      return null;
    }
  }

  /**
   * Get detailed device and browser information
   */
  getDeviceInfo(): DeviceInfo {
    try {
      const userAgent = navigator.userAgent;
      const platform = navigator.platform;
      
      return {
        browser: this.getBrowserInfo(userAgent),
        os: this.getOSInfo(userAgent, platform),
        device: this.getDeviceType(userAgent),
        screen: `${screen.width}x${screen.height}`,
        mobile: this.isMobile(userAgent),
        platform: platform
      };
    } catch (error) {
      console.error('Error getting device info:', error);
      return {};
    }
  }

  /**
   * Get browser information from user agent
   */
  private getBrowserInfo(userAgent: string): string {
    const browsers = [
      { name: 'Chrome', regex: /Chrome\/(\d+)/ },
      { name: 'Firefox', regex: /Firefox\/(\d+)/ },
      { name: 'Safari', regex: /Safari\/(\d+)/ },
      { name: 'Edge', regex: /Edg\/(\d+)/ },
      { name: 'Opera', regex: /OPR\/(\d+)/ },
      { name: 'Internet Explorer', regex: /MSIE (\d+)/ }
    ];

    for (const browser of browsers) {
      const match = userAgent.match(browser.regex);
      if (match) {
        return `${browser.name} ${match[1]}`;
      }
    }

    return 'Unknown Browser';
  }

  /**
   * Get operating system information
   */
  private getOSInfo(userAgent: string, platform: string): string {
    const osMap: { [key: string]: string } = {
      'Win32': 'Windows',
      'Win64': 'Windows',
      'Windows NT': 'Windows',
      'MacIntel': 'macOS',
      'MacPPC': 'macOS',
      'Linux x86_64': 'Linux',
      'Linux i686': 'Linux'
    };

    // Check platform first
    for (const [key, value] of Object.entries(osMap)) {
      if (platform.includes(key)) {
        return value;
      }
    }

    // Check user agent for mobile OS
    if (userAgent.includes('iPhone') || userAgent.includes('iPad')) {
      return 'iOS';
    }
    if (userAgent.includes('Android')) {
      return 'Android';
    }
    if (userAgent.includes('Windows Phone')) {
      return 'Windows Phone';
    }

    return platform || 'Unknown OS';
  }

  /**
   * Determine device type
   */
  private getDeviceType(userAgent: string): string {
    if (userAgent.includes('Mobile') || userAgent.includes('Android')) {
      return 'Mobile';
    }
    if (userAgent.includes('Tablet') || userAgent.includes('iPad')) {
      return 'Tablet';
    }
    return 'Desktop';
  }

  /**
   * Check if device is mobile
   */
  private isMobile(userAgent: string): boolean {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
  }

  /**
   * Validate IP address format
   */
  private isValidIP(ip: string): boolean {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    return ipv4Regex.test(ip) || ipv6Regex.test(ip);
  }

  /**
   * Get country from timezone (rough estimation)
   */
  private getCountryFromTimezone(timezone: string): string | undefined {
    const timezoneCountryMap: { [key: string]: string } = {
      'America/New_York': 'United States',
      'America/Chicago': 'United States',
      'America/Denver': 'United States',
      'America/Los_Angeles': 'United States',
      'Europe/London': 'United Kingdom',
      'Europe/Paris': 'France',
      'Europe/Berlin': 'Germany',
      'Europe/Madrid': 'Spain',
      'Europe/Rome': 'Italy',
      'Asia/Tokyo': 'Japan',
      'Asia/Shanghai': 'China',
      'Asia/Kolkata': 'India',
      'Australia/Sydney': 'Australia',
      'Pacific/Auckland': 'New Zealand'
    };

    return timezoneCountryMap[timezone];
  }

  /**
   * Get geolocation using browser API (requires user permission)
   */
  async getBrowserLocation(): Promise<{ lat: number; lng: number } | null> {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.warn('Browser geolocation failed:', error);
          resolve(null);
        },
        {
          timeout: 10000,
          maximumAge: 600000, // 10 minutes
          enableHighAccuracy: false
        }
      );
    });
  }

  /**
   * Get comprehensive location data including browser geolocation
   */
  async getFullLocationData(): Promise<LocationData | null> {
    try {
      const [ipLocation, browserCoords] = await Promise.all([
        this.getCurrentLocation(),
        this.getBrowserLocation()
      ]);

      if (!ipLocation) return null;

      // Merge IP location with browser coordinates if available
      const fullLocation: LocationData = {
        ...ipLocation,
        coordinates: browserCoords || ipLocation.coordinates
      };

      return fullLocation;
    } catch (error) {
      console.error('Error getting full location data:', error);
      return null;
    }
  }

  /**
   * Clear cached data
   */
  clearCache(): void {
    this.cachedLocation = null;
    this.cachedIP = null;
    this.lastLocationFetch = 0;
  }

  /**
   * Get location summary string
   */
  getLocationSummary(location: LocationData): string {
    const parts = [];
    if (location.city) parts.push(location.city);
    if (location.region) parts.push(location.region);
    if (location.country) parts.push(location.country);
    return parts.join(', ') || 'Unknown Location';
  }

  /**
   * Get device summary string
   */
  getDeviceSummary(device: DeviceInfo): string {
    const parts = [];
    if (device.browser) parts.push(device.browser);
    if (device.os) parts.push(`on ${device.os}`);
    if (device.device && device.device !== 'Desktop') parts.push(`(${device.device})`);
    return parts.join(' ') || 'Unknown Device';
  }
}

// Export singleton instance
export const locationTracker = new LocationTracker();

// Export types
export type { LocationData, DeviceInfo };