import { telegramBot, formatUserForTelegram } from './telegramBot';
import { notifications } from './notifications';

export interface ChatMessage {
  id: string;
  fromUserId: string;
  fromUserName: string;
  fromUserEmail: string;
  fromUserRole: 'user' | 'admin' | 'moderator';
  toUserId?: string; // For direct messages
  toUserName?: string;
  toUserEmail?: string;
  roomId?: string; // For group chats
  message: string;
  timestamp: string;
  isRead: boolean;
  messageType: 'text' | 'image' | 'file' | 'system';
  editedAt?: string;
  replyToId?: string;
  reactions?: { emoji: string; userId: string; timestamp: string }[];
  attachments?: {
    type: 'image' | 'file';
    url: string;
    name: string;
    size: number;
  }[];
  metadata?: {
    location?: string;
    device?: string;
    ipAddress?: string;
  };
}

export interface ChatRoom {
  id: string;
  name: string;
  type: 'direct' | 'group' | 'public' | 'admin';
  participants: string[]; // User IDs
  createdBy: string;
  createdAt: string;
  lastMessage?: ChatMessage;
  lastActivity: string;
  settings: {
    public: boolean;
    allowFiles: boolean;
    allowImages: boolean;
    maxParticipants: number;
  };
}

export interface ChatUser {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin' | 'moderator';
  avatar?: string;
  isOnline: boolean;
  lastSeen: string;
  profileCompleteness: number;
  status: 'available' | 'busy' | 'away' | 'offline';
  customStatus?: string;
  unreadCount: number;
  lastMessage?: string;
  lastMessageTime?: string;
  blockedUsers: string[];
  preferences: {
    notifications: boolean;
    sounds: boolean;
    emailAlerts: boolean;
    showTyping: boolean;
  };
}

export interface NotificationData {
  id: string;
  type: 'message' | 'mention' | 'room_invite' | 'system' | 'admin';
  title: string;
  message: string;
  fromUser?: string;
  roomId?: string;
  messageId?: string;
  timestamp: string;
  isRead: boolean;
  actionUrl?: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
}

class ChatManager {
  private readonly STORAGE_KEYS = {
    MESSAGES: 'smart-chat-messages',
    ROOMS: 'smart-chat-rooms',
    USERS: 'smart-chat-users',
    NOTIFICATIONS: 'smart-chat-notifications',
    TYPING: 'smart-chat-typing',
    ONLINE_USERS: 'smart-chat-online'
  };

  private typingTimeouts: { [key: string]: NodeJS.Timeout } = {};
  private notificationCallbacks: ((notification: NotificationData) => void)[] = [];
  private messageCallbacks: ((message: ChatMessage) => void)[] = [];

  /**
   * Initialize chat system
   */
  initialize(): void {
    // Set up periodic cleanup
    setInterval(() => {
      this.cleanupOldData();
    }, 5 * 60 * 1000); // Every 5 minutes

    // Set up online status tracking
    this.updateOnlineStatus();
    setInterval(() => {
      this.updateOnlineStatus();
    }, 30 * 1000); // Every 30 seconds
  }

  /**
   * Send a message
   */
  async sendMessage(
    fromUserId: string,
    fromUserName: string,
    fromUserEmail: string,
    fromUserRole: 'user' | 'admin' | 'moderator',
    message: string,
    toUserId?: string,
    roomId?: string,
    messageType: 'text' | 'image' | 'file' | 'system' = 'text',
    attachments?: ChatMessage['attachments'],
    replyToId?: string
  ): Promise<ChatMessage> {
    try {
      const newMessage: ChatMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        fromUserId,
        fromUserName,
        fromUserEmail,
        fromUserRole,
        toUserId,
        roomId,
        message: message.trim(),
        timestamp: new Date().toISOString(),
        isRead: false,
        messageType,
        attachments: attachments || [],
        replyToId,
        reactions: [],
        metadata: {
          location: 'Unknown',
          device: navigator.userAgent.split('(')[0].trim(),
          ipAddress: '0.0.0.0'
        }
      };

      // Get existing messages
      const messages = this.getAllMessages();
      messages.unshift(newMessage); // Add to beginning for chronological order

      // Keep only last 50000 messages
      if (messages.length > 50000) {
        messages.splice(50000);
      }

      // Save messages
      localStorage.setItem(this.STORAGE_KEYS.MESSAGES, JSON.stringify(messages));

      // Update room last activity
      if (roomId) {
        this.updateRoomActivity(roomId, newMessage);
      }

      // Update chat users
      this.updateChatUsers(fromUserId, fromUserName, fromUserEmail, fromUserRole);
      if (toUserId) {
        // Find target user info
        const targetUser = this.getChatUserById(toUserId);
        if (targetUser) {
          this.updateChatUsers(toUserId, targetUser.name, targetUser.email, targetUser.role);
        }
      }

      // Create notifications
      await this.createNotifications(newMessage);

      // Trigger callbacks
      this.messageCallbacks.forEach(callback => callback(newMessage));

      // Send Telegram notification
      await this.sendTelegramNotification(newMessage);

      return newMessage;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  /**
   * Get messages for a specific conversation
   */
  getConversationMessages(userId1: string, userId2?: string, roomId?: string): ChatMessage[] {
    try {
      const allMessages = this.getAllMessages();
      
      if (roomId) {
        // Room messages
        return allMessages
          .filter(msg => msg.roomId === roomId)
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      } else if (userId2) {
        // Direct messages between two users
        return allMessages
          .filter(msg => 
            (msg.fromUserId === userId1 && msg.toUserId === userId2) ||
            (msg.fromUserId === userId2 && msg.toUserId === userId1)
          )
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      } else {
        // All messages for a user
        return allMessages
          .filter(msg => msg.fromUserId === userId1 || msg.toUserId === userId1)
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
      }
    } catch (error) {
      console.error('Error getting conversation messages:', error);
      return [];
    }
  }

  /**
   * Get user messages (for admin panel)
   */
  getUserMessages(userId: string): ChatMessage[] {
    try {
      const allMessages = this.getAllMessages();
      return allMessages
        .filter(msg => msg.fromUserId === userId || msg.toUserId === userId)
        .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    } catch (error) {
      console.error('Error getting user messages:', error);
      return [];
    }
  }

  /**
   * Get all messages (admin only)
   */
  getAllMessages(): ChatMessage[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.MESSAGES);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting all messages:', error);
      return [];
    }
  }

  /**
   * Mark messages as read
   */
  markMessagesAsRead(userId: string, conversationWith?: string, roomId?: string, isAdmin: boolean = false): void {
    try {
      const messages = this.getAllMessages();
      const updated = messages.map(msg => {
        if (roomId) {
          // Mark room messages as read
          if (msg.roomId === roomId && msg.fromUserId !== userId && !msg.isRead) {
            return { ...msg, isRead: true };
          }
        } else if (conversationWith) {
          // Mark direct messages as read
          if (msg.fromUserId === conversationWith && msg.toUserId === userId && !msg.isRead) {
            return { ...msg, isRead: true };
          }
          // For admin marking messages as read
          if (isAdmin && ((msg.fromUserId === userId && msg.toUserId === conversationWith) || 
                          (msg.fromUserId === conversationWith && msg.toUserId === userId)) && !msg.isRead) {
            return { ...msg, isRead: true };
          }
        } else {
          // Mark all messages to this user as read
          if (msg.toUserId === userId && !msg.isRead) {
            return { ...msg, isRead: true };
          }
        }
        return msg;
      });

      localStorage.setItem(this.STORAGE_KEYS.MESSAGES, JSON.stringify(updated));

      // Update unread counts
      this.updateUnreadCounts();
    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  }

  /**
   * Get chat users with online status and unread counts
   */
  getChatUsers(): ChatUser[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.USERS);
      const users: ChatUser[] = stored ? JSON.parse(stored) : [];
      
      // Update unread counts and online status
      return users.map(user => {
        const unreadCount = this.getUnreadCount(user.id);
        const lastMessage = this.getLastMessageForUser(user.id);
        
        return {
          ...user,
          unreadCount,
          isOnline: this.isUserOnline(user.id),
          lastMessage: lastMessage?.message,
          lastMessageTime: lastMessage?.timestamp
        };
      }).sort((a, b) => {
        // Sort by online status first, then by last seen
        if (a.isOnline && !b.isOnline) return -1;
        if (!a.isOnline && b.isOnline) return 1;
        return new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime();
      });
    } catch (error) {
      console.error('Error getting chat users:', error);
      return [];
    }
  }

  /**
   * Get last message for a user
   */
  private getLastMessageForUser(userId: string): ChatMessage | null {
    try {
      const messages = this.getAllMessages();
      const userMessages = messages.filter(msg => 
        msg.fromUserId === userId || msg.toUserId === userId
      );
      
      if (userMessages.length === 0) return null;
      
      // Return the most recent message
      return userMessages.sort((a, b) => 
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      )[0];
    } catch (error) {
      console.error('Error getting last message for user:', error);
      return null;
    }
  }

  /**
   * Get chat user by ID
   */
  getChatUserById(userId: string): ChatUser | null {
    const users = this.getChatUsers();
    return users.find(u => u.id === userId) || null;
  }

  /**
   * Update chat user information
   */
  updateChatUsers(userId: string, userName: string, userEmail: string, userRole: 'user' | 'admin' | 'moderator'): void {
    try {
      const users = this.getChatUsers();
      const existingUserIndex = users.findIndex(u => u.id === userId);
      
      const updatedUser: ChatUser = {
        id: userId,
        name: userName,
        email: userEmail,
        role: userRole,
        isOnline: true,
        lastSeen: new Date().toISOString(),
        profileCompleteness: 75,
        status: 'available',
        unreadCount: 0,
        blockedUsers: [],
        preferences: {
          notifications: true,
          sounds: true,
          emailAlerts: true,
          showTyping: true
        }
      };

      if (existingUserIndex >= 0) {
        users[existingUserIndex] = { ...users[existingUserIndex], ...updatedUser };
      } else {
        users.push(updatedUser);
      }

      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (error) {
      console.error('Error updating chat user:', error);
    }
  }

  /**
   * Create chat room
   */
  async createRoom(
    name: string,
    type: 'direct' | 'group' | 'public' | 'admin',
    createdBy: string,
    participants: string[],
    settings?: Partial<ChatRoom['settings']>
  ): Promise<ChatRoom> {
    try {
      const newRoom: ChatRoom = {
        id: `room-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name,
        type,
        participants: [...new Set([createdBy, ...participants])], // Ensure creator is included and no duplicates
        createdBy,
        createdAt: new Date().toISOString(),
        lastActivity: new Date().toISOString(),
        settings: {
          public: false,
          allowFiles: true,
          allowImages: true,
          maxParticipants: type === 'direct' ? 2 : 100,
          ...settings
        }
      };

      const rooms = this.getAllRooms();
      rooms.unshift(newRoom);
      localStorage.setItem(this.STORAGE_KEYS.ROOMS, JSON.stringify(rooms));

      // Send system message
      await this.sendMessage(
        'system',
        'System',
        'system@smart.com',
        'admin',
        `Room "${name}" created by ${this.getChatUserById(createdBy)?.name || 'Unknown'}`,
        undefined,
        newRoom.id,
        'system'
      );

      return newRoom;
    } catch (error) {
      console.error('Error creating room:', error);
      throw error;
    }
  }

  /**
   * Get all chat rooms
   */
  getAllRooms(): ChatRoom[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.ROOMS);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting rooms:', error);
      return [];
    }
  }

  /**
   * Get rooms for a specific user
   */
  getUserRooms(userId: string): ChatRoom[] {
    return this.getAllRooms().filter(room => room.participants.includes(userId));
  }

  /**
   * Update room activity
   */
  private updateRoomActivity(roomId: string, lastMessage: ChatMessage): void {
    try {
      const rooms = this.getAllRooms();
      const roomIndex = rooms.findIndex(r => r.id === roomId);
      
      if (roomIndex >= 0) {
        rooms[roomIndex].lastMessage = lastMessage;
        rooms[roomIndex].lastActivity = new Date().toISOString();
        localStorage.setItem(this.STORAGE_KEYS.ROOMS, JSON.stringify(rooms));
      }
    } catch (error) {
      console.error('Error updating room activity:', error);
    }
  }

  /**
   * Create notifications for new messages
   */
  private async createNotifications(message: ChatMessage): Promise<void> {
    try {
      // Don't create notifications for system messages or own messages
      if (message.messageType === 'system') return;

      const notifications: NotificationData[] = [];

      if (message.toUserId) {
        // Direct message notification
        const notification: NotificationData = {
          id: `notif-${Date.now()}`,
          type: 'message',
          title: `New message from ${message.fromUserName}`,
          message: message.message.substring(0, 100),
          fromUser: message.fromUserId,
          messageId: message.id,
          timestamp: new Date().toISOString(),
          isRead: false,
          actionUrl: `/chat?user=${message.fromUserId}`,
          priority: message.fromUserRole === 'admin' ? 'high' : 'medium'
        };
        notifications.push(notification);
      }

      if (message.roomId) {
        // Room message notification for all participants except sender
        const room = this.getAllRooms().find(r => r.id === message.roomId);
        if (room) {
          room.participants.forEach(participantId => {
            if (participantId !== message.fromUserId) {
              const notification: NotificationData = {
                id: `notif-${Date.now()}-${participantId}`,
                type: 'message',
                title: `New message in ${room.name}`,
                message: `${message.fromUserName}: ${message.message.substring(0, 100)}`,
                fromUser: message.fromUserId,
                roomId: message.roomId,
                messageId: message.id,
                timestamp: new Date().toISOString(),
                isRead: false,
                actionUrl: `/chat?room=${message.roomId}`,
                priority: 'medium'
              };
              notifications.push(notification);
            }
          });
        }
      }

      // Save notifications
      if (notifications.length > 0) {
        const existingNotifications = this.getNotifications();
        const updatedNotifications = [...notifications, ...existingNotifications];
        
        // Keep only last 10000 notifications
        if (updatedNotifications.length > 10000) {
          updatedNotifications.splice(10000);
        }

        localStorage.setItem(this.STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updatedNotifications));

        // Trigger notification callbacks
        notifications.forEach(notification => {
          this.notificationCallbacks.forEach(callback => callback(notification));
        });
      }
    } catch (error) {
      console.error('Error creating notifications:', error);
    }
  }

  /**
   * Get notifications for a user
   */
  getNotifications(userId?: string): NotificationData[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.NOTIFICATIONS);
      const notifications: NotificationData[] = stored ? JSON.parse(stored) : [];
      
      if (userId) {
        // Filter notifications for specific user
        return notifications.filter(notif => 
          notif.actionUrl?.includes(userId) || 
          notif.fromUser === userId ||
          (notif.roomId && this.getAllRooms().find(r => r.id === notif.roomId)?.participants.includes(userId))
        );
      }
      
      return notifications;
    } catch (error) {
      console.error('Error getting notifications:', error);
      return [];
    }
  }

  /**
   * Mark notifications as read
   */
  markNotificationsAsRead(notificationIds: string[]): void {
    try {
      const notifications = this.getNotifications();
      const updated = notifications.map(notif => 
        notificationIds.includes(notif.id) ? { ...notif, isRead: true } : notif
      );
      localStorage.setItem(this.STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(updated));
    } catch (error) {
      console.error('Error marking notifications as read:', error);
    }
  }

  /**
   * Get unread message count for a user
   */
  getUnreadCount(userId: string): number {
    try {
      const messages = this.getAllMessages();
      return messages.filter(msg => 
        msg.toUserId === userId && !msg.isRead && msg.fromUserId !== userId
      ).length;
    } catch (error) {
      console.error('Error getting unread count:', error);
      return 0;
    }
  }

  /**
   * Get admin unread count - FIXED METHOD
   */
  getAdminUnreadCount(): number {
    try {
      const messages = this.getAllMessages();
      // Count messages sent to admin users that are unread
      return messages.filter(msg => {
        const isToAdmin = msg.toUserId === 'admin-1' || 
                         (msg.toUserEmail && msg.toUserEmail.includes('admin')) ||
                         msg.toUserRole === 'admin';
        return isToAdmin && !msg.isRead && msg.fromUserRole !== 'admin';
      }).length;
    } catch (error) {
      console.error('Error getting admin unread count:', error);
      return 0;
    }
  }

  /**
   * Update unread counts for all users
   */
  private updateUnreadCounts(): void {
    try {
      const users = this.getChatUsers();
      users.forEach(user => {
        user.unreadCount = this.getUnreadCount(user.id);
      });
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (error) {
      console.error('Error updating unread counts:', error);
    }
  }

  /**
   * Check if user is online
   */
  private isUserOnline(userId: string): boolean {
    try {
      const onlineUsers = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ONLINE_USERS) || '{}');
      const lastSeen = onlineUsers[userId];
      if (!lastSeen) return false;
      
      // User is online if seen within last 2 minutes
      return Date.now() - new Date(lastSeen).getTime() < 2 * 60 * 1000;
    } catch (error) {
      console.error('Error checking online status:', error);
      return false;
    }
  }

  /**
   * Update online status for current user
   */
  updateOnlineStatus(): void {
    try {
      const currentUser = JSON.parse(localStorage.getItem('smart-user') || 'null');
      if (!currentUser) return;

      const onlineUsers = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ONLINE_USERS) || '{}');
      onlineUsers[currentUser.id] = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEYS.ONLINE_USERS, JSON.stringify(onlineUsers));
    } catch (error) {
      console.error('Error updating online status:', error);
    }
  }

  /**
   * Set user away status
   */
  setUserAway(userId: string): void {
    try {
      const users = this.getChatUsers();
      const userIndex = users.findIndex(u => u.id === userId);
      if (userIndex >= 0) {
        users[userIndex].status = 'away';
        localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));
      }
    } catch (error) {
      console.error('Error setting user away:', error);
    }
  }

  /**
   * Set typing status
   */
  setTyping(userId: string, isTyping: boolean, conversationWith?: string, roomId?: string): void {
    try {
      const typingData = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.TYPING) || '{}');
      const key = roomId || conversationWith || 'general';
      
      if (!typingData[key]) {
        typingData[key] = {};
      }

      if (isTyping) {
        typingData[key][userId] = new Date().toISOString();
        
        // Clear typing after 3 seconds
        if (this.typingTimeouts[`${key}-${userId}`]) {
          clearTimeout(this.typingTimeouts[`${key}-${userId}`]);
        }
        
        this.typingTimeouts[`${key}-${userId}`] = setTimeout(() => {
          this.setTyping(userId, false, conversationWith, roomId);
        }, 3000);
      } else {
        delete typingData[key][userId];
        if (this.typingTimeouts[`${key}-${userId}`]) {
          clearTimeout(this.typingTimeouts[`${key}-${userId}`]);
          delete this.typingTimeouts[`${key}-${userId}`];
        }
      }

      localStorage.setItem(this.STORAGE_KEYS.TYPING, JSON.stringify(typingData));
    } catch (error) {
      console.error('Error setting typing status:', error);
    }
  }

  /**
   * Get typing users
   */
  getTypingUsers(conversationWith?: string, roomId?: string): string[] {
    try {
      const typingData = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.TYPING) || '{}');
      const key = roomId || conversationWith || 'general';
      
      if (!typingData[key]) return [];

      const now = Date.now();
      const typingUsers: string[] = [];

      Object.entries(typingData[key]).forEach(([userId, timestamp]) => {
        if (now - new Date(timestamp as string).getTime() < 5000) { // 5 seconds
          typingUsers.push(userId);
        }
      });

      return typingUsers;
    } catch (error) {
      console.error('Error getting typing users:', error);
      return [];
    }
  }

  /**
   * Send Telegram notification for important messages
   */
  private async sendTelegramNotification(message: ChatMessage): Promise<void> {
    try {
      // Only send Telegram notifications for admin messages or high-priority conversations
      if (message.fromUserRole === 'admin' || message.toUserId === 'admin-1') {
        await telegramBot.trackChatMessage(
          formatUserForTelegram({
            id: message.fromUserId,
            name: message.fromUserName,
            email: message.fromUserEmail,
            role: message.fromUserRole
          }),
          message.message,
          message.toUserId || 'Group Chat'
        );
      }
    } catch (error) {
      console.error('Error sending Telegram notification:', error);
    }
  }

  /**
   * Search messages
   */
  searchMessages(query: string, userId?: string, roomId?: string): ChatMessage[] {
    try {
      const messages = userId || roomId ? 
        this.getConversationMessages(userId || '', undefined, roomId) :
        this.getAllMessages();
      
      const lowercaseQuery = query.toLowerCase();
      
      return messages.filter(msg =>
        msg.message.toLowerCase().includes(lowercaseQuery) ||
        msg.fromUserName.toLowerCase().includes(lowercaseQuery) ||
        msg.fromUserEmail.toLowerCase().includes(lowercaseQuery)
      );
    } catch (error) {
      console.error('Error searching messages:', error);
      return [];
    }
  }

  /**
   * Get chat statistics
   */
  getChatStats(): {
    totalMessages: number;
    totalUsers: number;
    totalRooms: number;
    activeUsers: number;
    unreadMessages: number;
    messagesThisWeek: number;
    averageResponseTime: string;
  } {
    try {
      const messages = this.getAllMessages();
      const users = this.getChatUsers();
      const rooms = this.getAllRooms();
      const oneWeekAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
      
      return {
        totalMessages: messages.length,
        totalUsers: users.length,
        totalRooms: rooms.length,
        activeUsers: users.filter(u => u.isOnline).length,
        unreadMessages: messages.filter(msg => !msg.isRead).length,
        messagesThisWeek: messages.filter(msg => 
          new Date(msg.timestamp).getTime() > oneWeekAgo
        ).length,
        averageResponseTime: '< 2 hours'
      };
    } catch (error) {
      console.error('Error getting chat stats:', error);
      return {
        totalMessages: 0,
        totalUsers: 0,
        totalRooms: 0,
        activeUsers: 0,
        unreadMessages: 0,
        messagesThisWeek: 0,
        averageResponseTime: 'N/A'
      };
    }
  }

  /**
   * Clean up old data
   */
  private cleanupOldData(): void {
    try {
      // Clean up old typing data
      const typingData = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.TYPING) || '{}');
      const now = Date.now();
      
      Object.keys(typingData).forEach(key => {
        Object.keys(typingData[key]).forEach(userId => {
          if (now - new Date(typingData[key][userId]).getTime() > 10000) { // 10 seconds
            delete typingData[key][userId];
          }
        });
        
        if (Object.keys(typingData[key]).length === 0) {
          delete typingData[key];
        }
      });
      
      localStorage.setItem(this.STORAGE_KEYS.TYPING, JSON.stringify(typingData));

      // Clean up old online status
      const onlineUsers = JSON.parse(localStorage.getItem(this.STORAGE_KEYS.ONLINE_USERS) || '{}');
      Object.keys(onlineUsers).forEach(userId => {
        if (now - new Date(onlineUsers[userId]).getTime() > 5 * 60 * 1000) { // 5 minutes
          delete onlineUsers[userId];
        }
      });
      localStorage.setItem(this.STORAGE_KEYS.ONLINE_USERS, JSON.stringify(onlineUsers));
    } catch (error) {
      console.error('Error cleaning up old data:', error);
    }
  }

  /**
   * Subscribe to new messages
   */
  onNewMessage(callback: (message: ChatMessage) => void): () => void {
    this.messageCallbacks.push(callback);
    return () => {
      const index = this.messageCallbacks.indexOf(callback);
      if (index > -1) {
        this.messageCallbacks.splice(index, 1);
      }
    };
  }

  /**
   * Subscribe to new notifications
   */
  onNewNotification(callback: (notification: NotificationData) => void): () => void {
    this.notificationCallbacks.push(callback);
    return () => {
      const index = this.notificationCallbacks.indexOf(callback);
      if (index > -1) {
        this.notificationCallbacks.splice(index, 1);
      }
    };
  }

  /**
   * Export chat data
   */
  exportChatData(): {
    messages: ChatMessage[];
    rooms: ChatRoom[];
    users: ChatUser[];
    exportedAt: string;
  } {
    return {
      messages: this.getAllMessages(),
      rooms: this.getAllRooms(),
      users: this.getChatUsers(),
      exportedAt: new Date().toISOString()
    };
  }
}

// Export singleton instance
export const chatManager = new ChatManager();

// Initialize chat system
chatManager.initialize();

// Export types
export type { ChatMessage, ChatRoom, ChatUser, NotificationData };