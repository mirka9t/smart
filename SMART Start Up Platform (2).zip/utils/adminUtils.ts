import { telegramBot, formatUserForTelegram } from './telegramBot';
import { notifications } from './notifications';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin' | 'moderator';
  status: 'active' | 'suspended' | 'pending' | 'banned';
  createdAt: string;
  lastLogin: string;
  profileCompleteness: number;
  permissions?: string[];
  loginAttempts?: number;
  lastActivity?: string;
  ipAddress?: string;
  device?: string;
  metadata?: Record<string, any>;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'critical';
  category: string;
  message: string;
  userId?: string;
  metadata?: Record<string, any>;
}

export interface PlatformMetrics {
  totalUsers: number;
  activeUsers: number;
  newUsersToday: number;
  totalSessions: number;
  averageSessionDuration: number;
  totalPageViews: number;
  totalErrors: number;
  systemUptime: number;
  databaseSize: number;
  serverLoad: number;
}

export interface SecurityEvent {
  id: string;
  timestamp: string;
  type: 'login_attempt' | 'login_success' | 'login_failure' | 'password_reset' | 'account_locked' | 'suspicious_activity';
  userId?: string;
  email?: string;
  ipAddress: string;
  userAgent: string;
  location?: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  details: Record<string, any>;
}

class AdminManager {
  private readonly STORAGE_KEYS = {
    USERS: 'smart-admin-users',
    LOGS: 'smart-system-logs',
    SETTINGS: 'smart-platform-settings',
    METRICS: 'smart-platform-metrics',
    SECURITY_EVENTS: 'smart-security-events',
    FEATURE_FLAGS: 'smart-feature-flags',
    BACKUP_DATA: 'smart-backup-data'
  };

  /**
   * User Management Functions
   */
  async createUser(userData: Partial<AdminUser>, adminUser: any): Promise<AdminUser> {
    try {
      const newUser: AdminUser = {
        id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        email: userData.email!,
        name: userData.name!,
        role: userData.role || 'user',
        status: 'active',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        profileCompleteness: 30,
        permissions: userData.permissions || ['read'],
        loginAttempts: 0,
        lastActivity: new Date().toISOString(),
        ipAddress: '0.0.0.0',
        device: 'Created by admin',
        metadata: {
          createdBy: adminUser.email,
          source: 'admin_panel'
        }
      };

      const users = this.getAllUsers();
      users.push(newUser);
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));

      // Log the action
      await this.logSystemEvent('info', 'User Management', `Created user: ${newUser.email}`, adminUser.id);

      // Track in Telegram
      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        'User Created',
        {
          userEmail: newUser.email,
          userName: newUser.name,
          role: newUser.role
        }
      );

      return newUser;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async updateUser(userId: string, updates: Partial<AdminUser>, adminUser: any): Promise<boolean> {
    try {
      const users = this.getAllUsers();
      const userIndex = users.findIndex(u => u.id === userId);
      
      if (userIndex === -1) {
        throw new Error('User not found');
      }

      const originalUser = { ...users[userIndex] };
      users[userIndex] = { ...users[userIndex], ...updates };
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));

      // Log the changes
      const changes = Object.keys(updates).map(key => `${key}: ${originalUser[key as keyof AdminUser]} → ${updates[key as keyof AdminUser]}`);
      await this.logSystemEvent('info', 'User Management', `Updated user ${originalUser.email}: ${changes.join(', ')}`, adminUser.id);

      // Track in Telegram
      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        'User Updated',
        {
          userEmail: originalUser.email,
          changes: updates
        }
      );

      return true;
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }

  async deleteUser(userId: string, adminUser: any): Promise<boolean> {
    try {
      const users = this.getAllUsers();
      const userIndex = users.findIndex(u => u.id === userId);
      
      if (userIndex === -1) {
        throw new Error('User not found');
      }

      const deletedUser = users[userIndex];
      users.splice(userIndex, 1);
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(users));

      // Log the action
      await this.logSystemEvent('warning', 'User Management', `Deleted user: ${deletedUser.email}`, adminUser.id);

      // Track in Telegram
      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        '🗑️ User Deleted',
        {
          userEmail: deletedUser.email,
          userName: deletedUser.name,
          warning: 'User data permanently removed'
        }
      );

      return true;
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  }

  getAllUsers(): AdminUser[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.USERS);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting users:', error);
      return [];
    }
  }

  getUserById(userId: string): AdminUser | null {
    const users = this.getAllUsers();
    return users.find(u => u.id === userId) || null;
  }

  getUserByEmail(email: string): AdminUser | null {
    const users = this.getAllUsers();
    return users.find(u => u.email === email) || null;
  }

  /**
   * System Logging Functions
   */
  async logSystemEvent(
    level: SystemLog['level'],
    category: string,
    message: string,
    userId?: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    try {
      const newLog: SystemLog = {
        id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date().toISOString(),
        level,
        category,
        message,
        userId,
        metadata: {
          ...metadata,
          userAgent: navigator.userAgent,
          url: window.location.href
        }
      };

      const logs = this.getSystemLogs();
      logs.unshift(newLog); // Add to beginning
      
      // Keep only last 10000 logs
      const trimmedLogs = logs.slice(0, 10000);
      localStorage.setItem(this.STORAGE_KEYS.LOGS, JSON.stringify(trimmedLogs));

      // Send critical logs to Telegram immediately
      if (level === 'critical' || level === 'error') {
        await telegramBot.trackError(
          userId ? this.getUserById(userId) : null,
          message,
          window.location.pathname
        );
      }
    } catch (error) {
      console.error('Error logging system event:', error);
    }
  }

  getSystemLogs(): SystemLog[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.LOGS);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting system logs:', error);
      return [];
    }
  }

  getLogsByLevel(level: SystemLog['level']): SystemLog[] {
    return this.getSystemLogs().filter(log => log.level === level);
  }

  getLogsByCategory(category: string): SystemLog[] {
    return this.getSystemLogs().filter(log => log.category === category);
  }

  getLogsByTimeRange(startTime: string, endTime: string): SystemLog[] {
    const start = new Date(startTime).getTime();
    const end = new Date(endTime).getTime();
    
    return this.getSystemLogs().filter(log => {
      const logTime = new Date(log.timestamp).getTime();
      return logTime >= start && logTime <= end;
    });
  }

  /**
   * Platform Metrics Functions
   */
  async updateMetrics(): Promise<PlatformMetrics> {
    try {
      const users = this.getAllUsers();
      const logs = this.getSystemLogs();
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      const metrics: PlatformMetrics = {
        totalUsers: users.length,
        activeUsers: users.filter(u => u.status === 'active').length,
        newUsersToday: users.filter(u => new Date(u.createdAt) >= todayStart).length,
        totalSessions: users.reduce((acc, u) => acc + (u.loginAttempts || 0), 0),
        averageSessionDuration: 45, // Mock data - would be calculated from real session data
        totalPageViews: logs.filter(l => l.category === 'Page View').length,
        totalErrors: logs.filter(l => l.level === 'error' || l.level === 'critical').length,
        systemUptime: 99.5, // Mock data - would be calculated from system monitoring
        databaseSize: 125.7, // Mock data in MB
        serverLoad: 34.2 // Mock data as percentage
      };

      localStorage.setItem(this.STORAGE_KEYS.METRICS, JSON.stringify({
        ...metrics,
        lastUpdated: new Date().toISOString()
      }));

      return metrics;
    } catch (error) {
      console.error('Error updating metrics:', error);
      throw error;
    }
  }

  getMetrics(): PlatformMetrics | null {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.METRICS);
      return stored ? JSON.parse(stored) : null;
    } catch (error) {
      console.error('Error getting metrics:', error);
      return null;
    }
  }

  /**
   * Security Functions
   */
  async logSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): Promise<void> {
    try {
      const securityEvent: SecurityEvent = {
        id: `sec-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date().toISOString(),
        ...event
      };

      const events = this.getSecurityEvents();
      events.unshift(securityEvent);
      
      // Keep only last 5000 security events
      const trimmedEvents = events.slice(0, 5000);
      localStorage.setItem(this.STORAGE_KEYS.SECURITY_EVENTS, JSON.stringify(trimmedEvents));

      // Alert on high-risk events
      if (event.riskLevel === 'high' || event.riskLevel === 'critical') {
        await this.logSystemEvent('warning', 'Security', `High-risk security event: ${event.type}`, event.userId);
        
        // Send immediate Telegram notification
        await telegramBot.trackAdminAction(
          { id: 'system', email: 'system@smart.com', name: 'Security System', role: 'system' },
          '🚨 Security Alert',
          {
            type: event.type,
            riskLevel: event.riskLevel,
            userEmail: event.email,
            ipAddress: event.ipAddress,
            details: event.details
          }
        );
      }
    } catch (error) {
      console.error('Error logging security event:', error);
    }
  }

  getSecurityEvents(): SecurityEvent[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEYS.SECURITY_EVENTS);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error getting security events:', error);
      return [];
    }
  }

  getHighRiskEvents(): SecurityEvent[] {
    return this.getSecurityEvents().filter(event => 
      event.riskLevel === 'high' || event.riskLevel === 'critical'
    );
  }

  /**
   * Data Export Functions
   */
  async exportData(type: 'users' | 'logs' | 'metrics' | 'security' | 'all', adminUser: any): Promise<string> {
    try {
      let data: any = {};
      const timestamp = new Date().toISOString();

      switch (type) {
        case 'users':
          data = {
            users: this.getAllUsers(),
            exportedAt: timestamp,
            exportedBy: adminUser.email
          };
          break;
        case 'logs':
          data = {
            logs: this.getSystemLogs(),
            exportedAt: timestamp,
            exportedBy: adminUser.email
          };
          break;
        case 'metrics':
          data = {
            metrics: this.getMetrics(),
            exportedAt: timestamp,
            exportedBy: adminUser.email
          };
          break;
        case 'security':
          data = {
            securityEvents: this.getSecurityEvents(),
            exportedAt: timestamp,
            exportedBy: adminUser.email
          };
          break;
        case 'all':
          data = {
            users: this.getAllUsers(),
            logs: this.getSystemLogs(),
            metrics: this.getMetrics(),
            securityEvents: this.getSecurityEvents(),
            exportedAt: timestamp,
            exportedBy: adminUser.email
          };
          break;
      }

      // Log the export
      await this.logSystemEvent('info', 'Data Export', `Exported ${type} data`, adminUser.id);

      // Track in Telegram
      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        'Data Export',
        {
          type,
          timestamp,
          recordCount: type === 'all' ? 'multiple' : Object.keys(data[type] || {}).length
        }
      );

      return JSON.stringify(data, null, 2);
    } catch (error) {
      console.error('Error exporting data:', error);
      throw error;
    }
  }

  /**
   * Backup Functions
   */
  async createBackup(adminUser: any): Promise<boolean> {
    try {
      const backupData = {
        users: this.getAllUsers(),
        logs: this.getSystemLogs(),
        metrics: this.getMetrics(),
        securityEvents: this.getSecurityEvents(),
        settings: JSON.parse(localStorage.getItem(this.STORAGE_KEYS.SETTINGS) || '{}'),
        featureFlags: JSON.parse(localStorage.getItem(this.STORAGE_KEYS.FEATURE_FLAGS) || '{}'),
        createdAt: new Date().toISOString(),
        createdBy: adminUser.email
      };

      localStorage.setItem(this.STORAGE_KEYS.BACKUP_DATA, JSON.stringify(backupData));

      await this.logSystemEvent('info', 'Backup', 'System backup created', adminUser.id);

      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        '💾 Backup Created',
        {
          timestamp: backupData.createdAt,
          size: JSON.stringify(backupData).length + ' bytes'
        }
      );

      return true;
    } catch (error) {
      console.error('Error creating backup:', error);
      throw error;
    }
  }

  async restoreBackup(backupData: string, adminUser: any): Promise<boolean> {
    try {
      const data = JSON.parse(backupData);
      
      // Validate backup data structure
      if (!data.users || !Array.isArray(data.users)) {
        throw new Error('Invalid backup data structure');
      }

      // Restore data
      localStorage.setItem(this.STORAGE_KEYS.USERS, JSON.stringify(data.users));
      localStorage.setItem(this.STORAGE_KEYS.LOGS, JSON.stringify(data.logs || []));
      localStorage.setItem(this.STORAGE_KEYS.SECURITY_EVENTS, JSON.stringify(data.securityEvents || []));
      localStorage.setItem(this.STORAGE_KEYS.SETTINGS, JSON.stringify(data.settings || {}));
      localStorage.setItem(this.STORAGE_KEYS.FEATURE_FLAGS, JSON.stringify(data.featureFlags || {}));

      await this.logSystemEvent('warning', 'Backup', 'System restored from backup', adminUser.id);

      await telegramBot.trackAdminAction(
        formatUserForTelegram(adminUser),
        '🔄 System Restored',
        {
          backupDate: data.createdAt,
          restoredBy: adminUser.email,
          warning: 'System data has been restored from backup'
        }
      );

      return true;
    } catch (error) {
      console.error('Error restoring backup:', error);
      throw error;
    }
  }

  /**
   * Analytics Functions
   */
  getUserGrowthData(days: number = 30): { date: string; count: number }[] {
    const users = this.getAllUsers();
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - (days * 24 * 60 * 60 * 1000));
    
    const growthData: { date: string; count: number }[] = [];
    
    for (let i = 0; i < days; i++) {
      const date = new Date(startDate.getTime() + (i * 24 * 60 * 60 * 1000));
      const dateStr = date.toISOString().split('T')[0];
      const count = users.filter(u => u.createdAt.split('T')[0] === dateStr).length;
      
      growthData.push({ date: dateStr, count });
    }
    
    return growthData;
  }

  getActivityData(hours: number = 24): { hour: string; activity: number }[] {
    const logs = this.getSystemLogs();
    const endTime = new Date();
    const startTime = new Date(endTime.getTime() - (hours * 60 * 60 * 1000));
    
    const activityData: { hour: string; activity: number }[] = [];
    
    for (let i = 0; i < hours; i++) {
      const hour = new Date(startTime.getTime() + (i * 60 * 60 * 1000));
      const hourStr = hour.toISOString().split('T')[1].split(':')[0];
      const activity = logs.filter(log => {
        const logHour = new Date(log.timestamp).toISOString().split('T')[1].split(':')[0];
        return logHour === hourStr;
      }).length;
      
      activityData.push({ hour: hourStr, activity });
    }
    
    return activityData;
  }

  getTopErrors(limit: number = 10): { message: string; count: number; lastOccurred: string }[] {
    const errorLogs = this.getLogsByLevel('error');
    const errorCounts: { [key: string]: { count: number; lastOccurred: string } } = {};
    
    errorLogs.forEach(log => {
      if (errorCounts[log.message]) {
        errorCounts[log.message].count++;
        if (log.timestamp > errorCounts[log.message].lastOccurred) {
          errorCounts[log.message].lastOccurred = log.timestamp;
        }
      } else {
        errorCounts[log.message] = { count: 1, lastOccurred: log.timestamp };
      }
    });
    
    return Object.entries(errorCounts)
      .map(([message, data]) => ({ message, ...data }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  /**
   * Health Check Functions
   */
  async performHealthCheck(): Promise<{
    status: 'healthy' | 'warning' | 'critical';
    checks: { name: string; status: boolean; message: string }[];
    score: number;
  }> {
    const checks = [
      {
        name: 'Local Storage',
        status: this.checkLocalStorage(),
        message: this.checkLocalStorage() ? 'Local storage is accessible' : 'Local storage error'
      },
      {
        name: 'User Data',
        status: this.getAllUsers().length > 0,
        message: this.getAllUsers().length > 0 ? 'User data loaded' : 'No user data found'
      },
      {
        name: 'System Logs',
        status: this.getSystemLogs().length >= 0,
        message: 'System logging operational'
      },
      {
        name: 'Telegram Integration',
        status: await this.checkTelegramConnection(),
        message: await this.checkTelegramConnection() ? 'Telegram bot connected' : 'Telegram connection failed'
      }
    ];

    const passedChecks = checks.filter(c => c.status).length;
    const score = Math.round((passedChecks / checks.length) * 100);
    
    let status: 'healthy' | 'warning' | 'critical' = 'healthy';
    if (score < 50) status = 'critical';
    else if (score < 80) status = 'warning';

    return { status, checks, score };
  }

  private checkLocalStorage(): boolean {
    try {
      const test = '__test__';
      localStorage.setItem(test, test);
      localStorage.removeItem(test);
      return true;
    } catch {
      return false;
    }
  }

  private async checkTelegramConnection(): Promise<boolean> {
    try {
      return await telegramBot.sendTestMessage();
    } catch {
      return false;
    }
  }
}

// Export singleton instance
export const adminManager = new AdminManager();

// Export types
export type { AdminUser, SystemLog, PlatformMetrics, SecurityEvent };