import React, { useState, useEffect } from 'react';
import { HamburgerNavigation } from './HamburgerNavigation';
import { useAuth } from '../contexts/AuthContext';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';
import { Loader2 } from 'lucide-react';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface Route {
  path: string;
  component: React.ComponentType<any>;
  title: string;
  requiresAuth?: boolean;
  requiresAdmin?: boolean;
}

interface RouterProps {
  routes: Route[];
  children?: React.ReactNode;
}

export function Router({ routes, children }: RouterProps) {
  const [currentPath, setCurrentPath] = useState(() => window.location.pathname);
  const { user, isAuthenticated, isAdmin, loading: authLoading } = useAuth();

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = async (path: string) => {
    if (path !== currentPath) {
      setCurrentPath(path);
      window.history.pushState({}, '', path);
      
      // Update document title
      const route = routes.find(r => r.path === path);
      if (route) {
        document.title = `${route.title} | SMART Start Up`;
        
        // Track page navigation for authenticated users
        if (user) {
          await telegramBot.trackPageView(
            formatUserForTelegram(user), 
            route.title, 
            path
          );
        }
      }
      
      // Scroll to top
      window.scrollTo(0, 0);
    }
  };

  // Show loading screen while auth is loading
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 mb-6 mx-auto">
            <img 
              src={smartLogo} 
              alt="SMART Start Up" 
              className="w-full h-full object-contain animate-pulse"
            />
          </div>
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Loading SMART Start Up...</p>
          <p className="text-xs text-muted-foreground mt-2">Initializing authentication...</p>
        </div>
      </div>
    );
  }

  // Find current route - always find a route to avoid conditional rendering
  const currentRoute = routes.find(route => route.path === currentPath) || routes[0];

  // Check authentication requirements - but don't redirect here to avoid hook issues
  const canAccessRoute = () => {
    if (currentRoute.requiresAdmin && !isAdmin) {
      return false;
    }
    if (currentRoute.requiresAuth && !isAuthenticated) {
      return false;
    }
    return true;
  };

  const hasAccess = canAccessRoute();

  // Get the component to render
  const getComponentToRender = () => {
    if (hasAccess) {
      return currentRoute.component;
    }
    
    // Return a simple access denied component instead of redirecting
    return () => (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={smartLogo} 
              alt="SMART Start Up" 
              className="w-full h-full object-contain opacity-50"
            />
          </div>
          <h2 className="text-2xl font-semibold mb-2">Access Denied</h2>
          <p className="text-muted-foreground mb-4">
            {currentRoute.requiresAdmin 
              ? 'This page requires admin access.' 
              : 'Please sign in to access this page.'
            }
          </p>
          <button 
            onClick={() => navigate('/')}
            className="btn-primary"
          >
            Go Home
          </button>
        </div>
      </div>
    );
  };

  const CurrentComponent = getComponentToRender();

  return (
    <div className="min-h-screen bg-background">
      <HamburgerNavigation currentPath={currentPath} onNavigate={navigate} />
      <main className="min-h-[calc(100vh-4rem)]">
        <CurrentComponent />
      </main>
      {children}
    </div>
  );
}