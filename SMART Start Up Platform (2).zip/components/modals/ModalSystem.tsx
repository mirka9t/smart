import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { 
  X, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  MessageCircle, 
  Calendar, 
  UserPlus, 
  Building, 
  Download, 
  Share2, 
  Award,
  MapPin,
  Clock,
  Users,
  DollarSign,
  GraduationCap,
  Target
} from 'lucide-react';

interface Modal {
  id: string;
  type: string;
  title: string;
  description?: string;
  data?: any;
  onConfirm?: (data?: any) => void;
  onCancel?: () => void;
}

interface ModalContextType {
  openModal: (modal: Omit<Modal, 'id'>) => void;
  closeModal: (id?: string) => void;
  closeAllModals: () => void;
}

const ModalContext = createContext<ModalContextType | null>(null);

export const useModal = () => {
  const context = useContext(ModalContext);
  if (!context) {
    throw new Error('useModal must be used within a ModalProvider');
  }
  return context;
};

export function ModalProvider({ children }: { children: ReactNode }) {
  const [modals, setModals] = useState<Modal[]>([]);

  const openModal = (modal: Omit<Modal, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    setModals(prev => [...prev, { ...modal, id }]);
  };

  const closeModal = (id?: string) => {
    if (id) {
      setModals(prev => prev.filter(modal => modal.id !== id));
    } else {
      setModals(prev => prev.slice(0, -1));
    }
  };

  const closeAllModals = () => {
    setModals([]);
  };

  return (
    <ModalContext.Provider value={{ openModal, closeModal, closeAllModals }}>
      {children}
      {modals.map(modal => (
        <ModalRenderer key={modal.id} modal={modal} onClose={() => closeModal(modal.id)} />
      ))}
    </ModalContext.Provider>
  );
}

function ModalRenderer({ modal, onClose }: { modal: Modal; onClose: () => void }) {
  const [formData, setFormData] = useState<Record<string, any>>(modal.data || {});
  const [loading, setLoading] = useState(false);

  const handleConfirm = async () => {
    if (modal.onConfirm) {
      setLoading(true);
      try {
        await modal.onConfirm(formData);
        onClose();
      } catch (error) {
        console.error('Modal confirm error:', error);
      } finally {
        setLoading(false);
      }
    } else {
      onClose();
    }
  };

  const handleCancel = () => {
    if (modal.onCancel) {
      modal.onCancel();
    }
    onClose();
  };

  const updateFormData = (key: string, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const renderContent = () => {
    switch (modal.type) {
      case 'confirm':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-500" />
              <div>
                <p className="font-medium">{modal.title}</p>
                <p className="text-sm text-muted-foreground">{modal.description}</p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading}>
                {loading ? 'Processing...' : 'Confirm'}
              </Button>
            </div>
          </div>
        );

      case 'apply-funding':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <DollarSign className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Apply for {modal.data?.opportunityName}</h3>
                <p className="text-sm text-muted-foreground">Submit your funding application</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="startupName">Startup Name</Label>
                <Input
                  id="startupName"
                  placeholder="Your startup name"
                  value={formData.startupName || ''}
                  onChange={(e) => updateFormData('startupName', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="foundersName">Lead Founder Name</Label>
                <Input
                  id="foundersName"
                  placeholder="Your full name"
                  value={formData.foundersName || ''}
                  onChange={(e) => updateFormData('foundersName', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="email">Contact Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email || ''}
                  onChange={(e) => updateFormData('email', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="description">Startup Description</Label>
                <Textarea
                  id="description"
                  placeholder="Briefly describe your startup, the problem you're solving, and your solution..."
                  rows={4}
                  value={formData.description || ''}
                  onChange={(e) => updateFormData('description', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="stage">Current Stage</Label>
                <select
                  id="stage"
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.stage || ''}
                  onChange={(e) => updateFormData('stage', e.target.value)}
                >
                  <option value="">Select current stage</option>
                  <option value="idea">Idea Stage</option>
                  <option value="prototype">Prototype/MVP</option>
                  <option value="early-revenue">Early Revenue</option>
                  <option value="growth">Growth Stage</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="fundingAmount">Funding Amount Requested</Label>
                <Input
                  id="fundingAmount"
                  placeholder="e.g., $50,000"
                  value={formData.fundingAmount || ''}
                  onChange={(e) => updateFormData('fundingAmount', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="useOfFunds">How will you use the funding?</Label>
                <Textarea
                  id="useOfFunds"
                  placeholder="Describe how you plan to use the funding to grow your startup..."
                  rows={3}
                  value={formData.useOfFunds || ''}
                  onChange={(e) => updateFormData('useOfFunds', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="traction">Current Traction</Label>
                <Textarea
                  id="traction"
                  placeholder="Describe your current traction, customers, revenue, or other key metrics..."
                  rows={3}
                  value={formData.traction || ''}
                  onChange={(e) => updateFormData('traction', e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading || !formData.startupName || !formData.foundersName || !formData.email || !formData.description}>
                {loading ? 'Submitting...' : 'Submit Application'}
              </Button>
            </div>
          </div>
        );

      case 'program-details':
        const program = modal.data?.program;
        return (
          <div className="space-y-6 max-h-[70vh] overflow-y-auto">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Building className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">{program?.name}</h3>
                <p className="text-sm text-muted-foreground capitalize">{program?.type}</p>
              </div>
            </div>

            <p className="text-muted-foreground">{program?.description}</p>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span>{program?.duration}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span>{program?.cohortSize} startups</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <DollarSign className="w-4 h-4 text-muted-foreground" />
                <span>{program?.funding}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>{program?.location}</span>
              </div>
            </div>

            {/* Curriculum */}
            <div>
              <h4 className="font-medium mb-3">Curriculum</h4>
              <div className="grid grid-cols-2 gap-2">
                {program?.curriculum?.map((topic: string, index: number) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <GraduationCap className="w-3 h-3 text-muted-foreground" />
                    <span>{topic}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Benefits */}
            <div>
              <h4 className="font-medium mb-3">Benefits</h4>
              <div className="space-y-2">
                {program?.benefits?.map((benefit: string, index: number) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-3 h-3 text-green-600" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Requirements */}
            <div>
              <h4 className="font-medium mb-3">Requirements</h4>
              <div className="space-y-2">
                {program?.requirements?.map((requirement: string, index: number) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <Info className="w-3 h-3 text-blue-600" />
                    <span>{requirement}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Important Dates */}
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-3">Important Dates</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Application Deadline:</span>
                  <span className="font-medium">{program?.applicationDeadline}</span>
                </div>
                <div className="flex justify-between">
                  <span>Program Starts:</span>
                  <span className="font-medium">{program?.startDate}</span>
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button 
                className="flex-1 btn-primary"
                onClick={() => {
                  onClose();
                  // Trigger apply modal
                  setTimeout(() => {
                    // This would be handled by the parent component
                    console.log('Apply to program:', program?.id);
                  }, 100);
                }}
                disabled={!program?.isAcceptingApplications}
              >
                {program?.isAcceptingApplications ? 'Apply Now' : 'Applications Closed'}
              </Button>
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
            </div>
          </div>
        );

      case 'contact-mentor':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <MessageCircle className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Contact {modal.data?.mentorName}</h3>
                <p className="text-sm text-muted-foreground">Send a message to this mentor</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="What would you like to discuss?"
                  value={formData.subject || ''}
                  onChange={(e) => updateFormData('subject', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Tell the mentor about your startup and what kind of help you need..."
                  rows={4}
                  value={formData.message || ''}
                  onChange={(e) => updateFormData('message', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="availability">Your Availability</Label>
                <Input
                  id="availability"
                  placeholder="e.g., Weekday evenings, weekends"
                  value={formData.availability || ''}
                  onChange={(e) => updateFormData('availability', e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading || !formData.subject || !formData.message}>
                {loading ? 'Sending...' : 'Send Message'}
              </Button>
            </div>
          </div>
        );

      case 'book-session':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Calendar className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Book Session with {modal.data?.mentorName}</h3>
                <p className="text-sm text-muted-foreground">Schedule a mentoring session</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="sessionType">Session Type</Label>
                <select
                  id="sessionType"
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.sessionType || ''}
                  onChange={(e) => updateFormData('sessionType', e.target.value)}
                >
                  <option value="">Select session type</option>
                  <option value="1-on-1">1-on-1 Mentoring (60 min)</option>
                  <option value="pitch-review">Pitch Review (45 min)</option>
                  <option value="strategy">Strategy Session (90 min)</option>
                  <option value="quick-chat">Quick Chat (30 min)</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="preferredDate">Preferred Date</Label>
                <Input
                  id="preferredDate"
                  type="date"
                  value={formData.preferredDate || ''}
                  onChange={(e) => updateFormData('preferredDate', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="preferredTime">Preferred Time</Label>
                <Input
                  id="preferredTime"
                  type="time"
                  value={formData.preferredTime || ''}
                  onChange={(e) => updateFormData('preferredTime', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="sessionGoals">What would you like to achieve in this session?</Label>
                <Textarea
                  id="sessionGoals"
                  placeholder="Describe your goals for this mentoring session..."
                  rows={3}
                  value={formData.sessionGoals || ''}
                  onChange={(e) => updateFormData('sessionGoals', e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading || !formData.sessionType || !formData.preferredDate}>
                {loading ? 'Booking...' : 'Book Session'}
              </Button>
            </div>
          </div>
        );

      case 'apply-program':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Building className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Apply to {modal.data?.programName}</h3>
                <p className="text-sm text-muted-foreground">Submit your application</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="startupName">Startup Name</Label>
                <Input
                  id="startupName"
                  placeholder="Your startup name"
                  value={formData.startupName || ''}
                  onChange={(e) => updateFormData('startupName', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="description">Startup Description</Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of your startup..."
                  rows={3}
                  value={formData.description || ''}
                  onChange={(e) => updateFormData('description', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="stage">Current Stage</Label>
                <select
                  id="stage"
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.stage || ''}
                  onChange={(e) => updateFormData('stage', e.target.value)}
                >
                  <option value="">Select stage</option>
                  <option value="idea">Idea Stage</option>
                  <option value="mvp">MVP Stage</option>
                  <option value="scaling">Scaling Stage</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="motivation">Why do you want to join this program?</Label>
                <Textarea
                  id="motivation"
                  placeholder="Explain your motivation and what you hope to achieve..."
                  rows={4}
                  value={formData.motivation || ''}
                  onChange={(e) => updateFormData('motivation', e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading || !formData.startupName || !formData.description}>
                {loading ? 'Submitting...' : 'Submit Application'}
              </Button>
            </div>
          </div>
        );

      case 'apply-mentor':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Award className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Apply to Become a Mentor</h3>
                <p className="text-sm text-muted-foreground">Share your expertise with student founders</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  placeholder="Your full name"
                  value={formData.fullName || ''}
                  onChange={(e) => updateFormData('fullName', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="currentTitle">Current Title & Company</Label>
                <Input
                  id="currentTitle"
                  placeholder="e.g., VP Product at TechCorp"
                  value={formData.currentTitle || ''}
                  onChange={(e) => updateFormData('currentTitle', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="expertise">Areas of Expertise</Label>
                <Input
                  id="expertise"
                  placeholder="e.g., Product Management, Fundraising, Marketing"
                  value={formData.expertise || ''}
                  onChange={(e) => updateFormData('expertise', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="experience">Professional Experience</Label>
                <Textarea
                  id="experience"
                  placeholder="Brief overview of your professional background and achievements..."
                  rows={4}
                  value={formData.experience || ''}
                  onChange={(e) => updateFormData('experience', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="motivation">Why do you want to mentor student founders?</Label>
                <Textarea
                  id="motivation"
                  placeholder="Share your motivation for helping the next generation of entrepreneurs..."
                  rows={3}
                  value={formData.motivation || ''}
                  onChange={(e) => updateFormData('motivation', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="availability">Weekly Availability</Label>
                <select
                  id="availability"
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.availability || ''}
                  onChange={(e) => updateFormData('availability', e.target.value)}
                >
                  <option value="">Select availability</option>
                  <option value="1-2 hours">1-2 hours per week</option>
                  <option value="3-5 hours">3-5 hours per week</option>
                  <option value="5+ hours">5+ hours per week</option>
                  <option value="flexible">Flexible</option>
                </select>
              </div>
              
              <div>
                <Label htmlFor="linkedinUrl">LinkedIn Profile URL</Label>
                <Input
                  id="linkedinUrl"
                  placeholder="https://linkedin.com/in/yourprofile"
                  value={formData.linkedinUrl || ''}
                  onChange={(e) => updateFormData('linkedinUrl', e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading || !formData.fullName || !formData.currentTitle || !formData.experience}>
                {loading ? 'Submitting...' : 'Submit Application'}
              </Button>
            </div>
          </div>
        );

      case 'share-content':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Share2 className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Share {modal.data?.contentType}</h3>
                <p className="text-sm text-muted-foreground">Share this content with others</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label>Share Link</Label>
                <div className="flex gap-2">
                  <Input value={modal.data?.url || ''} readOnly className="flex-1" />
                  <Button 
                    variant="outline" 
                    onClick={() => navigator.clipboard.writeText(modal.data?.url || '')}
                  >
                    Copy
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(modal.data?.url || '')}&text=${encodeURIComponent(modal.data?.title || '')}`)}>
                  Share on Twitter
                </Button>
                <Button variant="outline" onClick={() => window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(modal.data?.url || '')}`)}>
                  Share on LinkedIn
                </Button>
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button onClick={handleCancel}>Done</Button>
            </div>
          </div>
        );

      case 'export-data':
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <Download className="w-6 h-6 text-primary" />
              <div>
                <h3 className="font-semibold">Export {modal.data?.dataType}</h3>
                <p className="text-sm text-muted-foreground">Choose export format and options</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label>Export Format</Label>
                <select
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.format || 'csv'}
                  onChange={(e) => updateFormData('format', e.target.value)}
                >
                  <option value="csv">CSV</option>
                  <option value="json">JSON</option>
                  <option value="xlsx">Excel</option>
                </select>
              </div>
              
              <div>
                <Label>Date Range</Label>
                <select
                  className="w-full px-3 py-2 border border-border rounded-md"
                  value={formData.dateRange || 'all'}
                  onChange={(e) => updateFormData('dateRange', e.target.value)}
                >
                  <option value="all">All Time</option>
                  <option value="30d">Last 30 Days</option>
                  <option value="90d">Last 90 Days</option>
                  <option value="1y">Last Year</option>
                </select>
              </div>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleCancel}>Cancel</Button>
              <Button onClick={handleConfirm} disabled={loading}>
                {loading ? 'Exporting...' : 'Export Data'}
              </Button>
            </div>
          </div>
        );

      default:
        return (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Info className="w-6 h-6 text-blue-500" />
              <div>
                <p className="font-medium">{modal.title}</p>
                {modal.description && <p className="text-sm text-muted-foreground">{modal.description}</p>}
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button onClick={handleConfirm}>OK</Button>
            </div>
          </div>
        );
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden">
        {renderContent()}
      </DialogContent>
    </Dialog>
  );
}