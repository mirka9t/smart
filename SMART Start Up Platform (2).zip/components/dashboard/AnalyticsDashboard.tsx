import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useAuth } from '../../contexts/AuthContext';
import { chatManager } from '../../utils/chatUtils';
import { telegramBot, formatUserForTelegram } from '../../utils/telegramBot';
import { notifications } from '../../utils/notifications';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Users,
  MessageCircle,
  Activity,
  Clock,
  Calendar,
  Globe,
  Smartphone,
  Monitor,
  Download,
  Share,
  Filter,
  RefreshCw,
  BarChart3,
  PieChart as PieChartIcon,
  Target,
  Zap,
  Award,
  BookOpen,
  DollarSign,
  Eye,
  MousePointer,
  ThumbsUp,
  AlertCircle
} from 'lucide-react';

interface AnalyticsData {
  overview: {
    totalUsers: number;
    activeUsers: number;
    newUsersToday: number;
    totalSessions: number;
    averageSessionDuration: number;
    totalPageViews: number;
    conversionRate: number;
    retentionRate: number;
  };
  userGrowth: {
    date: string;
    newUsers: number;
    totalUsers: number;
    activeUsers: number;
  }[];
  deviceStats: {
    name: string;
    value: number;
    percentage: number;
    color: string;
  }[];
  locationStats: {
    country: string;
    users: number;
    sessions: number;
    percentage: number;
  }[];
  activityData: {
    hour: string;
    users: number;
    sessions: number;
    messages: number;
  }[];
  featureUsage: {
    feature: string;
    usage: number;
    growth: number;
    trend: 'up' | 'down' | 'stable';
  }[];
  chatMetrics: {
    totalMessages: number;
    activeConversations: number;
    averageResponseTime: number;
    messagesByDay: {
      date: string;
      messages: number;
      users: number;
    }[];
  };
  performanceMetrics: {
    metric: string;
    value: number;
    target: number;
    status: 'good' | 'warning' | 'critical';
    change: number;
  }[];
}

const COLORS = {
  primary: '#f7a524',
  secondary: '#192441',
  success: '#22c55e',
  warning: '#f59e0b',
  error: '#ef4444',
  info: '#3b82f6',
  purple: '#8b5cf6',
  pink: '#ec4899',
  indigo: '#6366f1',
  teal: '#14b8a6'
};

const deviceColors = [COLORS.primary, COLORS.secondary, COLORS.success, COLORS.info];

export function AnalyticsDashboard() {
  const { user, allUsers, trackAction } = useAuth();
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [activeTab, setActiveTab] = useState('overview');
  const [chartType, setChartType] = useState<'line' | 'area' | 'bar'>('line');

  useEffect(() => {
    generateAnalyticsData();
    
    // Track analytics view
    if (user) {
      trackAction('analytics_viewed', { timeRange, tab: activeTab });
    }
  }, [timeRange]);

  const generateAnalyticsData = async () => {
    try {
      setLoading(true);
      
      // Simulate data loading delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const now = new Date();
      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      
      // Generate mock data based on actual system data
      const chatStats = chatManager.getChatStats();
      
      const mockData: AnalyticsData = {
        overview: {
          totalUsers: allUsers.length,
          activeUsers: Math.floor(allUsers.length * 0.65),
          newUsersToday: Math.floor(Math.random() * 5) + 1,
          totalSessions: allUsers.length * 15,
          averageSessionDuration: 24.5,
          totalPageViews: allUsers.length * 45,
          conversionRate: 12.8,
          retentionRate: 78.5
        },
        userGrowth: generateUserGrowthData(daysAgo),
        deviceStats: [
          { name: 'Desktop', value: 65, percentage: 65, color: COLORS.primary },
          { name: 'Mobile', value: 28, percentage: 28, color: COLORS.secondary },
          { name: 'Tablet', value: 7, percentage: 7, color: COLORS.success }
        ],
        locationStats: generateLocationData(),
        activityData: generateActivityData(),
        featureUsage: [
          { feature: 'Deck Generator', usage: 234, growth: 15.2, trend: 'up' },
          { feature: 'Chat System', usage: chatStats.totalMessages, growth: 23.4, trend: 'up' },
          { feature: 'Rehearsal Studio', usage: 156, growth: 8.7, trend: 'up' },
          { feature: 'Mentorship', usage: 89, growth: -2.1, trend: 'down' },
          { feature: 'Resources', usage: 445, growth: 12.3, trend: 'up' },
          { feature: 'Profile', usage: 678, growth: 5.6, trend: 'stable' }
        ],
        chatMetrics: {
          totalMessages: chatStats.totalMessages,
          activeConversations: chatStats.totalUsers,
          averageResponseTime: 2.3,
          messagesByDay: generateChatData(daysAgo)
        },
        performanceMetrics: [
          { metric: 'Page Load Time', value: 1.2, target: 2.0, status: 'good', change: -0.3 },
          { metric: 'API Response Time', value: 180, target: 500, status: 'good', change: -25 },
          { metric: 'Error Rate', value: 0.8, target: 1.0, status: 'good', change: -0.2 },
          { metric: 'Uptime', value: 99.8, target: 99.5, status: 'good', change: 0.1 },
          { metric: 'User Satisfaction', value: 4.6, target: 4.0, status: 'good', change: 0.2 }
        ]
      };
      
      setAnalyticsData(mockData);
    } catch (error) {
      console.error('Error generating analytics data:', error);
      notifications.error('Error', 'Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const generateUserGrowthData = (days: number) => {
    const data = [];
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    let totalUsers = Math.max(1, allUsers.length - days);
    
    for (let i = 0; i < days; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      
      const newUsers = Math.floor(Math.random() * 5) + 1;
      totalUsers += newUsers;
      const activeUsers = Math.floor(totalUsers * (0.6 + Math.random() * 0.2));
      
      data.push({
        date: date.toISOString().split('T')[0],
        newUsers,
        totalUsers,
        activeUsers
      });
    }
    
    return data;
  };

  const generateLocationData = () => {
    const countries = [
      'United States', 'United Kingdom', 'Canada', 'Germany', 'France',
      'Australia', 'India', 'Japan', 'Brazil', 'Netherlands'
    ];
    
    const total = allUsers.length;
    let remaining = total;
    
    return countries.slice(0, 5).map((country, index) => {
      const users = index === 4 ? remaining : Math.floor(remaining * (0.3 - index * 0.05));
      remaining -= users;
      
      return {
        country,
        users,
        sessions: users * Math.floor(Math.random() * 3 + 2),
        percentage: Math.round((users / total) * 100)
      };
    });
  };

  const generateActivityData = () => {
    const data = [];
    for (let hour = 0; hour < 24; hour++) {
      const users = Math.floor(Math.random() * 50) + 10;
      data.push({
        hour: `${hour.toString().padStart(2, '0')}:00`,
        users,
        sessions: Math.floor(users * 1.2),
        messages: Math.floor(users * 0.8)
      });
    }
    return data;
  };

  const generateChatData = (days: number) => {
    const data = [];
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    for (let i = 0; i < days; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      
      data.push({
        date: date.toISOString().split('T')[0],
        messages: Math.floor(Math.random() * 50) + 10,
        users: Math.floor(Math.random() * 20) + 5
      });
    }
    
    return data;
  };

  const exportAnalytics = async () => {
    try {
      if (!analyticsData) return;
      
      const exportData = {
        ...analyticsData,
        exportedAt: new Date().toISOString(),
        exportedBy: user?.email,
        timeRange
      };
      
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-export-${timeRange}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      // Track export
      if (user) {
        await trackAction('analytics_exported', { timeRange, format: 'json' });
        await telegramBot.trackAdminAction(
          formatUserForTelegram(user),
          'Analytics Exported',
          { timeRange, recordCount: analyticsData.userGrowth.length }
        );
      }
      
      notifications.success('Export Complete', 'Analytics data exported successfully');
    } catch (error) {
      console.error('Error exporting analytics:', error);
      notifications.error('Export Failed', 'Failed to export analytics data');
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const formatPercentage = (num: number) => {
    return `${num >= 0 ? '+' : ''}${num.toFixed(1)}%`;
  };

  if (loading || !analyticsData) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
          <div className="animate-pulse bg-muted rounded h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse bg-muted rounded-lg h-32" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold mb-2">Analytics Dashboard</h2>
          <p className="text-muted-foreground">
            Comprehensive insights into platform performance and user behavior
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <Select value={timeRange} onValueChange={(value: any) => setTimeRange(value)}>
            <SelectTrigger className="w-32">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={generateAnalyticsData}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          
          <Button variant="outline" onClick={exportAnalytics}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            title: 'Total Users',
            value: analyticsData.overview.totalUsers,
            change: 12.5,
            icon: Users,
            color: 'text-blue-600'
          },
          {
            title: 'Active Users',
            value: analyticsData.overview.activeUsers,
            change: 8.2,
            icon: Activity,
            color: 'text-green-600'
          },
          {
            title: 'Total Sessions',
            value: analyticsData.overview.totalSessions,
            change: 15.3,
            icon: MousePointer,
            color: 'text-purple-600'
          },
          {
            title: 'Page Views',
            value: analyticsData.overview.totalPageViews,
            change: 23.1,
            icon: Eye,
            color: 'text-orange-600'
          }
        ].map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                    <p className="text-2xl font-bold mb-1">{formatNumber(stat.value)}</p>
                    <div className="flex items-center space-x-1">
                      {stat.change > 0 ? (
                        <TrendingUp className="w-4 h-4 text-green-600" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-600" />
                      )}
                      <span className={`text-sm font-medium ${
                        stat.change > 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {formatPercentage(stat.change)}
                      </span>
                    </div>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color} bg-opacity-10`}>
                    <IconComponent className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Main Analytics Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="real-time">Real-time</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* User Growth Chart */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">User Growth</h3>
                <div className="flex space-x-2">
                  <Button
                    variant={chartType === 'line' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setChartType('line')}
                  >
                    Line
                  </Button>
                  <Button
                    variant={chartType === 'area' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setChartType('area')}
                  >
                    Area
                  </Button>
                  <Button
                    variant={chartType === 'bar' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setChartType('bar')}
                  >
                    Bar
                  </Button>
                </div>
              </div>
              
              <ResponsiveContainer width="100%" height={300}>
                {chartType === 'line' && (
                  <LineChart data={analyticsData.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="totalUsers" 
                      stroke={COLORS.primary} 
                      strokeWidth={2}
                      name="Total Users"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="activeUsers" 
                      stroke={COLORS.success} 
                      strokeWidth={2}
                      name="Active Users"
                    />
                  </LineChart>
                )}
                
                {chartType === 'area' && (
                  <AreaChart data={analyticsData.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="totalUsers" 
                      stackId="1"
                      stroke={COLORS.primary} 
                      fill={COLORS.primary}
                      fillOpacity={0.6}
                      name="Total Users"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="activeUsers" 
                      stackId="2"
                      stroke={COLORS.success} 
                      fill={COLORS.success}
                      fillOpacity={0.6}
                      name="Active Users"
                    />
                  </AreaChart>
                )}
                
                {chartType === 'bar' && (
                  <BarChart data={analyticsData.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="newUsers" fill={COLORS.primary} name="New Users" />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </Card>

            {/* Device Distribution */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Device Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={analyticsData.deviceStats}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percentage }) => `${name} ${percentage}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {analyticsData.deviceStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Activity Heatmap */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Daily Activity Pattern</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={analyticsData.activityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stroke={COLORS.primary} 
                  fill={COLORS.primary}
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Location Stats */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Users by Location</h3>
              <div className="space-y-3">
                {analyticsData.locationStats.map((location, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Globe className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{location.country}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-right">
                        <p className="text-sm font-medium">{location.users}</p>
                        <p className="text-xs text-muted-foreground">{location.percentage}%</p>
                      </div>
                      <div className="w-16 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary rounded-full h-2" 
                          style={{ width: `${location.percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* User Metrics */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">User Metrics</h3>
              <div className="space-y-4">
                {[
                  { label: 'Average Session Duration', value: `${analyticsData.overview.averageSessionDuration} min`, icon: Clock },
                  { label: 'Conversion Rate', value: `${analyticsData.overview.conversionRate}%`, icon: Target },
                  { label: 'Retention Rate', value: `${analyticsData.overview.retentionRate}%`, icon: Award },
                  { label: 'New Users Today', value: analyticsData.overview.newUsersToday, icon: TrendingUp }
                ].map((metric, index) => {
                  const IconComponent = metric.icon;
                  return (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                        <IconComponent className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-muted-foreground">{metric.label}</p>
                        <p className="font-semibold">{metric.value}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Engagement Tab */}
        <TabsContent value="engagement" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Chat Activity</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={analyticsData.chatMetrics.messagesByDay}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="messages" 
                  stackId="1"
                  stroke={COLORS.primary} 
                  fill={COLORS.primary}
                  fillOpacity={0.6}
                  name="Messages"
                />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stackId="2"
                  stroke={COLORS.success} 
                  fill={COLORS.success}
                  fillOpacity={0.6}
                  name="Active Users"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        {/* Features Tab */}
        <TabsContent value="features" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Feature Usage</h3>
            <div className="space-y-4">
              {analyticsData.featureUsage.map((feature, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <BarChart3 className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{feature.feature}</p>
                      <p className="text-sm text-muted-foreground">{feature.usage} uses</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={feature.trend === 'up' ? 'default' : feature.trend === 'down' ? 'destructive' : 'secondary'}>
                      {feature.trend === 'up' && <TrendingUp className="w-3 h-3 mr-1" />}
                      {feature.trend === 'down' && <TrendingDown className="w-3 h-3 mr-1" />}
                      {formatPercentage(feature.growth)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {analyticsData.performanceMetrics.map((metric, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">{metric.metric}</h4>
                  <Badge variant={
                    metric.status === 'good' ? 'default' : 
                    metric.status === 'warning' ? 'secondary' : 'destructive'
                  }>
                    {metric.status}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-2xl font-bold">
                      {metric.metric.includes('Time') ? `${metric.value}s` : 
                       metric.metric.includes('Rate') ? `${metric.value}%` :
                       metric.metric.includes('Satisfaction') ? `${metric.value}/5` : metric.value}
                    </span>
                    <span className={`text-sm font-medium ${metric.change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatPercentage(metric.change)}
                    </span>
                  </div>
                  
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className={`rounded-full h-2 ${
                        metric.status === 'good' ? 'bg-green-500' : 
                        metric.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min((metric.value / metric.target) * 100, 100)}%` }}
                    />
                  </div>
                  
                  <p className="text-xs text-muted-foreground">
                    Target: {metric.target}{metric.metric.includes('Time') ? 's' : metric.metric.includes('Rate') || metric.metric.includes('Uptime') ? '%' : ''}
                  </p>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Real-time Tab */}
        <TabsContent value="real-time" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6 text-center">
              <Activity className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">{analyticsData.overview.activeUsers}</p>
              <p className="text-sm text-muted-foreground">Online Now</p>
            </Card>
            
            <Card className="p-6 text-center">
              <MessageCircle className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">{analyticsData.chatMetrics.activeConversations}</p>
              <p className="text-sm text-muted-foreground">Active Chats</p>
            </Card>
            
            <Card className="p-6 text-center">
              <Eye className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">156</p>
              <p className="text-sm text-muted-foreground">Page Views/Hour</p>
            </Card>
            
            <Card className="p-6 text-center">
              <Clock className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">{analyticsData.chatMetrics.averageResponseTime}h</p>
              <p className="text-sm text-muted-foreground">Avg Response Time</p>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Live Activity Feed</h3>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {[
                { action: 'New user registration', user: 'john@example.com', time: '2 minutes ago' },
                { action: 'Deck generated', user: 'sarah@startup.com', time: '5 minutes ago' },
                { action: 'Chat message sent', user: 'mike@venture.com', time: '7 minutes ago' },
                { action: 'Profile updated', user: 'lisa@tech.co', time: '12 minutes ago' },
                { action: 'Resource downloaded', user: 'alex@innovation.io', time: '15 minutes ago' }
              ].map((activity, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg"
                >
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.action}</p>
                    <p className="text-xs text-muted-foreground">{activity.user}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{activity.time}</span>
                </motion.div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default AnalyticsDashboard;