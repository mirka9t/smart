import React from 'react';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Button } from '../ui/button';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Target, 
  Users, 
  Download, 
  Award, 
  TrendingUp, 
  Calendar,
  BookOpen,
  MessageCircle
} from 'lucide-react';

export function DashboardStats() {
  const { user } = useAuth();

  if (!user) return null;

  const stats = [
    {
      title: 'Applications Submitted',
      value: user.stats.applicationsSubmitted,
      icon: Target,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      change: '+12%',
      changeType: 'positive' as const
    },
    {
      title: 'Mentoring Sessions',
      value: user.stats.mentoringSessions,
      icon: Users,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      change: '+5%',
      changeType: 'positive' as const
    },
    {
      title: 'Resources Downloaded',
      value: user.stats.resourcesDownloaded,
      icon: Download,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      change: '+28%',
      changeType: 'positive' as const
    },
    {
      title: 'Certificates Earned',
      value: user.stats.certificatesEarned,
      icon: Award,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
      change: '0%',
      changeType: 'neutral' as const
    }
  ];

  const quickActions = [
    {
      title: 'New Application',
      description: 'Apply to a program',
      icon: Target,
      action: () => {/* Navigate to programs */}
    },
    {
      title: 'Book Session',
      description: 'Schedule with mentor',
      icon: Calendar,
      action: () => {/* Navigate to mentors */}
    },
    {
      title: 'Study Material',
      description: 'Access curriculum',
      icon: BookOpen,
      action: () => {/* Navigate to curriculum */}
    },
    {
      title: 'Get Support',
      description: 'Chat with admin',
      icon: MessageCircle,
      action: () => {/* Navigate to chat */}
    }
  ];

  return (
    <div className="space-y-6">
      {/* Profile Completion Banner */}
      <Card className="p-6 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="font-semibold mb-2">Complete Your Profile</h3>
            <p className="text-sm text-muted-foreground mb-3">
              {user.profileCompleteness}% complete - Add more details to unlock all features
            </p>
            <Progress value={user.profileCompleteness} className="h-2 mb-4" />
          </div>
          <Button variant="outline" size="sm">
            Complete Profile
          </Button>
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold mb-2">{stat.value}</p>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-green-600" />
                    <span className={`text-xs ${
                      stat.changeType === 'positive' ? 'text-green-600' : 
                      stat.changeType === 'negative' ? 'text-red-600' : 
                      'text-muted-foreground'
                    }`}>
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.bgColor}`}>
                  <IconComponent className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const IconComponent = action.icon;
            return (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-4 flex-col items-start text-left"
                onClick={action.action}
              >
                <IconComponent className="w-5 h-5 mb-2 text-primary" />
                <div className="space-y-1">
                  <p className="font-medium">{action.title}</p>
                  <p className="text-xs text-muted-foreground">{action.description}</p>
                </div>
              </Button>
            );
          })}
        </div>
      </Card>

      {/* Recent Activity */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4">Recent Activity</h3>
        <div className="space-y-4">
          <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <Target className="w-4 h-4 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Applied to TechStars Accelerator</p>
              <p className="text-sm text-muted-foreground">2 days ago</p>
            </div>
            <Badge variant="outline">In Review</Badge>
          </div>
          
          <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <Users className="w-4 h-4 text-green-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Completed mentoring session</p>
              <p className="text-sm text-muted-foreground">1 week ago</p>
            </div>
            <Badge variant="secondary">Completed</Badge>
          </div>
          
          <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <Download className="w-4 h-4 text-purple-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Downloaded Pitch Deck Template</p>
              <p className="text-sm text-muted-foreground">2 weeks ago</p>
            </div>
            <Badge variant="outline">Resource</Badge>
          </div>
        </div>
      </Card>
    </div>
  );
}