import React, { useState } from 'react';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { createProject, updateProject } from '../../utils/storage';

interface Project {
  id: string;
  name: string;
  description: string;
  stage: 'idea' | 'mvp' | 'scaling';
  currentMilestone: string;
  updatedAt: string;
}

interface ProjectsSectionProps {
  projects: Project[];
  onUpdate: () => void;
}

export function ProjectsSection({ projects, onUpdate }: ProjectsSectionProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const handleSubmit = (projectData: any) => {
    if (editingProject) {
      updateProject(editingProject.id, projectData);
    } else {
      createProject(projectData);
    }
    setShowForm(false);
    setEditingProject(null);
    onUpdate();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900">My Projects</h2>
        <button
          onClick={() => setShowForm(true)}
          className="btn-primary flex items-center"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Project
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <p>No projects yet. Create your first project to get started!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {projects.map(project => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              onEdit={() => {
                setEditingProject(project);
                setShowForm(true);
              }}
            />
          ))}
        </div>
      )}

      {showForm && (
        <ProjectForm
          project={editingProject}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingProject(null);
          }}
        />
      )}
    </div>
  );
}

function ProjectCard({ project, onEdit }: { project: Project; onEdit: () => void }) {
  const stageColors = {
    idea: 'badge-stage-idea',
    mvp: 'badge-stage-mvp',
    scaling: 'badge-stage-scaling'
  };

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="font-medium text-gray-900">{project.name}</h3>
            <span className={stageColors[project.stage]}>{project.stage}</span>
          </div>
          <p className="text-gray-600 text-sm mb-2">{project.description}</p>
          <p className="text-sm text-gray-500">
            Current milestone: {project.currentMilestone}
          </p>
          <p className="text-xs text-gray-400 mt-1">
            Updated {new Date(project.updatedAt).toLocaleDateString()}
          </p>
        </div>
        <button
          onClick={onEdit}
          className="p-2 text-gray-400 hover:text-gray-600"
        >
          <Edit className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function ProjectForm({ project, onSubmit, onCancel }: {
  project: Project | null;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState({
    name: project?.name || '',
    description: project?.description || '',
    stage: project?.stage || 'idea',
    currentMilestone: project?.currentMilestone || '',
    team: project?.team || [],
    links: project?.links || []
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-bold mb-4">
          {project ? 'Edit Project' : 'New Project'}
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Project Name *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={3}
              className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Stage
            </label>
            <select
              value={formData.stage}
              onChange={(e) => setFormData({...formData, stage: e.target.value as any})}
              className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
            >
              <option value="idea">Idea</option>
              <option value="mvp">MVP</option>
              <option value="scaling">Scaling</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Current Milestone
            </label>
            <input
              type="text"
              value={formData.currentMilestone}
              onChange={(e) => setFormData({...formData, currentMilestone: e.target.value})}
              className="w-full p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              placeholder="What are you working on next?"
            />
          </div>
          
          <div className="flex gap-3">
            <button type="submit" className="btn-primary flex-1">
              {project ? 'Update' : 'Create'} Project
            </button>
            <button type="button" onClick={onCancel} className="btn-secondary flex-1">
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}