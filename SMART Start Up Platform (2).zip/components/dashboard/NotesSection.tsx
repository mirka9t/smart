import React, { useState } from 'react';
import { Plus, CheckCircle, Circle, Trash2 } from 'lucide-react';
import { addNote, toggleNote, deleteNote } from '../../utils/storage';

interface Note {
  id: string;
  content: string;
  completed: boolean;
  createdAt: string;
}

interface NotesSectionProps {
  notes: Note[];
  onUpdate: () => void;
}

export function NotesSection({ notes, onUpdate }: NotesSectionProps) {
  const [showForm, setShowForm] = useState(false);
  const [newNote, setNewNote] = useState('');

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (newNote.trim()) {
      addNote(newNote.trim());
      setNewNote('');
      setShowForm(false);
      onUpdate();
    }
  };

  const handleToggleNote = (noteId: string) => {
    toggleNote(noteId);
    onUpdate();
  };

  const handleDeleteNote = (noteId: string) => {
    deleteNote(noteId);
    onUpdate();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900">Notes & To-dos</h2>
        <button
          onClick={() => setShowForm(true)}
          className="btn-primary flex items-center"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Note
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleAddNote} className="mb-6">
          <div className="flex gap-2">
            <input
              type="text"
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Add a note or todo..."
              className="flex-1 p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              autoFocus
            />
            <button type="submit" className="btn-primary">Add</button>
            <button 
              type="button" 
              onClick={() => {
                setShowForm(false);
                setNewNote('');
              }}
              className="btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {notes.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <p>No notes yet. Add your first note to keep track of ideas and tasks!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notes.map(note => (
            <NoteItem
              key={note.id}
              note={note}
              onToggle={() => handleToggleNote(note.id)}
              onDelete={() => handleDeleteNote(note.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function NoteItem({ note, onToggle, onDelete }: {
  note: Note;
  onToggle: () => void;
  onDelete: () => void;
}) {
  return (
    <div className={`flex items-center gap-3 p-3 border border-gray-200 rounded-lg ${
      note.completed ? 'bg-gray-50' : 'bg-white'
    }`}>
      <button onClick={onToggle} className="flex-shrink-0">
        {note.completed ? (
          <CheckCircle className="h-5 w-5 text-green-500" />
        ) : (
          <Circle className="h-5 w-5 text-gray-400" />
        )}
      </button>
      
      <span className={`flex-1 ${
        note.completed ? 'line-through text-gray-500' : 'text-gray-700'
      }`}>
        {note.content}
      </span>
      
      <span className="text-xs text-gray-400">
        {new Date(note.createdAt).toLocaleDateString()}
      </span>
      
      <button
        onClick={onDelete}
        className="p-1 text-gray-400 hover:text-red-500"
      >
        <Trash2 className="h-4 w-4" />
      </button>
    </div>
  );
}