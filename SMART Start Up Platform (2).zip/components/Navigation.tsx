import React, { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Menu, 
  X, 
  User, 
  Settings, 
  LogOut, 
  Bell,
  Heart,
  BookOpen,
  FileText,
  MessageCircle,
  Shield
} from 'lucide-react';
import { AuthModal } from './auth/AuthModals';
import { useAuth } from '../contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface NavigationProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export function Navigation({ currentPath, onNavigate }: NavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  const publicNavItems = [
    { path: '/', label: 'Home', icon: '🏠' },
    { path: '/programs', label: 'Programs', icon: '🚀' },
    { path: '/curriculum', label: 'Curriculum', icon: '📚' },
    { path: '/mentors', label: 'Mentors', icon: '👥' },
    { path: '/funding', label: 'Funding', icon: '💰' },
    { path: '/startups', label: 'Startups', icon: '🏢' },
    { path: '/resources', label: 'Resources', icon: '📋' },
  ];

  const userNavItems = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/deck', label: 'Pitch Deck', icon: '📈' },
    { path: '/rehearsal', label: 'Rehearsal', icon: '🎯' },
    { path: '/my-favorites', label: 'Favorites', icon: '❤️' },
    { path: '/my-applications', label: 'Applications', icon: '📝' },
  ];

  const adminNavItems = [
    { path: '/admin', label: 'Admin Panel', icon: '⚙️' },
  ];

  const allNavItems = [
    ...publicNavItems,
    ...(isAuthenticated ? userNavItems : []),
    ...(isAdmin ? adminNavItems : []),
  ];

  const handleAuthClick = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleLogout = () => {
    logout();
    onNavigate('/');
    setIsMenuOpen(false);
  };

  const handleProfileClick = () => {
    onNavigate('/profile');
    setIsMenuOpen(false);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <>
      <nav className="smart-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div 
              className="flex items-center cursor-pointer" 
              onClick={() => onNavigate('/')}
            >
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center mr-3">
                <span className="text-primary-foreground font-bold text-lg">S</span>
              </div>
              <span className="text-xl font-bold text-primary">SMART Start Up</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              {publicNavItems.map((item) => (
                <Button
                  key={item.path}
                  variant={currentPath === item.path ? "default" : "ghost"}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    currentPath === item.path ? 'bg-primary text-primary-foreground' : ''
                  }`}
                  onClick={() => onNavigate(item.path)}
                >
                  <span className="mr-1">{item.icon}</span>
                  {item.label}
                </Button>
              ))}
            </div>

            {/* User Section */}
            <div className="hidden md:flex items-center space-x-4">
              {isAuthenticated ? (
                <>
                  {/* User-specific navigation */}
                  {userNavItems.map((item) => (
                    <Button
                      key={item.path}
                      variant={currentPath === item.path ? "default" : "ghost"}
                      size="sm"
                      onClick={() => onNavigate(item.path)}
                    >
                      <span className="mr-1">{item.icon}</span>
                      {item.label}
                    </Button>
                  ))}

                  {/* Admin navigation */}
                  {isAdmin && adminNavItems.map((item) => (
                    <Button
                      key={item.path}
                      variant={currentPath === item.path ? "default" : "outline"}
                      size="sm"
                      onClick={() => onNavigate(item.path)}
                      className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Shield className="w-4 h-4 mr-1" />
                      {item.label}
                    </Button>
                  ))}

                  {/* Notifications */}
                  <Button variant="ghost" size="sm" className="relative">
                    <Bell className="w-4 h-4" />
                    <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs">3</Badge>
                  </Button>

                  {/* User Menu */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user?.avatar} alt={user?.name} />
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {getInitials(user?.name || 'U')}
                          </AvatarFallback>
                        </Avatar>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent className="w-56" align="end" forceMount>
                      <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium leading-none">{user?.name}</p>
                          <p className="text-xs leading-none text-muted-foreground">
                            {user?.email}
                          </p>
                          <div className="flex items-center space-x-1 pt-1">
                            <Badge variant="outline" className="text-xs">
                              {user?.role === 'admin' ? 'Admin' : 'Student'}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {user?.profileCompleteness}% Complete
                            </Badge>
                          </div>
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleProfileClick}>
                        <User className="mr-2 h-4 w-4" />
                        <span>Profile</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onNavigate('/profile/settings')}>
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Settings</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onNavigate('/my-favorites')}>
                        <Heart className="mr-2 h-4 w-4" />
                        <span>Favorites</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onNavigate('/my-applications')}>
                        <FileText className="mr-2 h-4 w-4" />
                        <span>Applications</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onNavigate('/chat')}>
                        <MessageCircle className="mr-2 h-4 w-4" />
                        <span>Chat with Admin</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Log out</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" onClick={() => handleAuthClick('login')}>
                    Sign In
                  </Button>
                  <Button className="btn-primary" onClick={() => handleAuthClick('signup')}>
                    Get Started
                  </Button>
                </div>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 bg-background border-t border-border">
                {allNavItems.map((item) => (
                  <Button
                    key={item.path}
                    variant={currentPath === item.path ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => {
                      onNavigate(item.path);
                      setIsMenuOpen(false);
                    }}
                  >
                    <span className="mr-2">{item.icon}</span>
                    {item.label}
                  </Button>
                ))}

                {isAuthenticated ? (
                  <div className="border-t border-border pt-3 mt-3 space-y-1">
                    <div className="px-3 py-2">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user?.avatar} alt={user?.name} />
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {getInitials(user?.name || 'U')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-sm font-medium">{user?.name}</div>
                          <div className="text-xs text-muted-foreground">{user?.email}</div>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={handleProfileClick}
                    >
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        onNavigate('/profile/settings');
                        setIsMenuOpen(false);
                      }}
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Log out
                    </Button>
                  </div>
                ) : (
                  <div className="border-t border-border pt-3 mt-3 space-y-1">
                    <Button
                      variant="ghost"
                      className="w-full justify-start"
                      onClick={() => {
                        handleAuthClick('login');
                        setIsMenuOpen(false);
                      }}
                    >
                      Sign In
                    </Button>
                    <Button
                      className="w-full btn-primary"
                      onClick={() => {
                        handleAuthClick('signup');
                        setIsMenuOpen(false);
                      }}
                    >
                      Get Started
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
        onSwitchMode={setAuthMode}
      />
    </>
  );
}