import React from 'react';
import { motion } from 'motion/react';
import { Loader2, Zap, Coffee, Rocket, Lightbulb, Target } from 'lucide-react';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface LoadingProps {
  message?: string;
  submessage?: string;
  type?: 'default' | 'upload' | 'processing' | 'saving' | 'loading' | 'generating';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  fullScreen?: boolean;
  showProgress?: boolean;
  progress?: number;
  className?: string;
}

const loadingMessages = {
  default: [
    "Getting things ready...",
    "Almost there...",
    "Loading your content...",
    "Setting up your workspace..."
  ],
  upload: [
    "Uploading your files...",
    "Processing upload...",
    "Almost finished uploading...",
    "Finalizing upload..."
  ],
  processing: [
    "Processing your request...",
    "Analyzing data...",
    "Running calculations...",
    "Generating results..."
  ],
  saving: [
    "Saving your changes...",
    "Updating records...",
    "Synchronizing data...",
    "Almost saved..."
  ],
  loading: [
    "Loading your dashboard...",
    "Fetching latest data...",
    "Preparing your view...",
    "Getting ready..."
  ],
  generating: [
    "Generating your content...",
    "Creating personalized results...",
    "Building your deck...",
    "Crafting your presentation..."
  ]
};

const loadingIcons = {
  default: Loader2,
  upload: Rocket,
  processing: Zap,
  saving: Coffee,
  loading: Target,
  generating: Lightbulb
};

export function Loading({
  message,
  submessage,
  type = 'default',
  size = 'md',
  fullScreen = false,
  showProgress = false,
  progress = 0,
  className = ''
}: LoadingProps) {
  const [currentMessageIndex, setCurrentMessageIndex] = React.useState(0);
  const [displayMessage, setDisplayMessage] = React.useState(message || loadingMessages[type][0]);

  const IconComponent = loadingIcons[type];

  // Cycle through messages
  React.useEffect(() => {
    if (!message) {
      const interval = setInterval(() => {
        setCurrentMessageIndex((prev) => (prev + 1) % loadingMessages[type].length);
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [message, type]);

  React.useEffect(() => {
    if (!message) {
      setDisplayMessage(loadingMessages[type][currentMessageIndex]);
    } else {
      setDisplayMessage(message);
    }
  }, [currentMessageIndex, message, type]);

  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  };

  const textSizeClasses = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-lg',
    xl: 'text-xl'
  };

  const containerClasses = fullScreen
    ? 'fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center'
    : 'flex items-center justify-center p-8';

  return (
    <div className={`${containerClasses} ${className}`}>
      <div className="text-center space-y-4 max-w-sm mx-auto">
        {/* Logo and Spinner */}
        <div className="relative flex items-center justify-center">
          {/* SMART Logo */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <img 
              src={smartLogo} 
              alt="SMART" 
              className={`${sizeClasses[size]} object-contain`}
            />
          </motion.div>

          {/* Spinning Icon */}
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <IconComponent className={`${sizeClasses[size]} text-primary opacity-70`} />
          </motion.div>

          {/* Pulse Ring */}
          <motion.div
            animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.2, 0.5] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0 rounded-full border-2 border-primary"
          />
        </div>

        {/* Progress Bar */}
        {showProgress && (
          <div className="w-full max-w-xs mx-auto">
            <div className="flex justify-between text-xs text-muted-foreground mb-2">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-primary to-primary/80 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              />
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="space-y-2">
          <motion.p
            key={displayMessage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className={`${textSizeClasses[size]} font-medium text-foreground`}
          >
            {displayMessage}
          </motion.p>

          {submessage && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-sm text-muted-foreground"
            >
              {submessage}
            </motion.p>
          )}
        </div>

        {/* Animated Dots */}
        <div className="flex justify-center space-x-1">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              animate={{
                y: [0, -8, 0],
                opacity: [0.4, 1, 0.4]
              }}
              transition={{
                duration: 1.2,
                repeat: Infinity,
                delay: i * 0.2,
                ease: "easeInOut"
              }}
              className="w-2 h-2 bg-primary rounded-full"
            />
          ))}
        </div>

        {/* Startup Motivation Quote */}
        {fullScreen && type === 'generating' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.5 }}
            className="mt-8 p-4 bg-muted/30 rounded-lg border border-border"
          >
            <p className="text-xs text-muted-foreground italic">
              "The way to get started is to quit talking and begin doing." - Walt Disney
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}

// Specialized loading components for different use cases
export function PageLoading({ message }: { message?: string }) {
  return (
    <Loading
      message={message}
      type="loading"
      size="lg"
      fullScreen
      className="min-h-screen"
    />
  );
}

export function ButtonLoading({ size = 'sm' }: { size?: 'sm' | 'md' }) {
  return (
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
    >
      <Loader2 className={size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} />
    </motion.div>
  );
}

export function InlineLoading({ 
  message = "Loading...", 
  className = "" 
}: { 
  message?: string; 
  className?: string; 
}) {
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      >
        <Loader2 className="w-4 h-4 text-primary" />
      </motion.div>
      <span className="text-sm text-muted-foreground">{message}</span>
    </div>
  );
}

export function ProgressLoading({ 
  progress, 
  message, 
  className = "" 
}: { 
  progress: number; 
  message?: string; 
  className?: string; 
}) {
  return (
    <Loading
      message={message}
      type="processing"
      size="md"
      showProgress
      progress={progress}
      className={className}
    />
  );
}

export default Loading;