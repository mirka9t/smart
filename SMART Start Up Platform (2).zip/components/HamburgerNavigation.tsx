import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Menu, 
  X, 
  User, 
  Settings, 
  LogOut, 
  Bell,
  Heart,
  BookOpen,
  FileText,
  MessageCircle,
  Shield,
  Home,
  Rocket,
  GraduationCap,
  Users,
  DollarSign,
  Building,
  FolderOpen,
  BarChart3,
  Presentation,
  Target,
  Star,
  Building2,
  UserCheck
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AuthModal } from './auth/AuthModals';
import { useAuth } from '../contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { chatManager } from '../utils/chatUtils';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface NavigationProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<any>;
  badge?: string;
  requiresAuth?: boolean;
  adminOnly?: boolean;
  description?: string;
}

export function HamburgerNavigation({ currentPath, onNavigate }: NavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [adminUnreadCount, setAdminUnreadCount] = useState(0);
  const [teamUnreadCount, setTeamUnreadCount] = useState(0);
  
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  // Check for unread messages
  useEffect(() => {
    if (user) {
      try {
        // Get admin unread count
        const adminCount = chatManager.getAdminUnreadCount();
        setAdminUnreadCount(adminCount);
        
        // Get general chat unread count
        const chatUsers = chatManager.getChatUsers();
        const teamCount = chatUsers.reduce((total, chatUser) => total + chatUser.unreadCount, 0);
        setTeamUnreadCount(teamCount);
      } catch (error) {
        console.error('Error getting unread counts:', error);
      }
    }
  }, [user, isMenuOpen]);

  // Navigation items organized by category
  const publicNavItems: NavItem[] = [
    { path: '/', label: 'Home', icon: Home, description: 'Platform overview and welcome' },
    { path: '/programs', label: 'Programs', icon: Rocket, description: 'Startup acceleration programs' },
    { path: '/curriculum', label: 'Curriculum', icon: GraduationCap, description: 'Educational content and courses' },
    { path: '/mentors', label: 'Mentors', icon: UserCheck, description: 'Find experienced mentors' },
    { path: '/funding', label: 'Funding', icon: DollarSign, description: 'Investment and funding opportunities' },
    { path: '/startups', label: 'Startups', icon: Building, description: 'Discover startup projects' },
    { path: '/resources', label: 'Resources', icon: FolderOpen, description: 'Tools and helpful resources' },
  ];

  const userNavItems: NavItem[] = [
    { path: '/dashboard', label: 'Dashboard', icon: BarChart3, requiresAuth: true, description: 'Your personal startup dashboard' },
    { path: '/deck', label: 'Pitch Deck', icon: Presentation, requiresAuth: true, description: 'Create and edit pitch decks' },
    { path: '/rehearsal', label: 'Rehearsal Studio', icon: Target, requiresAuth: true, description: 'Practice your presentations' },
    { path: '/my-favorites', label: 'My Favorites', icon: Heart, requiresAuth: true, description: 'Saved content and bookmarks' },
    { path: '/my-applications', label: 'My Applications', icon: FileText, requiresAuth: true, description: 'Track your applications' },
  ];

  const chatNavItems: NavItem[] = [
    { 
      path: '/chat-admin', 
      label: 'Chat with Admin', 
      icon: Shield, 
      requiresAuth: true, 
      badge: adminUnreadCount > 0 ? adminUnreadCount.toString() : undefined,
      description: 'Direct support from admin team'
    },
    { 
      path: '/chat', 
      label: 'Team Chat', 
      icon: Building2, 
      requiresAuth: true, 
      badge: teamUnreadCount > 0 ? teamUnreadCount.toString() : undefined,
      description: 'Collaborate with your startup team'
    },
  ];

  const adminNavItems: NavItem[] = [
    { path: '/admin', label: 'Admin Panel', icon: Shield, adminOnly: true, description: 'Platform administration tools' },
  ];

  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [currentPath]);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  // Close menu on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isMenuOpen]);

  const handleAuthClick = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
    setIsMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    onNavigate('/');
    setIsMenuOpen(false);
  };

  const handleNavClick = (path: string) => {
    onNavigate(path);
    setIsMenuOpen(false);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getVisibleNavItems = () => {
    let items = [...publicNavItems];
    
    if (isAuthenticated) {
      items = [...items, ...userNavItems, ...chatNavItems];
    }
    
    if (isAdmin) {
      items = [...items, ...adminNavItems];
    }
    
    return items.filter(item => {
      if (item.requiresAuth && !isAuthenticated) return false;
      if (item.adminOnly && !isAdmin) return false;
      return true;
    });
  };

  const menuVariants = {
    closed: {
      opacity: 0,
      scale: 0.95,
      transition: {
        duration: 0.2,
        ease: "easeInOut"
      }
    },
    open: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.3,
        ease: "easeOutBack"
      }
    }
  };

  const itemVariants = {
    closed: {
      opacity: 0,
      x: -20,
      transition: {
        duration: 0.2
      }
    },
    open: (i: number) => ({
      opacity: 1,
      x: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.3,
        ease: "easeOut"
      }
    })
  };

  const hamburgerVariants = {
    closed: {
      rotate: 0,
      transition: {
        duration: 0.2
      }
    },
    open: {
      rotate: 180,
      transition: {
        duration: 0.3
      }
    }
  };

  // Get notification count (including both chat systems)
  const totalNotificationCount = adminUnreadCount + teamUnreadCount;

  return (
    <>
      {/* Main Navigation Bar */}
      <nav className="smart-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <motion.div 
              className="flex items-center cursor-pointer" 
              onClick={() => onNavigate('/')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="w-10 h-10 mr-3">
                <img 
                  src={smartLogo} 
                  alt="SMART Start Up" 
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="text-xl font-bold text-primary">SMART Start Up</span>
            </motion.div>

            {/* User Info Badge (Desktop) */}
            {isAuthenticated && user && (
              <motion.div 
                className="hidden lg:flex items-center space-x-3 px-4 py-2 bg-muted/50 rounded-full"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                    {getInitials(user.name)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="text-sm font-medium leading-none">{user.name}</span>
                  <span className="text-xs text-muted-foreground">{user.role === 'admin' ? 'Admin' : 'Student'}</span>
                </div>
                {totalNotificationCount > 0 && (
                  <Badge variant="destructive" className="text-xs px-2 py-1">
                    {totalNotificationCount}
                  </Badge>
                )}
              </motion.div>
            )}

            {/* Hamburger Menu Button */}
            <motion.button
              className="relative w-12 h-12 rounded-full bg-primary/10 hover:bg-primary/20 flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              variants={hamburgerVariants}
              animate={isMenuOpen ? "open" : "closed"}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <AnimatePresence mode="wait">
                {isMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="h-6 w-6 text-primary" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="h-6 w-6 text-primary" />
                  </motion.div>
                )}
              </AnimatePresence>
              
              {/* Notification indicator */}
              {isAuthenticated && totalNotificationCount > 0 && (
                <motion.div
                  className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3, type: "spring", stiffness: 500, damping: 15 }}
                >
                  <span className="text-xs text-destructive-foreground font-semibold">
                    {totalNotificationCount > 9 ? '9+' : totalNotificationCount}
                  </span>
                </motion.div>
              )}
            </motion.button>
          </div>
        </div>
      </nav>

      {/* Hamburger Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            className="fixed inset-0 z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 bg-background/95 backdrop-blur-xl"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
            />

            {/* Menu Content */}
            <motion.div
              className="relative h-full flex"
              variants={menuVariants}
              initial="closed"
              animate="open"
              exit="closed"
            >
              {/* Main Menu Panel */}
              <div className="w-full max-w-lg ml-auto bg-card border-l border-border flex flex-col shadow-2xl">
                {/* Header */}
                <div className="p-6 border-b border-border">
                  <div className="flex items-center justify-between mb-6">
                    <motion.div 
                      className="flex items-center"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 }}
                    >
                      <img 
                        src={smartLogo} 
                        alt="SMART Start Up" 
                        className="w-10 h-10 mr-3"
                      />
                      <span className="text-xl font-bold text-primary">SMART Start Up</span>
                    </motion.div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsMenuOpen(false)}
                      className="w-10 h-10 p-0 rounded-full hover:bg-muted"
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>

                  {/* User Info */}
                  {isAuthenticated && user && (
                    <motion.div
                      className="flex items-center space-x-4 p-4 bg-muted/30 rounded-xl"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback className="bg-primary text-primary-foreground">
                          {getInitials(user.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold truncate">{user.name}</p>
                        <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="outline" className="text-xs">
                            {user.role === 'admin' ? 'Admin' : 'Student'}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {user.profileCompleteness}% Complete
                          </Badge>
                          {totalNotificationCount > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              {totalNotificationCount} new
                            </Badge>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Navigation Items */}
                <div className="flex-1 overflow-y-auto p-6">
                  <div className="space-y-8">
                    {/* Main Navigation */}
                    <div>
                      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                        Navigate
                      </h3>
                      <div className="space-y-2">
                        {publicNavItems.map((item, index) => {
                          const IconComponent = item.icon;
                          const isActive = currentPath === item.path;
                          
                          return (
                            <motion.button
                              key={item.path}
                              custom={index}
                              variants={itemVariants}
                              initial="closed"
                              animate="open"
                              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                                isActive 
                                  ? 'bg-primary text-primary-foreground shadow-lg' 
                                  : 'hover:bg-muted/70 text-foreground hover:shadow-md'
                              }`}
                              onClick={() => handleNavClick(item.path)}
                              whileHover={{ x: 6 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <div className="flex items-center space-x-3">
                                <IconComponent className="w-5 h-5" />
                                <div>
                                  <span className="font-medium">{item.label}</span>
                                  {item.description && (
                                    <p className="text-xs opacity-70 group-hover:opacity-100 transition-opacity">
                                      {item.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                              {item.badge && (
                                <Badge variant={isActive ? "secondary" : "outline"} className="text-xs">
                                  {item.badge}
                                </Badge>
                              )}
                            </motion.button>
                          );
                        })}
                      </div>
                    </div>

                    {/* User Tools (if authenticated) */}
                    {isAuthenticated && (
                      <div>
                        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                          Your Tools
                        </h3>
                        <div className="space-y-2">
                          {userNavItems.map((item, index) => {
                            const IconComponent = item.icon;
                            const isActive = currentPath === item.path;
                            
                            return (
                              <motion.button
                                key={item.path}
                                custom={publicNavItems.length + index}
                                variants={itemVariants}
                                initial="closed"
                                animate="open"
                                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                                  isActive 
                                    ? 'bg-primary text-primary-foreground shadow-lg' 
                                    : 'hover:bg-muted/70 text-foreground hover:shadow-md'
                                }`}
                                onClick={() => handleNavClick(item.path)}
                                whileHover={{ x: 6 }}
                                whileTap={{ scale: 0.98 }}
                              >
                                <div className="flex items-center space-x-3">
                                  <IconComponent className="w-5 h-5" />
                                  <div>
                                    <span className="font-medium">{item.label}</span>
                                    {item.description && (
                                      <p className="text-xs opacity-70 group-hover:opacity-100 transition-opacity">
                                        {item.description}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                {item.badge && (
                                  <Badge variant={isActive ? "secondary" : "outline"} className="text-xs">
                                    {item.badge}
                                  </Badge>
                                )}
                              </motion.button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Chat Systems (if authenticated) */}
                    {isAuthenticated && (
                      <div>
                        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                          Communication
                        </h3>
                        <div className="space-y-2">
                          {chatNavItems.map((item, index) => {
                            const IconComponent = item.icon;
                            const isActive = currentPath === item.path;
                            
                            return (
                              <motion.button
                                key={item.path}
                                custom={publicNavItems.length + userNavItems.length + index}
                                variants={itemVariants}
                                initial="closed"
                                animate="open"
                                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                                  isActive 
                                    ? 'bg-primary text-primary-foreground shadow-lg' 
                                    : 'hover:bg-muted/70 text-foreground hover:shadow-md'
                                }`}
                                onClick={() => handleNavClick(item.path)}
                                whileHover={{ x: 6 }}
                                whileTap={{ scale: 0.98 }}
                              >
                                <div className="flex items-center space-x-3">
                                  <IconComponent className="w-5 h-5" />
                                  <div>
                                    <span className="font-medium">{item.label}</span>
                                    {item.description && (
                                      <p className="text-xs opacity-70 group-hover:opacity-100 transition-opacity">
                                        {item.description}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                {item.badge && (
                                  <Badge 
                                    variant={isActive ? "secondary" : "destructive"} 
                                    className="text-xs animate-pulse"
                                  >
                                    {item.badge}
                                  </Badge>
                                )}
                              </motion.button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Admin Section */}
                    {isAdmin && (
                      <div>
                        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                          Administration
                        </h3>
                        <div className="space-y-2">
                          {adminNavItems.map((item, index) => {
                            const IconComponent = item.icon;
                            const isActive = currentPath === item.path;
                            
                            return (
                              <motion.button
                                key={item.path}
                                custom={publicNavItems.length + userNavItems.length + chatNavItems.length + index}
                                variants={itemVariants}
                                initial="closed"
                                animate="open"
                                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-left transition-all duration-200 group ${
                                  isActive 
                                    ? 'bg-primary text-primary-foreground shadow-lg' 
                                    : 'hover:bg-muted/70 text-foreground hover:shadow-md'
                                }`}
                                onClick={() => handleNavClick(item.path)}
                                whileHover={{ x: 6 }}
                                whileTap={{ scale: 0.98 }}
                              >
                                <div className="flex items-center space-x-3">
                                  <IconComponent className="w-5 h-5" />
                                  <div>
                                    <span className="font-medium">{item.label}</span>
                                    {item.description && (
                                      <p className="text-xs opacity-70 group-hover:opacity-100 transition-opacity">
                                        {item.description}
                                      </p>
                                    )}
                                  </div>
                                </div>
                              </motion.button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Account Actions */}
                    {isAuthenticated ? (
                      <div>
                        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                          Account
                        </h3>
                        <div className="space-y-2">
                          <motion.button
                            custom={getVisibleNavItems().length}
                            variants={itemVariants}
                            initial="closed"
                            animate="open"
                            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left hover:bg-muted/70 transition-all duration-200"
                            onClick={() => handleNavClick('/profile')}
                            whileHover={{ x: 6 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <User className="w-5 h-5" />
                            <span className="font-medium">Profile</span>
                          </motion.button>
                          
                          <motion.button
                            custom={getVisibleNavItems().length + 1}
                            variants={itemVariants}
                            initial="closed"
                            animate="open"
                            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left hover:bg-muted/70 transition-all duration-200"
                            onClick={() => handleNavClick('/profile/settings')}
                            whileHover={{ x: 6 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <Settings className="w-5 h-5" />
                            <span className="font-medium">Settings</span>
                          </motion.button>
                          
                          <motion.button
                            custom={getVisibleNavItems().length + 2}
                            variants={itemVariants}
                            initial="closed"
                            animate="open"
                            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-left hover:bg-destructive/10 hover:text-destructive transition-all duration-200 text-destructive"
                            onClick={handleLogout}
                            whileHover={{ x: 6 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <LogOut className="w-5 h-5" />
                            <span className="font-medium">Sign Out</span>
                          </motion.button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                          Get Started
                        </h3>
                        <div className="space-y-3">
                          <motion.button
                            custom={getVisibleNavItems().length}
                            variants={itemVariants}
                            initial="closed"
                            animate="open"
                            className="w-full btn-secondary justify-center"
                            onClick={() => handleAuthClick('login')}
                            whileTap={{ scale: 0.98 }}
                          >
                            Sign In
                          </motion.button>
                          
                          <motion.button
                            custom={getVisibleNavItems().length + 1}
                            variants={itemVariants}
                            initial="closed"
                            animate="open"
                            className="w-full btn-primary justify-center"
                            onClick={() => handleAuthClick('signup')}
                            whileTap={{ scale: 0.98 }}
                          >
                            Get Started Free
                          </motion.button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-border">
                  <motion.div
                    className="text-center space-y-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <p className="text-xs text-muted-foreground">
                      © 2024 SMART Start Up Platform
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Empowering the next generation of entrepreneurs
                    </p>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
        onSwitchMode={setAuthMode}
      />
    </>
  );
}