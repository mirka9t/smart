import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { useAuth } from '../contexts/AuthContext';
import { 
  Heart, 
  Search, 
  Filter, 
  ExternalLink,
  Calendar,
  MapPin,
  Users,
  Building,
  Bookmark,
  Star,
  Trash2
} from 'lucide-react';

interface FavoriteItem {
  id: string;
  type: 'program' | 'mentor' | 'startup' | 'resource';
  title: string;
  description: string;
  image?: string;
  metadata: {
    location?: string;
    date?: string;
    company?: string;
    stage?: string;
    price?: string;
    rating?: number;
  };
  addedAt: string;
  url?: string;
}

export function MyFavorites() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    // Load favorites from localStorage or API
    const savedFavorites = localStorage.getItem(`favorites-${user?.id}`);
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    } else {
      // Demo data
      setFavorites([
        {
          id: 'fav-1',
          type: 'program',
          title: 'Techstars Accelerator',
          description: 'World-class startup accelerator program with $120K funding and global mentorship network.',
          metadata: {
            location: 'Multiple Cities',
            stage: 'Early-stage',
            rating: 4.8
          },
          addedAt: '2024-01-15T10:00:00Z',
          url: 'https://techstars.com'
        },
        {
          id: 'fav-2',
          type: 'mentor',
          title: 'Sarah Chen',
          description: 'Senior Product Manager at Google with 8+ years of experience in startup product development.',
          metadata: {
            company: 'Google',
            price: '$150/hour',
            rating: 4.9
          },
          addedAt: '2024-01-20T14:30:00Z'
        },
        {
          id: 'fav-3',
          type: 'startup',
          title: 'EcoTrack',
          description: 'AI-powered platform helping companies track and reduce their environmental impact.',
          metadata: {
            location: 'Austin, TX',
            stage: 'MVP'
          },
          addedAt: '2024-01-25T09:15:00Z',
          url: 'https://ecotrack.com'
        },
        {
          id: 'fav-4',
          type: 'resource',
          title: 'Pitch Deck Template 2024',
          description: 'Professional pitch deck template with 20+ slides and investor-ready design.',
          metadata: {
            date: 'Updated Jan 2024'
          },
          addedAt: '2024-02-01T16:45:00Z'
        }
      ]);
    }
  }, [user?.id]);

  const removeFavorite = (id: string) => {
    const updatedFavorites = favorites.filter(fav => fav.id !== id);
    setFavorites(updatedFavorites);
    localStorage.setItem(`favorites-${user?.id}`, JSON.stringify(updatedFavorites));
  };

  const filteredFavorites = favorites.filter(favorite => {
    const matchesSearch = favorite.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         favorite.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || favorite.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'program': return '🚀';
      case 'mentor': return '👨‍💼';
      case 'startup': return '🏢';
      case 'resource': return '📋';
      default: return '⭐';
    }
  };

  const getTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'program': return 'bg-blue-100 text-blue-800';
      case 'mentor': return 'bg-green-100 text-green-800';
      case 'startup': return 'bg-purple-100 text-purple-800';
      case 'resource': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const categoryCount = (type: string) => {
    if (type === 'all') return favorites.length;
    return favorites.filter(fav => fav.type === type).length;
  };

  if (!user) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Please log in to view your favorites.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Heart className="w-6 h-6 text-destructive" />
          <h1 className="text-3xl font-bold">My Favorites</h1>
        </div>
        <p className="text-muted-foreground">
          Your saved programs, mentors, startups, and resources all in one place.
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="p-6 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search your favorites..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full md:w-auto">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">
                All ({categoryCount('all')})
              </TabsTrigger>
              <TabsTrigger value="program">
                Programs ({categoryCount('program')})
              </TabsTrigger>
              <TabsTrigger value="mentor">
                Mentors ({categoryCount('mentor')})
              </TabsTrigger>
              <TabsTrigger value="startup">
                Startups ({categoryCount('startup')})
              </TabsTrigger>
              <TabsTrigger value="resource">
                Resources ({categoryCount('resource')})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </Card>

      {/* Favorites Grid */}
      {filteredFavorites.length === 0 ? (
        <Card className="p-12 text-center">
          <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">
            {searchQuery ? 'No matches found' : 'No favorites yet'}
          </h3>
          <p className="text-muted-foreground mb-6">
            {searchQuery 
              ? 'Try adjusting your search or filters'
              : 'Start exploring and save items to see them here'
            }
          </p>
          {!searchQuery && (
            <div className="flex gap-2 justify-center">
              <Button variant="outline">
                Explore Programs
              </Button>
              <Button variant="outline">
                Find Mentors
              </Button>
            </div>
          )}
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFavorites.map((favorite) => (
            <Card key={favorite.id} className="p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{getTypeIcon(favorite.type)}</span>
                  <Badge className={`text-xs ${getTypeBadgeColor(favorite.type)}`}>
                    {favorite.type}
                  </Badge>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => removeFavorite(favorite.id)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>

              <h3 className="font-semibold mb-2 line-clamp-2">{favorite.title}</h3>
              <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                {favorite.description}
              </p>

              {/* Metadata */}
              <div className="space-y-2 mb-4">
                {favorite.metadata.location && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <MapPin className="w-3 h-3" />
                    <span>{favorite.metadata.location}</span>
                  </div>
                )}
                
                {favorite.metadata.company && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Building className="w-3 h-3" />
                    <span>{favorite.metadata.company}</span>
                  </div>
                )}
                
                {favorite.metadata.price && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>💰</span>
                    <span>{favorite.metadata.price}</span>
                  </div>
                )}
                
                {favorite.metadata.rating && (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Star className="w-3 h-3 fill-current text-yellow-400" />
                    <span>{favorite.metadata.rating}/5</span>
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-xs text-muted-foreground">
                  Added {new Date(favorite.addedAt).toLocaleDateString()}
                </span>
                
                {favorite.url && (
                  <Button size="sm" variant="outline">
                    <ExternalLink className="w-3 h-3 mr-1" />
                    View
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Quick Actions */}
      <Card className="p-6 mt-8">
        <h3 className="font-semibold mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Button variant="outline" className="h-16 flex-col">
            <Bookmark className="w-5 h-5 mb-2" />
            <span>Export List</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col">
            <Users className="w-5 h-5 mb-2" />
            <span>Share Favorites</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col">
            <Heart className="w-5 h-5 mb-2" />
            <span>Create Collection</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col">
            <Filter className="w-5 h-5 mb-2" />
            <span>Advanced Filter</span>
          </Button>
        </div>
      </Card>
    </div>
  );
}