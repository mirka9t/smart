import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { 
  FileText, 
  Download, 
  ExternalLink, 
  Search, 
  BookOpen, 
  Video, 
  Wrench, 
  Users, 
  TrendingUp, 
  Target, 
  Lightbulb,
  Calendar,
  DollarSign,
  Building,
  MessageCircle,
  Star,
  Clock,
  CheckCircle
} from 'lucide-react';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'template' | 'guide' | 'tool' | 'video' | 'book' | 'course';
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  rating: number;
  downloads?: number;
  duration?: string;
  price: 'Free' | 'Paid';
  url: string;
  tags: string[];
}

const RESOURCES: Resource[] = [
  // Templates
  {
    id: 'business-model-canvas',
    title: 'Business Model Canvas Template',
    description: 'Interactive template to map out your business model with examples from successful student startups.',
    type: 'template',
    category: 'Strategy',
    difficulty: 'Beginner',
    rating: 4.8,
    downloads: 12500,
    price: 'Free',
    url: '#',
    tags: ['Business Model', 'Strategy', 'Planning']
  },
  {
    id: 'pitch-deck-template',
    title: 'Student Founder Pitch Deck',
    description: 'Professional pitch deck template with 15 slides optimized for student entrepreneurs.',
    type: 'template',
    category: 'Fundraising',
    difficulty: 'Intermediate',
    rating: 4.9,
    downloads: 8900,
    price: 'Free',
    url: '#',
    tags: ['Pitch Deck', 'Fundraising', 'Presentation']
  },
  {
    id: 'financial-model',
    title: 'Startup Financial Model',
    description: 'Excel template with 3-year financial projections, unit economics, and scenario planning.',
    type: 'template',
    category: 'Finance',
    difficulty: 'Advanced',
    rating: 4.7,
    downloads: 5600,
    price: 'Free',
    url: '#',
    tags: ['Finance', 'Modeling', 'Planning']
  },
  
  // Guides
  {
    id: 'mvp-guide',
    title: 'MVP Development Guide',
    description: 'Step-by-step guide to building your Minimum Viable Product without technical expertise.',
    type: 'guide',
    category: 'Product',
    difficulty: 'Beginner',
    rating: 4.6,
    downloads: 15200,
    price: 'Free',
    url: '#',
    tags: ['MVP', 'Product', 'Development']
  },
  {
    id: 'customer-validation',
    title: 'Customer Validation Playbook',
    description: 'Comprehensive playbook with interview scripts, survey templates, and validation frameworks.',
    type: 'guide',
    category: 'Research',
    difficulty: 'Intermediate',
    rating: 4.8,
    downloads: 9800,
    price: 'Free',
    url: '#',
    tags: ['Validation', 'Research', 'Customers']
  },
  {
    id: 'legal-startup-guide',
    title: 'Legal Basics for Student Founders',
    description: 'Essential legal knowledge including incorporation, equity splits, and IP protection.',
    type: 'guide',
    category: 'Legal',
    difficulty: 'Advanced',
    rating: 4.5,
    downloads: 4200,
    price: 'Free',
    url: '#',
    tags: ['Legal', 'Incorporation', 'IP']
  },

  // Tools
  {
    id: 'competitor-analysis-tool',
    title: 'Competitor Analysis Framework',
    description: 'Interactive tool to analyze competitors, identify gaps, and position your startup.',
    type: 'tool',
    category: 'Research',
    difficulty: 'Intermediate',
    rating: 4.4,
    downloads: 7300,
    price: 'Free',
    url: '#',
    tags: ['Competition', 'Analysis', 'Positioning']
  },
  {
    id: 'feature-prioritization',
    title: 'Feature Prioritization Matrix',
    description: 'Tool to prioritize product features based on impact, effort, and user feedback.',
    type: 'tool',
    category: 'Product',
    difficulty: 'Beginner',
    rating: 4.7,
    downloads: 11100,
    price: 'Free',
    url: '#',
    tags: ['Product', 'Features', 'Prioritization']
  },

  // Videos & Courses
  {
    id: 'startup-fundamentals',
    title: 'Startup Fundamentals Course',
    description: '12-hour comprehensive course covering all aspects of building a startup from idea to scale.',
    type: 'course',
    category: 'General',
    difficulty: 'Beginner',
    rating: 4.9,
    duration: '12 hours',
    price: 'Free',
    url: '#',
    tags: ['Course', 'Fundamentals', 'Complete']
  },
  {
    id: 'fundraising-masterclass',
    title: 'Fundraising Masterclass',
    description: 'Video series by successful student founders who raised $50M+ sharing their strategies.',
    type: 'video',
    category: 'Fundraising',
    difficulty: 'Advanced',
    rating: 4.8,
    duration: '3 hours',
    price: 'Free',
    url: '#',
    tags: ['Fundraising', 'Video', 'Expert']
  }
];

const CATEGORIES = [
  'All',
  'Strategy',
  'Product',
  'Fundraising',
  'Research',
  'Finance',
  'Legal',
  'Marketing',
  'General'
];

const RESOURCE_TYPES = [
  'All',
  'template',
  'guide',
  'tool',
  'video',
  'book',
  'course'
];

export function Resources() {
  const [resources] = useState<Resource[]>(RESOURCES);
  const [filteredResources, setFilteredResources] = useState<Resource[]>(RESOURCES);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');

  // Filter resources
  React.useEffect(() => {
    let filtered = resources;

    if (searchTerm) {
      filtered = filtered.filter(resource =>
        resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        resource.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        resource.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(resource => resource.category === selectedCategory);
    }

    if (selectedType !== 'All') {
      filtered = filtered.filter(resource => resource.type === selectedType);
    }

    if (selectedDifficulty !== 'All') {
      filtered = filtered.filter(resource => resource.difficulty === selectedDifficulty);
    }

    setFilteredResources(filtered);
  }, [resources, searchTerm, selectedCategory, selectedType, selectedDifficulty]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'template': return FileText;
      case 'guide': return BookOpen;
      case 'tool': return Wrench;
      case 'video': return Video;
      case 'book': return BookOpen;
      case 'course': return Video;
      default: return FileText;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'template': return 'bg-blue-100 text-blue-700';
      case 'guide': return 'bg-green-100 text-green-700';
      case 'tool': return 'bg-purple-100 text-purple-700';
      case 'video': return 'bg-red-100 text-red-700';
      case 'book': return 'bg-orange-100 text-orange-700';
      case 'course': return 'bg-indigo-100 text-indigo-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-700';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'Advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  // Quick Start Tools
  const quickStartTools = [
    {
      title: 'Idea Validator',
      description: 'Quick assessment of your startup idea',
      icon: Lightbulb,
      color: 'bg-yellow-100 text-yellow-700'
    },
    {
      title: 'Market Size Calculator',
      description: 'Estimate your addressable market',
      icon: TrendingUp,
      color: 'bg-green-100 text-green-700'
    },
    {
      title: 'Equity Calculator',
      description: 'Calculate fair equity splits',
      icon: DollarSign,
      color: 'bg-blue-100 text-blue-700'
    },
    {
      title: 'Launch Checklist',
      description: 'Everything you need before launch',
      icon: CheckCircle,
      color: 'bg-purple-100 text-purple-700'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1>Startup Resources</h1>
        <p className="text-lg mb-6">
          Access templates, guides, tools, and educational content specifically designed for student entrepreneurs.
        </p>
      </div>

      <Tabs defaultValue="resources" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="resources">All Resources</TabsTrigger>
          <TabsTrigger value="quick-tools">Quick Tools</TabsTrigger>
          <TabsTrigger value="learning-path">Learning Path</TabsTrigger>
        </TabsList>

        <TabsContent value="resources" className="space-y-6">
          {/* Search and Filters */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              className="px-3 py-2 border border-border rounded-md bg-background"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              {CATEGORIES.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>

            <select
              className="px-3 py-2 border border-border rounded-md bg-background"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              {RESOURCE_TYPES.map(type => (
                <option key={type} value={type}>
                  {type === 'All' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                </option>
              ))}
            </select>

            <select
              className="px-3 py-2 border border-border rounded-md bg-background"
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
            >
              <option value="All">All Levels</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Results Summary */}
          <p className="text-muted-foreground">
            Showing {filteredResources.length} of {resources.length} resources
          </p>

          {/* Resources Grid */}
          <div className="smart-grid">
            {filteredResources.map((resource) => {
              const IconComponent = getTypeIcon(resource.type);
              
              return (
                <Card key={resource.id} className="smart-card">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg ${getTypeColor(resource.type)} flex items-center justify-center`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="font-semibold truncate">{resource.title}</h3>
                        <p className="text-sm text-muted-foreground capitalize">{resource.type}</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700">
                      {resource.price}
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                    {resource.description}
                  </p>

                  {/* Rating and Stats */}
                  <div className="flex items-center gap-4 mb-4 text-sm">
                    <div className="flex items-center gap-1">
                      {renderStars(resource.rating)}
                      <span className="ml-1 font-medium">{resource.rating}</span>
                    </div>
                    {resource.downloads && (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Download className="w-3 h-3" />
                        <span>{resource.downloads.toLocaleString()}</span>
                      </div>
                    )}
                    {resource.duration && (
                      <div className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        <span>{resource.duration}</span>
                      </div>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge className={getDifficultyColor(resource.difficulty)}>
                      {resource.difficulty}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {resource.category}
                    </Badge>
                    {resource.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button className="flex-1 btn-primary">
                      {resource.type === 'template' || resource.type === 'tool' ? 'Download' : 'Access'}
                    </Button>
                    <Button variant="outline" size="sm">
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Empty State */}
          {filteredResources.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No resources found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search criteria or clearing filters.
              </p>
              <Button 
                variant="outline"
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('All');
                  setSelectedType('All');
                  setSelectedDifficulty('All');
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="quick-tools" className="space-y-6">
          <div className="mb-6">
            <h2>Quick Start Tools</h2>
            <p className="text-muted-foreground">
              Interactive tools to help you make quick progress on key startup decisions.
            </p>
          </div>

          <div className="smart-grid">
            {quickStartTools.map((tool, index) => {
              const IconComponent = tool.icon;
              
              return (
                <Card key={index} className="smart-card cursor-pointer hover:shadow-lg transition-all">
                  <div className={`w-12 h-12 rounded-lg ${tool.color} flex items-center justify-center mb-4`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="mb-2">{tool.title}</h3>
                  <p className="text-muted-foreground mb-4">{tool.description}</p>
                  <Button className="btn-primary">Launch Tool</Button>
                </Card>
              );
            })}
          </div>

          {/* Featured Quick Actions */}
          <div className="smart-card bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
            <h3 className="mb-4">Need Help Getting Started?</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button className="btn-primary justify-start">
                <MessageCircle className="w-4 h-4 mr-2" />
                Chat with AI Assistant
              </Button>
              <Button variant="outline" className="justify-start">
                <Calendar className="w-4 h-4 mr-2" />
                Book Mentor Session
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="learning-path" className="space-y-6">
          <div className="mb-6">
            <h2>Recommended Learning Path</h2>
            <p className="text-muted-foreground">
              A curated sequence of resources to take you from idea to successful startup.
            </p>
          </div>

          <div className="space-y-6">
            {[
              {
                stage: '1. Ideation & Validation',
                resources: ['Idea Validator', 'Customer Validation Playbook', 'MVP Development Guide'],
                description: 'Start here to validate your idea and understand your market.'
              },
              {
                stage: '2. Business Planning',
                resources: ['Business Model Canvas Template', 'Competitor Analysis Framework', 'Financial Model'],
                description: 'Build a solid foundation for your business.'
              },
              {
                stage: '3. Product Development',
                resources: ['Feature Prioritization Matrix', 'MVP Development Guide', 'Launch Checklist'],
                description: 'Build and launch your minimum viable product.'
              },
              {
                stage: '4. Growth & Scaling',
                resources: ['Growth Strategy Guide', 'Marketing Templates', 'Team Building Guide'],
                description: 'Scale your business and build your team.'
              },
              {
                stage: '5. Fundraising',
                resources: ['Pitch Deck Template', 'Fundraising Masterclass', 'Legal Basics Guide'],
                description: 'Raise capital to accelerate your growth.'
              }
            ].map((stage, index) => (
              <Card key={index} className="smart-card">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm flex-shrink-0 mt-1">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <h3 className="mb-2">{stage.stage}</h3>
                    <p className="text-muted-foreground mb-4">{stage.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {stage.resources.map((resource) => (
                        <Badge key={resource} variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                          {resource}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}