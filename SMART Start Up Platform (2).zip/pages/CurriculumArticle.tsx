import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { useAuth } from '../contexts/AuthContext';
import { 
  BookOpen, 
  Clock, 
  CheckCircle, 
  ArrowLeft, 
  ArrowRight,
  Bookmark,
  Share2,
  Download,
  Play,
  Pause,
  Volume2,
  Heart,
  MessageCircle,
  Star,
  User
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  category: string;
  description: string;
  content: string;
  readTime: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  tags: string[];
  author: {
    name: string;
    title: string;
    avatar?: string;
  };
  publishedAt: string;
  updatedAt: string;
  rating: number;
  reviews: number;
  nextArticle?: string;
  prevArticle?: string;
  resources: {
    title: string;
    type: string;
    url: string;
  }[];
}

export function CurriculumArticle() {
  const { user } = useAuth();
  const [article, setArticle] = useState<Article | null>(null);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);

  useEffect(() => {
    // Get article ID from URL parameters (in a real app, this would come from routing)
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id') || 'problem-discovery';
    
    // Load article data (in a real app, this would be from an API)
    loadArticle(articleId);
    
    // Simulate reading progress
    const handleScroll = () => {
      const scrolled = window.scrollY;
      const maxHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (scrolled / maxHeight) * 100;
      setReadingProgress(Math.min(progress, 100));
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const loadArticle = (id: string) => {
    // Demo article data - in a real app, this would come from your CMS or API
    const demoArticle: Article = {
      id: 'problem-discovery',
      title: 'Problem Discovery: Finding Real Problems Worth Solving',
      category: 'Foundation',
      description: 'Learn how to identify and validate real customer problems that are worth building a startup around.',
      content: `
# Problem Discovery: The Foundation of Every Successful Startup

## Introduction

Every successful startup begins with a problem worth solving. But not all problems are created equal. In this comprehensive guide, you'll learn how to identify, validate, and articulate problems that customers actually care about.

## Why Problem Discovery Matters

Before you write a single line of code or create your first prototype, you need to deeply understand the problem you're trying to solve. Here's why:

### 1. Reduces Risk
Starting with a validated problem significantly reduces the risk of building something nobody wants.

### 2. Saves Time and Money
Understanding the problem upfront prevents costly pivots and rebuilds later.

### 3. Attracts Investors
Investors fund solutions to real, significant problems. A well-articulated problem statement is crucial for fundraising.

## The Problem Discovery Framework

### Step 1: Start with Observation
Look for friction points in your daily life and the lives of people around you. The best startup ideas often come from personal experiences.

**Questions to ask:**
- What tasks do I find frustrating or time-consuming?
- What do I complain about regularly?
- What workarounds do I use to get things done?

### Step 2: Talk to Potential Customers
Once you've identified a potential problem, validate it by talking to people who might experience it.

**Customer Interview Script:**
1. Tell me about the last time you [relevant activity]
2. What was frustrating about that experience?
3. How do you currently solve this problem?
4. How much time/money does this problem cost you?
5. Have you tried other solutions? What didn't work?

### Step 3: Quantify the Problem
A good problem has three characteristics:
- **Frequent**: Happens regularly
- **Expensive**: Costs time, money, or frustration
- **Pervasive**: Affects many people

### Step 4: Define Your Problem Statement
Create a clear, concise problem statement:

"[Target customer] struggles with [specific problem] when [context], which leads to [negative outcome]."

## Common Mistakes to Avoid

### 1. Falling in Love with Your Solution
Don't start with a solution and look for a problem. Start with the problem.

### 2. Asking Leading Questions
"Wouldn't it be great if..." questions lead to biased answers.

### 3. Talking to the Wrong People
Make sure you're interviewing actual potential customers, not just anyone willing to talk.

### 4. Ignoring Existing Solutions
If no one has tried to solve this problem before, ask yourself why.

## Tools and Techniques

### Customer Interview Tools
- Calendly for scheduling
- Zoom for remote interviews
- Typeform for surveys
- Airtable for organizing insights

### Research Methods
- Online surveys
- Focus groups
- Observational studies
- Competitive analysis

## Case Study: Airbnb's Problem Discovery

Brian Chesky and Joe Gebbia identified the problem of expensive hotel accommodation during conferences. They validated this by:

1. Experiencing the problem themselves (couldn't afford a hotel)
2. Talking to other conference attendees
3. Creating a simple solution (air mattresses in their apartment)
4. Testing demand during a design conference

The key insight: people were willing to stay in strangers' homes if it saved money and provided a local experience.

## Next Steps

After completing your problem discovery:

1. **Prioritize problems** based on frequency, expense, and market size
2. **Create user personas** representing people with this problem
3. **Map the customer journey** showing when and how the problem occurs
4. **Begin solution ideation** with a deep understanding of the problem

## Action Items

- [ ] Identify 3 potential problems from your personal experience
- [ ] Interview 10 people about these problems
- [ ] Create a problem statement for your top validated problem
- [ ] Research existing solutions and their limitations

## Additional Resources

Use these resources to deepen your understanding of problem discovery:

- "The Mom Test" by Rob Fitzpatrick
- "Talking to Humans" by Giff Constable
- Customer Development methodology by Steve Blank
- Jobs-to-be-Done framework by Clayton Christensen

Remember: The goal isn't to find any problem to solve, but to find a problem you're passionate about solving and that enough people care about to build a business around.
      `,
      readTime: 12,
      difficulty: 'Beginner',
      tags: ['Problem Discovery', 'Customer Validation', 'Startup Fundamentals'],
      author: {
        name: 'Dr. Sarah Martinez',
        title: 'Entrepreneurship Professor, Stanford',
        avatar: '👩‍🏫'
      },
      publishedAt: '2024-01-15T10:00:00Z',
      updatedAt: '2024-01-20T14:30:00Z',
      rating: 4.8,
      reviews: 124,
      nextArticle: 'solution-validation',
      prevArticle: null,
      resources: [
        { title: 'Customer Interview Template', type: 'PDF', url: '#' },
        { title: 'Problem Statement Worksheet', type: 'PDF', url: '#' },
        { title: 'Interview Recording: Airbnb Founders', type: 'Video', url: '#' },
        { title: 'The Mom Test (Book)', type: 'Link', url: '#' }
      ]
    };

    setArticle(demoArticle);
    
    // Check if bookmarked
    const bookmarks = JSON.parse(localStorage.getItem(`bookmarks-${user?.id}`) || '[]');
    setIsBookmarked(bookmarks.includes(demoArticle.id));
  };

  const toggleBookmark = () => {
    if (!user || !article) return;
    
    const bookmarks = JSON.parse(localStorage.getItem(`bookmarks-${user.id}`) || '[]');
    let updatedBookmarks;
    
    if (isBookmarked) {
      updatedBookmarks = bookmarks.filter((id: string) => id !== article.id);
    } else {
      updatedBookmarks = [...bookmarks, article.id];
    }
    
    localStorage.setItem(`bookmarks-${user.id}`, JSON.stringify(updatedBookmarks));
    setIsBookmarked(!isBookmarked);
  };

  const toggleAudio = () => {
    setIsAudioPlaying(!isAudioPlaying);
    // In a real app, this would control text-to-speech
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article?.title,
        text: article?.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const goBack = () => {
    window.history.pushState({}, '', '/curriculum');
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Loading article...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Progress Bar */}
      <div className="fixed top-16 left-0 w-full z-40">
        <Progress value={readingProgress} className="h-1 rounded-none" />
      </div>

      {/* Back Button */}
      <Button 
        variant="ghost" 
        onClick={goBack}
        className="mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Curriculum
      </Button>

      {/* Article Header */}
      <Card className="p-8 mb-8">
        <div className="mb-6">
          <Badge variant="outline" className="mb-4">
            {article.category}
          </Badge>
          <h1 className="text-4xl font-bold mb-4">{article.title}</h1>
          <p className="text-xl text-muted-foreground mb-6">{article.description}</p>
          
          <div className="flex items-center flex-wrap gap-4 mb-6">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{article.readTime} min read</span>
            </div>
            
            <Badge variant={
              article.difficulty === 'Beginner' ? 'default' :
              article.difficulty === 'Intermediate' ? 'secondary' : 'destructive'
            }>
              {article.difficulty}
            </Badge>
            
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm">{article.rating}/5</span>
              <span className="text-sm text-muted-foreground">({article.reviews} reviews)</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-lg">{article.author.avatar || '👤'}</span>
              </div>
              <div>
                <div className="font-medium">{article.author.name}</div>
                <div className="text-sm text-muted-foreground">{article.author.title}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button 
                size="sm" 
                variant="ghost"
                onClick={toggleAudio}
              >
                {isAudioPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                Listen
              </Button>
              
              <Button 
                size="sm" 
                variant="ghost"
                onClick={toggleBookmark}
                className={isBookmarked ? 'text-primary' : ''}
              >
                <Bookmark className="w-4 h-4" />
                {isBookmarked ? 'Bookmarked' : 'Bookmark'}
              </Button>
              
              <Button size="sm" variant="ghost" onClick={handleShare}>
                <Share2 className="w-4 h-4" />
                Share
              </Button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {article.tags.map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Article Content */}
      <Card className="p-8 mb-8">
        <div className="prose prose-lg max-w-none">
          {article.content.split('\n').map((line, index) => {
            if (line.startsWith('# ')) {
              return <h1 key={index} className="text-3xl font-bold mt-8 mb-4">{line.substring(2)}</h1>;
            } else if (line.startsWith('## ')) {
              return <h2 key={index} className="text-2xl font-semibold mt-6 mb-3">{line.substring(3)}</h2>;
            } else if (line.startsWith('### ')) {
              return <h3 key={index} className="text-xl font-medium mt-4 mb-2">{line.substring(4)}</h3>;
            } else if (line.startsWith('- ')) {
              return <li key={index} className="ml-4">{line.substring(2)}</li>;
            } else if (line.trim() === '') {
              return <br key={index} />;
            } else if (line.startsWith('**') && line.endsWith('**')) {
              return <p key={index} className="font-semibold">{line.slice(2, -2)}</p>;
            } else {
              return <p key={index} className="mb-4">{line}</p>;
            }
          })}
        </div>
      </Card>

      {/* Resources */}
      <Card className="p-6 mb-8">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Download className="w-5 h-5" />
          Additional Resources
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {article.resources.map((resource, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded flex items-center justify-center">
                  <span className="text-xs">{resource.type.charAt(0)}</span>
                </div>
                <div>
                  <div className="font-medium text-sm">{resource.title}</div>
                  <div className="text-xs text-muted-foreground">{resource.type}</div>
                </div>
              </div>
              <Button size="sm" variant="outline">
                <Download className="w-3 h-3 mr-1" />
                Get
              </Button>
            </div>
          ))}
        </div>
      </Card>

      {/* Navigation */}
      <div className="flex justify-between mb-8">
        <Button 
          variant="outline" 
          disabled={!article.prevArticle}
          className="flex-1 mr-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous: Foundation Concepts
        </Button>
        
        <Button 
          variant="outline" 
          disabled={!article.nextArticle}
          className="flex-1 ml-2"
        >
          Next: Solution Validation
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      {/* Complete Section */}
      <Card className="p-6 text-center">
        <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <h3 className="font-semibold mb-2">Mark as Complete</h3>
        <p className="text-muted-foreground mb-4">
          Track your progress through the SMART Start Up curriculum
        </p>
        <Button className="btn-primary">
          Mark Complete & Continue
        </Button>
      </Card>
    </div>
  );
}