import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Switch } from '../components/ui/switch';
import { Separator } from '../components/ui/separator';
import { useAuth } from '../contexts/AuthContext';
import { 
  Settings, 
  Bell, 
  Shield, 
  Eye, 
  Download, 
  Trash2,
  Lock,
  Mail,
  Globe,
  Smartphone
} from 'lucide-react';

export function ProfileSettings() {
  const { user, updatePreferences, logout } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Please log in to access settings.</p>
        </div>
      </div>
    );
  }

  const handlePreferenceChange = (key: keyof typeof user.preferences, value: boolean) => {
    updatePreferences({ [key]: value });
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      return;
    }
    // Password change logic would go here
    console.log('Password change requested');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleDeleteAccount = () => {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      // Account deletion logic would go here
      console.log('Account deletion requested');
    }
  };

  const handleExportData = () => {
    // Data export logic would go here
    const userData = {
      profile: user,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };
    
    const blob = new Blob([JSON.stringify(userData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `smart-startup-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-muted-foreground">Manage your account preferences and privacy settings.</p>
      </div>

      <div className="space-y-8">
        {/* Notifications */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Bell className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Notifications</h2>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="notifications" className="text-base font-medium">
                  Push Notifications
                </Label>
                <p className="text-sm text-muted-foreground">
                  Receive notifications about applications, mentoring sessions, and updates
                </p>
              </div>
              <Switch
                id="notifications"
                checked={user.preferences.notifications}
                onCheckedChange={(checked) => handlePreferenceChange('notifications', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="emailUpdates" className="text-base font-medium">
                  Email Updates
                </Label>
                <p className="text-sm text-muted-foreground">
                  Get weekly newsletters and important announcements via email
                </p>
              </div>
              <Switch
                id="emailUpdates"
                checked={user.preferences.emailUpdates}
                onCheckedChange={(checked) => handlePreferenceChange('emailUpdates', checked)}
              />
            </div>
          </div>
        </Card>

        {/* Privacy */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Privacy & Security</h2>
          </div>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="publicProfile" className="text-base font-medium">
                  Public Profile
                </Label>
                <p className="text-sm text-muted-foreground">
                  Allow other users to see your profile in the startup directory
                </p>
              </div>
              <Switch
                id="publicProfile"
                checked={user.preferences.publicProfile}
                onCheckedChange={(checked) => handlePreferenceChange('publicProfile', checked)}
              />
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dataTracking" className="text-base font-medium">
                  Analytics & Tracking
                </Label>
                <p className="text-sm text-muted-foreground">
                  Help us improve the platform by sharing usage analytics
                </p>
              </div>
              <Switch
                id="dataTracking"
                checked={user.preferences.dataTracking}
                onCheckedChange={(checked) => handlePreferenceChange('dataTracking', checked)}
              />
            </div>
          </div>
        </Card>

        {/* Account Security */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Lock className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Account Security</h2>
          </div>
          
          <form onSubmit={handlePasswordChange} className="space-y-4">
            <div>
              <Label htmlFor="currentPassword">Current Password</Label>
              <Input
                id="currentPassword"
                type="password"
                placeholder="Enter current password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
              />
            </div>
            
            <div>
              <Label htmlFor="newPassword">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                placeholder="Enter new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            
            <div>
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
              />
            </div>
            
            <Button type="submit" disabled={!currentPassword || !newPassword || newPassword !== confirmPassword}>
              Update Password
            </Button>
          </form>
        </Card>

        {/* Data Management */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Download className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Data Management</h2>
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="font-medium mb-2">Export Your Data</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Download a copy of all your data stored in SMART Start Up
              </p>
              <Button variant="outline" onClick={handleExportData}>
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>

            <Separator />

            <div>
              <h3 className="font-medium mb-2 text-destructive">Delete Account</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Permanently delete your account and all associated data. This action cannot be undone.
              </p>
              <Button variant="destructive" onClick={handleDeleteAccount}>
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Account
              </Button>
            </div>
          </div>
        </Card>

        {/* Session Management */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Smartphone className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-semibold">Session Management</h2>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <p className="font-medium">Current Session</p>
                <p className="text-sm text-muted-foreground">
                  Chrome on Windows • Last active: Now
                </p>
              </div>
              <Button variant="outline" size="sm">
                Current
              </Button>
            </div>
            
            <div className="text-center">
              <Button variant="outline" onClick={logout}>
                Sign Out of All Devices
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}