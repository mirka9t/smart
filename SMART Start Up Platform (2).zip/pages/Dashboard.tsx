import React from 'react';
import { DashboardStats } from '../components/dashboard/DashboardStats';
import { Card } from '../components/ui/card';
import { useAuth } from '../contexts/AuthContext';
import { 
  Calendar,
  Bell,
  BookOpen,
  Users,
  Target,
  TrendingUp
} from 'lucide-react';

export function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Please log in to access your dashboard.</p>
        </div>
      </div>
    );
  }

  const upcomingEvents = [
    {
      id: 1,
      title: 'Mentoring Session with Sarah Chen',
      date: '2024-02-15',
      time: '2:00 PM',
      type: 'meeting'
    },
    {
      id: 2,
      title: 'Pitch Deck Review Deadline',
      date: '2024-02-18',
      time: '11:59 PM',
      type: 'deadline'
    },
    {
      id: 3,
      title: 'Startup Networking Event',
      date: '2024-02-20',
      time: '6:00 PM',
      type: 'event'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">
          Welcome back, {user.name.split(' ')[0]}! 👋
        </h1>
        <p className="text-muted-foreground">
          Here's what's happening with your startup journey today.
        </p>
      </div>

      {/* Main Dashboard Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Stats and Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <DashboardStats />
        </div>

        {/* Right Column - Sidebar */}
        <div className="space-y-6">
          {/* Upcoming Events */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Upcoming</h3>
            </div>
            
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    event.type === 'meeting' ? 'bg-blue-500' :
                    event.type === 'deadline' ? 'bg-red-500' : 'bg-green-500'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm leading-tight">{event.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(event.date).toLocaleDateString()} at {event.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Quick Links */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Quick Links</h3>
            </div>
            
            <div className="space-y-2">
              <button className="w-full text-left p-2 hover:bg-muted rounded-lg transition-colors">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">Find Mentors</span>
                </div>
              </button>
              
              <button className="w-full text-left p-2 hover:bg-muted rounded-lg transition-colors">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">Browse Programs</span>
                </div>
              </button>
              
              <button className="w-full text-left p-2 hover:bg-muted rounded-lg transition-colors">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">View Analytics</span>
                </div>
              </button>
            </div>
          </Card>

          {/* Notifications */}
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Recent Notifications</h3>
            </div>
            
            <div className="space-y-3">
              <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm font-medium text-blue-800">Application Update</p>
                <p className="text-xs text-blue-600">Your Techstars application is under review</p>
              </div>
              
              <div className="p-2 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm font-medium text-green-800">Session Confirmed</p>
                <p className="text-xs text-green-600">Mentoring session scheduled for tomorrow</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}