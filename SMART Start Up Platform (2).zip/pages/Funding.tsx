import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Progress } from '../components/ui/progress';
import { useModal } from '../components/modals/ModalSystem';
import { 
  notifications, 
  fundingNotifications, 
  resourceNotifications,
  generalNotifications,
  showSuccess 
} from '../utils/notifications';
import { 
  DollarSign, 
  Calendar, 
  MapPin, 
  Users, 
  TrendingUp, 
  Target, 
  Clock, 
  ExternalLink, 
  Search, 
  Filter, 
  Award, 
  Building, 
  Lightbulb,
  Bookmark,
  BookmarkCheck,
  Share2,
  AlertCircle,
  CheckCircle,
  Info
} from 'lucide-react';

interface FundingOpportunity {
  id: string;
  name: string;
  type: 'grant' | 'competition' | 'accelerator' | 'investor' | 'crowdfunding';
  amount: string;
  deadline: string;
  location: string;
  description: string;
  requirements: string[];
  tags: string[];
  website: string;
  difficulty: 'Low' | 'Medium' | 'High';
  timeline: string;
  success_rate?: string;
}

const FUNDING_OPPORTUNITIES: FundingOpportunity[] = [
  {
    id: 'thiel-fellowship',
    name: 'Thiel Fellowship',
    type: 'grant',
    amount: '$100,000',
    deadline: '2024-12-31',
    location: 'Global',
    description: 'Two-year program for entrepreneurs under 23 to skip or stop out of college and focus on their work, their research, and their self-education.',
    requirements: ['Under 23 years old', 'Drop out of college', 'Revolutionary idea', 'Strong team'],
    tags: ['Technology', 'Innovation', 'Early Stage'],
    website: 'https://thielfellowship.org',
    difficulty: 'High',
    timeline: '2 years',
    success_rate: '0.5%'
  },
  {
    id: 'techstars-accelerator',
    name: 'Techstars Accelerator',
    type: 'accelerator',
    amount: '$120,000',
    deadline: '2024-04-15',
    location: 'Multiple Cities',
    description: '13-week mentorship-driven accelerator program. Get funding, mentorship, and access to the Techstars network.',
    requirements: ['Working product', 'Committed team', 'Scalable business model'],
    tags: ['Accelerator', 'Mentorship', 'Global Network'],
    website: 'https://techstars.com',
    difficulty: 'Medium',
    timeline: '13 weeks',
    success_rate: '2%'
  },
  {
    id: 'entrepreneurs-challenge',
    name: 'Global Student Entrepreneur Awards',
    type: 'competition',
    amount: '$50,000',
    deadline: '2024-03-31',
    location: 'Global',
    description: 'Competition for students who own and operate a business while attending college or university.',
    requirements: ['Current student', 'Operating business', 'Undergraduate or graduate'],
    tags: ['Student', 'Competition', 'Business Growth'],
    website: 'https://gsea.org',
    difficulty: 'Medium',
    timeline: '6 months',
    success_rate: '5%'
  },
  {
    id: 'kickstarter-campaign',
    name: 'Kickstarter Crowdfunding',
    type: 'crowdfunding',
    amount: 'Variable',
    deadline: 'Ongoing',
    location: 'Global',
    description: 'Crowdfunding platform for creative projects. Great for consumer products and innovative ideas.',
    requirements: ['Creative project', 'Compelling story', 'Marketing plan'],
    tags: ['Crowdfunding', 'Consumer Products', 'Marketing'],
    website: 'https://kickstarter.com',
    difficulty: 'Low',
    timeline: '30-60 days',
    success_rate: '37%'
  },
  {
    id: 'first-round-dorm',
    name: 'First Round Dorm Room Fund',
    type: 'investor',
    amount: '$20,000',
    deadline: 'Rolling',
    location: 'US Universities',
    description: 'Provides funding and mentorship to student entrepreneurs at top universities.',
    requirements: ['Student at partner university', 'Early stage startup', 'Technology focus'],
    tags: ['Student', 'Early Stage', 'Technology'],
    website: 'https://dormroomfund.com',
    difficulty: 'Medium',
    timeline: '4-6 weeks',
    success_rate: '10%'
  },
  {
    id: 'amazon-alexa-fund',
    name: 'Alexa Accelerator',
    type: 'accelerator',
    amount: '$200,000',
    deadline: '2024-05-01',
    location: 'Seattle, WA',
    description: '13-week program for voice technology startups building on Alexa.',
    requirements: ['Voice technology focus', 'Alexa integration', 'B2C or B2B product'],
    tags: ['Voice Technology', 'AI', 'Amazon'],
    website: 'https://developer.amazon.com/alexa/accelerator',
    difficulty: 'High',
    timeline: '13 weeks',
    success_rate: '3%'
  }
];

// Funding readiness assessment questions
const READINESS_QUESTIONS = [
  {
    id: 'business-plan',
    question: 'Do you have a comprehensive business plan?',
    weight: 20
  },
  {
    id: 'mvp',
    question: 'Do you have a working MVP or prototype?',
    weight: 25
  },
  {
    id: 'market-validation',
    question: 'Have you validated your market and problem?',
    weight: 20
  },
  {
    id: 'team',
    question: 'Do you have a committed co-founder or team?',
    weight: 15
  },
  {
    id: 'traction',
    question: 'Do you have paying customers or strong user traction?',
    weight: 20
  }
];

export function Funding() {
  const [opportunities, setOpportunities] = useState<FundingOpportunity[]>(FUNDING_OPPORTUNITIES);
  const [filteredOpportunities, setFilteredOpportunities] = useState<FundingOpportunity[]>(FUNDING_OPPORTUNITIES);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [readinessAnswers, setReadinessAnswers] = useState<Record<string, boolean>>({});
  const [showReadinessResult, setShowReadinessResult] = useState(false);
  const [bookmarkedOpportunities, setBookmarkedOpportunities] = useState<Set<string>>(new Set());
  
  const { openModal } = useModal();

  useEffect(() => {
    // Load saved bookmarks
    const savedBookmarks = localStorage.getItem('smart-bookmarked-funding');
    if (savedBookmarks) {
      setBookmarkedOpportunities(new Set(JSON.parse(savedBookmarks)));
    }

    // Load saved readiness answers
    const savedAnswers = localStorage.getItem('smart-readiness-answers');
    if (savedAnswers) {
      const answers = JSON.parse(savedAnswers);
      setReadinessAnswers(answers);
      if (Object.keys(answers).length === READINESS_QUESTIONS.length) {
        setShowReadinessResult(true);
      }
    }
  }, []);

  // Filter opportunities based on search and filters
  useEffect(() => {
    let filtered = opportunities;

    if (searchTerm) {
      filtered = filtered.filter(opp =>
        opp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        opp.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        opp.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedType) {
      filtered = filtered.filter(opp => opp.type === selectedType);
    }

    if (selectedDifficulty) {
      filtered = filtered.filter(opp => opp.difficulty === selectedDifficulty);
    }

    setFilteredOpportunities(filtered);
  }, [opportunities, searchTerm, selectedType, selectedDifficulty]);

  // Calculate funding readiness score
  const calculateReadinessScore = () => {
    const answeredQuestions = Object.keys(readinessAnswers).length;
    if (answeredQuestions === 0) return 0;

    const totalWeight = READINESS_QUESTIONS.reduce((sum, q) => sum + q.weight, 0);
    const score = READINESS_QUESTIONS.reduce((sum, q) => {
      return sum + (readinessAnswers[q.id] ? q.weight : 0);
    }, 0);

    return Math.round((score / totalWeight) * 100);
  };

  const handleReadinessAnswer = (questionId: string, answer: boolean) => {
    const newAnswers = { ...readinessAnswers, [questionId]: answer };
    setReadinessAnswers(newAnswers);
    localStorage.setItem('smart-readiness-answers', JSON.stringify(newAnswers));
    
    if (Object.keys(newAnswers).length === READINESS_QUESTIONS.length) {
      setShowReadinessResult(true);
    }
  };

  const handleApplyToOpportunity = (opportunity: FundingOpportunity) => {
    openModal({
      type: 'apply-funding',
      title: 'Apply for Funding',
      data: { opportunityName: opportunity.name, opportunityId: opportunity.id },
      onConfirm: async (formData) => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        fundingNotifications.applied(opportunity.name);
        console.log('Funding application:', { opportunity: opportunity.id, ...formData });
      }
    });
  };

  const handleLearnMore = (opportunity: FundingOpportunity) => {
    window.open(opportunity.website, '_blank');
    notifications.info('Opening External Link', `Redirecting to ${opportunity.name} website...`);
  };

  const handleShareOpportunity = (opportunity: FundingOpportunity) => {
    const shareData = {
      title: opportunity.name,
      text: opportunity.description,
      url: opportunity.website,
    };

    openModal({
      type: 'share-content',
      title: 'Share Opportunity',
      data: { 
        contentType: 'Funding Opportunity',
        title: opportunity.name,
        url: shareData.url 
      },
      onConfirm: async () => {
        try {
          if (navigator.share && navigator.canShare(shareData)) {
            await navigator.share(shareData);
            showSuccess('Shared successfully!');
          } else {
            await navigator.clipboard.writeText(shareData.url);
            showSuccess('Link copied!', 'Opportunity link has been copied to clipboard.');
          }
        } catch (error) {
          notifications.error('Sharing failed', 'Please try copying the link manually.');
        }
      }
    });
  };

  const toggleBookmark = (opportunityId: string) => {
    const opportunity = opportunities.find(o => o.id === opportunityId);
    const newBookmarks = new Set(bookmarkedOpportunities);
    
    if (newBookmarks.has(opportunityId)) {
      newBookmarks.delete(opportunityId);
      showSuccess('Bookmark Removed', 'Opportunity removed from your bookmarks.');
    } else {
      newBookmarks.add(opportunityId);
      fundingNotifications.bookmarked(opportunity?.name || 'Opportunity');
    }
    
    setBookmarkedOpportunities(newBookmarks);
    localStorage.setItem('smart-bookmarked-funding', JSON.stringify(Array.from(newBookmarks)));
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedType('');
    setSelectedDifficulty('');
    showSuccess('Filters Cleared', 'All filters have been reset.');
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'grant': return Award;
      case 'competition': return Target;
      case 'accelerator': return TrendingUp;
      case 'investor': return Building;
      case 'crowdfunding': return Users;
      default: return DollarSign;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'grant': return 'bg-green-100 text-green-700';
      case 'competition': return 'bg-blue-100 text-blue-700';
      case 'accelerator': return 'bg-purple-100 text-purple-700';
      case 'investor': return 'bg-orange-100 text-orange-700';
      case 'crowdfunding': return 'bg-pink-100 text-pink-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Low': return 'bg-green-100 text-green-700';
      case 'Medium': return 'bg-yellow-100 text-yellow-700';
      case 'High': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getReadinessRecommendations = (score: number) => {
    if (score >= 80) {
      return {
        level: 'Investment Ready',
        color: 'text-green-600',
        recommendations: [
          'Apply to top-tier accelerators and VCs',
          'Consider Series A preparation',
          'Focus on scaling and growth metrics'
        ]
      };
    } else if (score >= 60) {
      return {
        level: 'Nearly Ready',
        color: 'text-orange-600',
        recommendations: [
          'Apply to seed funds and angels',
          'Strengthen weaker areas',
          'Consider accelerator programs'
        ]
      };
    } else {
      return {
        level: 'Early Stage',
        color: 'text-red-600',
        recommendations: [
          'Focus on grants and competitions',
          'Build MVP and validate market',
          'Consider bootstrapping initially'
        ]
      };
    }
  };

  const resetReadinessAssessment = () => {
    setReadinessAnswers({});
    setShowReadinessResult(false);
    localStorage.removeItem('smart-readiness-answers');
    showSuccess('Assessment Reset', 'You can now retake the readiness assessment.');
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1>Funding Opportunities</h1>
        <p className="text-lg">
          Discover grants, competitions, accelerators, and investors specifically for student entrepreneurs.
        </p>
      </div>

      <Tabs defaultValue="opportunities" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="readiness">Readiness Check</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="opportunities" className="space-y-6">
          {/* Search and Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search opportunities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              className="px-3 py-2 border border-border rounded-md bg-background"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              <option value="">All Types</option>
              <option value="grant">Grants</option>
              <option value="competition">Competitions</option>
              <option value="accelerator">Accelerators</option>
              <option value="investor">Investors</option>
              <option value="crowdfunding">Crowdfunding</option>
            </select>

            <select
              className="px-3 py-2 border border-border rounded-md bg-background"
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
            >
              <option value="">All Difficulties</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>

            <Button variant="outline" className="flex items-center gap-2" onClick={clearAllFilters}>
              <Filter className="w-4 h-4" />
              Clear Filters
            </Button>
          </div>

          {/* Results Summary */}
          <p className="text-muted-foreground">
            Showing {filteredOpportunities.length} of {opportunities.length} opportunities
          </p>

          {/* Opportunities Grid */}
          <div className="smart-grid">
            {filteredOpportunities.map((opportunity) => {
              const IconComponent = getTypeIcon(opportunity.type);
              
              return (
                <Card key={opportunity.id} className="smart-card">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`w-10 h-10 rounded-lg ${getTypeColor(opportunity.type)} flex items-center justify-center`}>
                        <IconComponent className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="font-semibold truncate">{opportunity.name}</h3>
                        <p className="text-sm text-muted-foreground capitalize">{opportunity.type}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-1 ml-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-1 h-8 w-8"
                        onClick={() => toggleBookmark(opportunity.id)}
                      >
                        {bookmarkedOpportunities.has(opportunity.id) ? (
                          <BookmarkCheck className="w-4 h-4 text-primary" />
                        ) : (
                          <Bookmark className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="p-1 h-8 w-8"
                        onClick={() => handleShareOpportunity(opportunity)}
                      >
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <Badge className={getDifficultyColor(opportunity.difficulty)}>
                      {opportunity.difficulty}
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                    {opportunity.description}
                  </p>

                  {/* Key Details */}
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm">
                      <DollarSign className="w-4 h-4 text-primary" />
                      <span className="font-medium">{opportunity.amount}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      <span>Deadline: {opportunity.deadline}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{opportunity.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>Timeline: {opportunity.timeline}</span>
                    </div>
                    {opportunity.success_rate && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Target className="w-4 h-4" />
                        <span>Success Rate: {opportunity.success_rate}</span>
                      </div>
                    )}
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {opportunity.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  {/* Requirements Preview */}
                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2">Key Requirements:</p>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {opportunity.requirements.slice(0, 3).map((req, index) => (
                        <li key={index} className="flex items-start gap-1">
                          <span className="text-primary mt-1">•</span>
                          <span>{req}</span>
                        </li>
                      ))}
                      {opportunity.requirements.length > 3 && (
                        <li className="flex items-start gap-1">
                          <span className="text-primary mt-1">•</span>
                          <span>+{opportunity.requirements.length - 3} more requirements</span>
                        </li>
                      )}
                    </ul>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1 btn-primary"
                      onClick={() => handleApplyToOpportunity(opportunity)}
                    >
                      Apply Now
                    </Button>
                    <Button 
                      variant="outline"
                      size="sm"
                      onClick={() => handleLearnMore(opportunity)}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Empty State */}
          {filteredOpportunities.length === 0 && (
            <div className="text-center py-12">
              <DollarSign className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No opportunities found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your search criteria or clearing filters.
              </p>
              <Button 
                variant="outline"
                onClick={clearAllFilters}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </TabsContent>

        <TabsContent value="readiness" className="space-y-6">
          <div className="max-w-4xl">
            <div className="smart-card mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2>Funding Readiness Assessment</h2>
                  <p className="text-muted-foreground">
                    Answer these questions to get personalized funding recommendations based on your startup's current stage.
                  </p>
                </div>
                {showReadinessResult && (
                  <Button variant="outline" onClick={resetReadinessAssessment}>
                    Retake Assessment
                  </Button>
                )}
              </div>

              <div className="space-y-6">
                {READINESS_QUESTIONS.map((question) => (
                  <div key={question.id} className="border-b border-border pb-4">
                    <p className="font-medium mb-3">{question.question}</p>
                    <div className="flex gap-4">
                      <Button
                        variant={readinessAnswers[question.id] === true ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleReadinessAnswer(question.id, true)}
                      >
                        Yes
                      </Button>
                      <Button
                        variant={readinessAnswers[question.id] === false ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleReadinessAnswer(question.id, false)}
                      >
                        No
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              {showReadinessResult && (
                <div className="mt-8 p-6 bg-muted rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <h3>Your Funding Readiness Score</h3>
                    <span className="text-3xl font-bold text-primary">{calculateReadinessScore()}%</span>
                  </div>
                  
                  <Progress value={calculateReadinessScore()} className="h-3 mb-6" />
                  
                  {(() => {
                    const score = calculateReadinessScore();
                    const recommendations = getReadinessRecommendations(score);
                    
                    return (
                      <div>
                        <p className={`font-medium mb-4 ${recommendations.color}`}>
                          Assessment: {recommendations.level}
                        </p>
                        
                        <div>
                          <p className="font-medium mb-2">Recommended next steps:</p>
                          <ul className="space-y-1">
                            {recommendations.recommendations.map((rec, index) => (
                              <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                                <CheckCircle className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          <div className="smart-grid">
            <Card className="smart-card cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => resourceNotifications.accessed('Funding Strategy Guide')}>
              <Lightbulb className="w-8 h-8 text-primary mb-4" />
              <h3>Funding Strategy Guide</h3>
              <p className="text-muted-foreground mb-4">
                Comprehensive guide to choosing the right funding path for your startup stage.
              </p>
              <Button className="btn-primary">Download Guide</Button>
            </Card>

            <Card className="smart-card cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => resourceNotifications.accessed('Investor Database')}>
              <Users className="w-8 h-8 text-primary mb-4" />
              <h3>Investor Database</h3>
              <p className="text-muted-foreground mb-4">
                Curated list of 500+ student-friendly investors with contact information and investment criteria.
              </p>
              <Button className="btn-primary">Access Database</Button>
            </Card>

            <Card className="smart-card cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => resourceNotifications.accessed('Pitch Deck Templates')}>
              <Target className="w-8 h-8 text-primary mb-4" />
              <h3>Pitch Deck Templates</h3>
              <p className="text-muted-foreground mb-4">
                Professional pitch deck templates used by successful student entrepreneurs.
              </p>
              <Button className="btn-primary">Get Templates</Button>
            </Card>

            <Card className="smart-card cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => resourceNotifications.accessed('Funding Calendar')}>
              <Calendar className="w-8 h-8 text-primary mb-4" />
              <h3>Funding Calendar</h3>
              <p className="text-muted-foreground mb-4">
                Stay updated with deadlines for competitions, grants, and accelerator applications.
              </p>
              <Button className="btn-primary">View Calendar</Button>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}