import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';
import { CheckCircle, PlayCircle, Clock, Book, Target, Users, Lightbulb, TrendingUp } from 'lucide-react';

// Curriculum data structure
const CURRICULUM_MODULES = [
  {
    id: 'module-1',
    title: 'Problem Discovery & Validation',
    description: 'Learn to identify real problems worth solving and validate them with potential customers.',
    duration: '2 weeks',
    difficulty: 'Beginner',
    lessons: [
      { id: 'lesson-1-1', title: 'Finding Problems Worth Solving', duration: '20 min', completed: true },
      { id: 'lesson-1-2', title: 'Customer Interview Techniques', duration: '25 min', completed: true },
      { id: 'lesson-1-3', title: 'Market Research Methods', duration: '30 min', completed: false },
      { id: 'lesson-1-4', title: 'Problem Validation Framework', duration: '35 min', completed: false }
    ],
    icon: Target,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    id: 'module-2',
    title: 'Solution Design & MVP',
    description: 'Design solutions that address validated problems and build your Minimum Viable Product.',
    duration: '3 weeks',
    difficulty: 'Intermediate',
    lessons: [
      { id: 'lesson-2-1', title: 'Solution Ideation Techniques', duration: '25 min', completed: false },
      { id: 'lesson-2-2', title: 'Feature Prioritization', duration: '30 min', completed: false },
      { id: 'lesson-2-3', title: 'MVP Planning & Development', duration: '45 min', completed: false },
      { id: 'lesson-2-4', title: 'No-Code Tools & Prototyping', duration: '40 min', completed: false },
      { id: 'lesson-2-5', title: 'User Testing Your MVP', duration: '35 min', completed: false }
    ],
    icon: Lightbulb,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50'
  },
  {
    id: 'module-3',
    title: 'Business Model & Strategy',
    description: 'Develop sustainable business models and go-to-market strategies.',
    duration: '2 weeks',
    difficulty: 'Intermediate',
    lessons: [
      { id: 'lesson-3-1', title: 'Business Model Canvas', duration: '30 min', completed: false },
      { id: 'lesson-3-2', title: 'Revenue Streams & Pricing', duration: '35 min', completed: false },
      { id: 'lesson-3-3', title: 'Go-to-Market Strategy', duration: '40 min', completed: false },
      { id: 'lesson-3-4', title: 'Unit Economics & Metrics', duration: '25 min', completed: false }
    ],
    icon: TrendingUp,
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    id: 'module-4',
    title: 'Team Building & Leadership',
    description: 'Build and lead high-performing teams while developing your leadership skills.',
    duration: '2 weeks',
    difficulty: 'Advanced',
    lessons: [
      { id: 'lesson-4-1', title: 'Finding Co-founders', duration: '25 min', completed: false },
      { id: 'lesson-4-2', title: 'Equity & Legal Basics', duration: '30 min', completed: false },
      { id: 'lesson-4-3', title: 'Team Culture & Values', duration: '20 min', completed: false },
      { id: 'lesson-4-4', title: 'Leadership in Uncertainty', duration: '35 min', completed: false }
    ],
    icon: Users,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50'
  },
  {
    id: 'module-5',
    title: 'Fundraising & Investment',
    description: 'Navigate the fundraising process and prepare compelling investor presentations.',
    duration: '3 weeks',
    difficulty: 'Advanced',
    lessons: [
      { id: 'lesson-5-1', title: 'Fundraising Fundamentals', duration: '30 min', completed: false },
      { id: 'lesson-5-2', title: 'Investor Types & Matching', duration: '25 min', completed: false },
      { id: 'lesson-5-3', title: 'Pitch Deck Masterclass', duration: '45 min', completed: false },
      { id: 'lesson-5-4', title: 'Due Diligence Process', duration: '35 min', completed: false },
      { id: 'lesson-5-5', title: 'Term Sheets & Negotiations', duration: '40 min', completed: false }
    ],
    icon: Book,
    color: 'text-indigo-600',
    bgColor: 'bg-indigo-50'
  }
];

// Load progress from localStorage
function loadProgress() {
  try {
    const saved = localStorage.getItem('smart-curriculum-progress');
    return saved ? JSON.parse(saved) : {};
  } catch {
    return {};
  }
}

// Save progress to localStorage
function saveProgress(progress: Record<string, boolean>) {
  try {
    localStorage.setItem('smart-curriculum-progress', JSON.stringify(progress));
  } catch (error) {
    console.error('Error saving progress:', error);
  }
}

export function Curriculum() {
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [progress, setProgress] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setProgress(loadProgress());
  }, []);

  const toggleLessonComplete = (lessonId: string) => {
    const newProgress = { ...progress, [lessonId]: !progress[lessonId] };
    setProgress(newProgress);
    saveProgress(newProgress);
  };

  const getModuleProgress = (moduleId: string) => {
    const module = CURRICULUM_MODULES.find(m => m.id === moduleId);
    if (!module) return 0;
    
    const completedLessons = module.lessons.filter(lesson => progress[lesson.id]).length;
    return Math.round((completedLessons / module.lessons.length) * 100);
  };

  const getTotalProgress = () => {
    const totalLessons = CURRICULUM_MODULES.reduce((sum, module) => sum + module.lessons.length, 0);
    const completedLessons = CURRICULUM_MODULES.reduce((sum, module) => 
      sum + module.lessons.filter(lesson => progress[lesson.id]).length, 0
    );
    return Math.round((completedLessons / totalLessons) * 100);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-700';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-700';
      case 'Advanced': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1>SMART Start Up Curriculum</h1>
        <p className="text-lg mb-6">
          A comprehensive learning path designed for student founders, covering everything from problem discovery to fundraising success.
        </p>
        
        {/* Overall Progress */}
        <div className="smart-card mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3>Your Progress</h3>
            <span className="text-2xl font-semibold text-primary">{getTotalProgress()}%</span>
          </div>
          <Progress value={getTotalProgress()} className="h-3" />
          <p className="text-sm text-muted-foreground mt-2">
            Keep going! You're making great progress on your entrepreneurial journey.
          </p>
        </div>
      </div>

      {/* Module Overview */}
      {!selectedModule && (
        <div className="smart-grid">
          {CURRICULUM_MODULES.map((module) => {
            const IconComponent = module.icon;
            const moduleProgress = getModuleProgress(module.id);
            const completedLessons = module.lessons.filter(lesson => progress[lesson.id]).length;
            
            return (
              <Card 
                key={module.id} 
                className="smart-card cursor-pointer hover:shadow-lg transition-all duration-200"
                onClick={() => setSelectedModule(module.id)}
              >
                <div className={`w-12 h-12 rounded-lg ${module.bgColor} flex items-center justify-center mb-4`}>
                  <IconComponent className={`w-6 h-6 ${module.color}`} />
                </div>
                
                <h3 className="mb-2">{module.title}</h3>
                <p className="text-muted-foreground mb-4">{module.description}</p>
                
                <div className="flex items-center gap-2 mb-4">
                  <Badge variant="outline" className="text-xs">
                    <Clock className="w-3 h-3 mr-1" />
                    {module.duration}
                  </Badge>
                  <Badge className={`text-xs ${getDifficultyColor(module.difficulty)}`}>
                    {module.difficulty}
                  </Badge>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span>{completedLessons} of {module.lessons.length} lessons</span>
                    <span>{moduleProgress}%</span>
                  </div>
                  <Progress value={moduleProgress} className="h-2" />
                </div>
                
                <Button className="w-full btn-primary">
                  {moduleProgress === 0 ? 'Start Module' : 'Continue Learning'}
                </Button>
              </Card>
            );
          })}
        </div>
      )}

      {/* Module Detail View */}
      {selectedModule && (
        <div>
          {(() => {
            const module = CURRICULUM_MODULES.find(m => m.id === selectedModule);
            if (!module) return null;
            
            const IconComponent = module.icon;
            const moduleProgress = getModuleProgress(module.id);
            
            return (
              <div>
                {/* Back Button */}
                <Button 
                  variant="outline" 
                  onClick={() => setSelectedModule(null)}
                  className="mb-6"
                >
                  ← Back to Curriculum
                </Button>
                
                {/* Module Header */}
                <div className="smart-card mb-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-16 h-16 rounded-lg ${module.bgColor} flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className={`w-8 h-8 ${module.color}`} />
                    </div>
                    
                    <div className="flex-1">
                      <h1 className="mb-2">{module.title}</h1>
                      <p className="text-lg text-muted-foreground mb-4">{module.description}</p>
                      
                      <div className="flex items-center gap-4 mb-4">
                        <Badge variant="outline">
                          <Clock className="w-3 h-3 mr-1" />
                          {module.duration}
                        </Badge>
                        <Badge className={getDifficultyColor(module.difficulty)}>
                          {module.difficulty}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {module.lessons.length} lessons
                        </span>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span>Module Progress</span>
                          <span>{moduleProgress}%</span>
                        </div>
                        <Progress value={moduleProgress} className="h-3" />
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Lessons List */}
                <div className="space-y-4">
                  {module.lessons.map((lesson, index) => {
                    const isCompleted = progress[lesson.id];
                    const isPrevCompleted = index === 0 || progress[module.lessons[index - 1].id];
                    const isAccessible = isPrevCompleted;
                    
                    return (
                      <Card 
                        key={lesson.id} 
                        className={`p-4 transition-all duration-200 ${
                          isAccessible ? 'cursor-pointer hover:shadow-md' : 'opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div 
                              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                isCompleted 
                                  ? 'bg-green-100 text-green-600' 
                                  : isAccessible 
                                    ? 'bg-primary text-primary-foreground'
                                    : 'bg-gray-100 text-gray-400'
                              }`}
                            >
                              {isCompleted ? (
                                <CheckCircle className="w-5 h-5" />
                              ) : (
                                <PlayCircle className="w-5 h-5" />
                              )}
                            </div>
                            
                            <div>
                              <h4 className="font-medium">{lesson.title}</h4>
                              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                <Clock className="w-3 h-3" />
                                {lesson.duration}
                                {isCompleted && (
                                  <Badge variant="outline" className="ml-2 text-xs">
                                    Completed
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {isAccessible && (
                              <Button
                                variant={isCompleted ? "outline" : "default"}
                                size="sm"
                                onClick={() => toggleLessonComplete(lesson.id)}
                              >
                                {isCompleted ? 'Mark Incomplete' : 'Mark Complete'}
                              </Button>
                            )}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
                
                {/* Module Completion */}
                {moduleProgress === 100 && (
                  <Card className="mt-6 p-6 bg-green-50 border-green-200">
                    <div className="text-center">
                      <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                      <h3 className="text-green-900 mb-2">Module Completed! 🎉</h3>
                      <p className="text-green-700 mb-4">
                        Congratulations on completing {module.title}. You're ready for the next challenge!
                      </p>
                      <Button 
                        className="btn-primary"
                        onClick={() => setSelectedModule(null)}
                      >
                        Continue to Next Module
                      </Button>
                    </div>
                  </Card>
                )}
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}