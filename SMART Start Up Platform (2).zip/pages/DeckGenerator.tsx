import React, { useState, useEffect } from 'react';
import { Save, Download, Eye, ArrowLeft, ArrowRight, HelpCircle } from 'lucide-react';
import { getUserData, saveDeckSlide, toggleDeckEnhancer } from '../utils/storage';

const GPS_SLIDES = [
  {
    id: 'title',
    title: 'Title & Hook',
    prompt: 'State your one-line value and the forcing function that makes this the right time.',
    fields: ['headline', 'subtitle', 'presenter']
  },
  {
    id: 'problem',
    title: 'Problem',
    prompt: 'Who hurts, how often, and how expensive is it today?',
    fields: ['headline', 'painPoints', 'frequency', 'cost']
  },
  {
    id: 'alternatives',
    title: 'Alternatives',
    prompt: 'What do people do today? Why is it broken?',
    fields: ['headline', 'currentSolutions', 'limitations']
  },
  {
    id: 'solution',
    title: 'Solution',
    prompt: 'Your unique approach and core insight.',
    fields: ['headline', 'coreInsight', 'approach']
  },
  {
    id: 'market',
    title: 'Market',
    prompt: 'Define your ICP; show bottom-up SOM for your first 24 months.',
    fields: ['headline', 'icp', 'som', 'sam']
  },
  {
    id: 'business-model',
    title: 'Business Model',
    prompt: 'How you make money, unit economics, pricing strategy.',
    fields: ['headline', 'revenueModel', 'pricing', 'unitEconomics']
  },
  {
    id: 'gtm',
    title: 'Go-to-Market',
    prompt: 'What is your first wedge? Explain the repeatable loop in one line.',
    fields: ['headline', 'firstWedge', 'acquisitionLoop', 'channels']
  },
  {
    id: 'traction',
    title: 'Traction',
    prompt: 'Time-stamped progress with key metrics.',
    fields: ['headline', 'keyMetrics', 'timeline', 'proof']
  },
  {
    id: 'competition',
    title: 'Competition & Moat',
    prompt: 'Competitive landscape and your sustainable advantage.',
    fields: ['headline', 'competitors', 'moat', 'differentiation']
  },
  {
    id: 'team',
    title: 'Team',
    prompt: 'Why are you the right team to solve this problem?',
    fields: ['headline', 'founders', 'advisors', 'experience']
  },
  {
    id: 'roadmap',
    title: 'Roadmap',
    prompt: 'Key milestones for the next 18-24 months.',
    fields: ['headline', 'milestones', 'timeline', 'resources']
  },
  {
    id: 'financial',
    title: 'Financial Snapshot',
    prompt: 'Revenue projections, key metrics, uses of funds.',
    fields: ['headline', 'projections', 'keyMetrics', 'usesOfFunds']
  },
  {
    id: 'ask',
    title: 'Ask',
    prompt: 'How much, what instrument, and which milestones will this unlock by month 18?',
    fields: ['headline', 'amount', 'instrument', 'milestones']
  },
  {
    id: 'risks',
    title: 'Risks & Mitigations',
    prompt: 'Biggest risks and how you plan to address them.',
    fields: ['headline', 'risks', 'mitigations']
  },
  {
    id: 'close',
    title: 'Close',
    prompt: 'Strong close with clear next steps.',
    fields: ['headline', 'nextSteps', 'contact']
  }
];

const ENHANCERS = {
  harvard: 'Harvard (Milestone-based asks)',
  stanford: 'Stanford (Narrative arc)',
  mit: 'MIT (Technical validation)',
  berkeley: 'Berkeley (Unit economics)',
  wharton: 'Wharton (Capital plan)',
  oxbridge: 'Oxbridge (Policy/ethics)',
  imperial: 'Imperial (Engineering depth)'
};

export function DeckGenerator() {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [deckData, setDeckData] = useState<any>({});
  const [enhancers, setEnhancers] = useState<Record<string, boolean>>({});
  const [showPreview, setShowPreview] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  const currentSlide = GPS_SLIDES[currentSlideIndex];

  useEffect(() => {
    const userData = getUserData();
    setDeckData(userData.deck.slides);
    setEnhancers(userData.deck.enhancers);
    if (userData.deck.lastModified) {
      setLastSaved(new Date(userData.deck.lastModified));
    }
  }, []);

  const handleFieldChange = (field: string, value: string) => {
    const updatedSlideData = {
      ...deckData[currentSlide.id],
      [field]: value
    };
    
    setDeckData({
      ...deckData,
      [currentSlide.id]: updatedSlideData
    });

    // Auto-save
    saveDeckSlide(currentSlide.id, updatedSlideData);
    setLastSaved(new Date());
  };

  const handleEnhancerToggle = (enhancer: string) => {
    const newValue = !enhancers[enhancer];
    setEnhancers({
      ...enhancers,
      [enhancer]: newValue
    });
    toggleDeckEnhancer(enhancer, newValue);
  };

  const exportDeck = () => {
    const deckHtml = generateDeckHTML();
    const blob = new Blob([deckHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pitch-deck.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const generateDeckHTML = () => {
    return `
<!DOCTYPE html>
<html>
<head>
    <title>GPS v1.0 Pitch Deck</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .slide { page-break-after: always; min-height: 90vh; padding: 40px; border: 1px solid #ccc; margin-bottom: 20px; }
        h1 { color: #192441; margin-bottom: 20px; }
        h2 { color: #f7a524; margin-bottom: 15px; }
        p { line-height: 1.6; margin-bottom: 10px; }
        .slide:last-child { page-break-after: auto; }
    </style>
</head>
<body>
    ${GPS_SLIDES.map(slide => `
        <div class="slide">
            <h1>${slide.title}</h1>
            ${deckData[slide.id]?.headline ? `<h2>${deckData[slide.id].headline}</h2>` : ''}
            ${Object.entries(deckData[slide.id] || {})
              .filter(([key]) => key !== 'headline')
              .map(([key, value]) => `<p><strong>${key}:</strong> ${value}</p>`)
              .join('')}
        </div>
    `).join('')}
</body>
</html>
    `;
  };

  const getSlideHealth = (slideId: string) => {
    const slideData = deckData[slideId];
    if (!slideData) return 'red';
    
    const filledFields = Object.values(slideData).filter(value => 
      typeof value === 'string' && value.trim().length > 0
    ).length;
    
    if (filledFields === 0) return 'red';
    if (filledFields < 2) return 'orange';
    return 'green';
  };

  if (showPreview) {
    return <DeckPreview deckData={deckData} onBack={() => setShowPreview(false)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Build Your GPS v1.0 Pitch Deck</h1>
              <p className="text-gray-600 mt-1">
                {lastSaved ? `Last saved: ${lastSaved.toLocaleTimeString()}` : 'Not saved yet'}
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowPreview(true)}
                className="btn-secondary flex items-center"
              >
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </button>
              <button
                onClick={exportDeck}
                className="btn-primary flex items-center"
              >
                <Download className="h-4 w-4 mr-2" />
                Export HTML
              </button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Slide Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Slides</h3>
              <div className="space-y-2">
                {GPS_SLIDES.map((slide, index) => {
                  const health = getSlideHealth(slide.id);
                  const healthColors = {
                    green: 'bg-green-100 border-green-500 text-green-700',
                    orange: 'bg-orange-100 border-orange-500 text-orange-700',
                    red: 'bg-red-100 border-red-500 text-red-700'
                  };
                  
                  return (
                    <button
                      key={slide.id}
                      onClick={() => setCurrentSlideIndex(index)}
                      className={`w-full text-left p-3 rounded-lg border-2 transition-colors ${
                        index === currentSlideIndex
                          ? 'bg-orange-100 border-orange-500 text-orange-700'
                          : `${healthColors[health]} hover:bg-gray-50`
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{slide.title}</span>
                        <div className={`w-2 h-2 rounded-full ${
                          health === 'green' ? 'bg-green-500' :
                          health === 'orange' ? 'bg-orange-500' : 'bg-red-500'
                        }`}></div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Enhancers */}
              <div className="mt-8">
                <h3 className="font-semibold text-gray-900 mb-4">Program Enhancers</h3>
                <div className="space-y-2">
                  {Object.entries(ENHANCERS).map(([key, label]) => (
                    <label key={key} className="flex items-center">
                      <input
                        type="checkbox"
                        checked={enhancers[key] || false}
                        onChange={() => handleEnhancerToggle(key)}
                        className="rounded border-gray-300 text-orange-600 focus:ring-orange-500 mr-2"
                      />
                      <span className="text-sm text-gray-700">{label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Slide Editor */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow-sm p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{currentSlide.title}</h2>
                  <div className="flex items-center text-sm text-gray-600 mt-1">
                    <HelpCircle className="h-4 w-4 mr-1" />
                    {currentSlide.prompt}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1))}
                    disabled={currentSlideIndex === 0}
                    className="p-2 text-gray-400 hover:text-gray-600 disabled:opacity-50"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setCurrentSlideIndex(Math.min(GPS_SLIDES.length - 1, currentSlideIndex + 1))}
                    disabled={currentSlideIndex === GPS_SLIDES.length - 1}
                    className="p-2 text-gray-400 hover:text-gray-600 disabled:opacity-50"
                  >
                    <ArrowRight className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="space-y-6">
                {currentSlide.fields.map(field => (
                  <div key={field}>
                    <label className="block text-sm font-medium text-gray-700 mb-2 capitalize">
                      {field.replace(/([A-Z])/g, ' $1').toLowerCase()}
                    </label>
                    {field === 'headline' ? (
                      <input
                        type="text"
                        value={deckData[currentSlide.id]?.[field] || ''}
                        onChange={(e) => handleFieldChange(field, e.target.value)}
                        className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                        placeholder="Enter a compelling headline..."
                        maxLength={90}
                      />
                    ) : (
                      <textarea
                        value={deckData[currentSlide.id]?.[field] || ''}
                        onChange={(e) => handleFieldChange(field, e.target.value)}
                        rows={4}
                        className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                        placeholder={`Enter ${field}...`}
                      />
                    )}
                    {field === 'headline' && (
                      <div className="text-xs text-gray-500 mt-1">
                        {(deckData[currentSlide.id]?.[field] || '').length}/90 characters
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Enhanced Tips */}
              {Object.entries(enhancers).some(([key, enabled]) => enabled) && (
                <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Enhanced Tips Active:</h4>
                  <div className="text-sm text-blue-700 space-y-1">
                    {enhancers.harvard && <p>• <strong>Harvard:</strong> Emphasize milestone-based asks and clear timelines</p>}
                    {enhancers.stanford && <p>• <strong>Stanford:</strong> Focus on narrative arc and founder insight</p>}
                    {enhancers.mit && <p>• <strong>MIT:</strong> Include technical validation and experiments</p>}
                    {enhancers.berkeley && <p>• <strong>Berkeley:</strong> Show detailed unit economics</p>}
                    {enhancers.wharton && <p>• <strong>Wharton:</strong> Include capital plan and dilution scenarios</p>}
                    {enhancers.oxbridge && <p>• <strong>Oxbridge:</strong> Consider policy, regulatory, and ethical implications</p>}
                    {enhancers.imperial && <p>• <strong>Imperial:</strong> Demonstrate engineering depth and industry partnerships</p>}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DeckPreview({ deckData, onBack }: { deckData: any; onBack: () => void }) {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="p-4">
        <button onClick={onBack} className="text-orange-400 hover:text-orange-300 mb-4 flex items-center">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Editor
        </button>
      </div>
      
      <div className="max-w-4xl mx-auto px-4 space-y-8">
        {GPS_SLIDES.map(slide => (
          <div key={slide.id} className="bg-white text-gray-900 rounded-lg p-8 min-h-[400px]">
            <h1 className="text-3xl font-bold text-gray-900 mb-6">{slide.title}</h1>
            {deckData[slide.id]?.headline && (
              <h2 className="text-2xl font-semibold text-orange-600 mb-4">
                {deckData[slide.id].headline}
              </h2>
            )}
            <div className="space-y-3">
              {Object.entries(deckData[slide.id] || {})
                .filter(([key]) => key !== 'headline')
                .map(([key, value]) => (
                  <div key={key}>
                    <strong className="capitalize">{key.replace(/([A-Z])/g, ' $1')}:</strong>
                    <p className="mt-1 text-gray-700">{value as string}</p>
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}