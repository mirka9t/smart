import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Download, Plus } from 'lucide-react';
import { saveRehearsalLog, getUserData } from '../utils/storage';
import { loadQuestions } from '../utils/dataLoader';

interface Question {
  question: string;
  notes: string;
}

export function RehearsalStudio() {
  const [mode, setMode] = useState<'5min' | '7min' | '10min'>('5min');
  const [isRunning, setIsRunning] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds
  const [questions, setQuestions] = useState<Question[]>([]);
  const [runNotes, setRunNotes] = useState('');
  const [logs, setLogs] = useState<any[]>([]);

  const modes = {
    '5min': 300,
    '7min': 420,
    '10min': 600
  };

  useEffect(() => {
    setTimeLeft(modes[mode]);
  }, [mode]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(time => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
      // Auto-prompt to save log when timer ends
      if (timeLeft === 0) {
        setTimeout(() => {
          const save = confirm('Time\'s up! Would you like to save this rehearsal log?');
          if (save) {
            handleSaveLog();
          }
        }, 500);
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  useEffect(() => {
    // Load existing logs
    const userData = getUserData();
    setLogs(userData.rehearsals);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(modes[mode]);
  };

  const generateQuestions = async () => {
    try {
      const questionData = await loadQuestions();
      
      // Flatten all questions from all categories
      const allQuestions = questionData.flatMap(category => category.questions);
      
      // Randomize and select 5 questions
      const randomQuestions = allQuestions
        .sort(() => Math.random() - 0.5)
        .slice(0, 5)
        .map((q: string) => ({ question: q, notes: '' }));
      
      setQuestions(randomQuestions);
    } catch (error) {
      console.error('Failed to load questions:', error);
      // This shouldn't happen as loadQuestions has its own fallbacks
      setQuestions([
        { question: 'What problem are you solving and why now?', notes: '' },
        { question: 'Who is your target customer?', notes: '' },
        { question: 'What\'s your business model?', notes: '' },
        { question: 'How do you plan to acquire customers?', notes: '' },
        { question: 'What are the biggest risks to your business?', notes: '' }
      ]);
    }
  };

  const updateQuestionNotes = (index: number, notes: string) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index].notes = notes;
    setQuestions(updatedQuestions);
  };

  const handleSaveLog = () => {
    const totalTime = modes[mode];
    const actualTime = totalTime - timeLeft;
    
    saveRehearsalLog({
      date: new Date().toISOString(),
      duration: actualTime,
      mode,
      notes: runNotes,
      questions: questions
    });

    // Refresh logs
    const userData = getUserData();
    setLogs(userData.rehearsals);

    // Reset for next run
    setRunNotes('');
    setQuestions([]);
    handleReset();
    
    alert('Rehearsal log saved! Great job on the practice run.');
  };

  const exportLogs = () => {
    const exportData = logs.map(log => ({
      date: new Date(log.date).toLocaleDateString(),
      duration: `${Math.floor(log.duration / 60)}:${(log.duration % 60).toString().padStart(2, '0')}`,
      mode: log.mode,
      notes: log.notes,
      questions: log.questions.map((q: Question) => `Q: ${q.question}\nA: ${q.notes}`).join('\n\n')
    }));

    const text = exportData.map(log => 
      `Date: ${log.date}\nDuration: ${log.duration}\nMode: ${log.mode}\nNotes: ${log.notes}\n\nQuestions:\n${log.questions}\n\n---\n\n`
    ).join('');

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rehearsal-logs.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Rehearsal Studio</h1>
          <p className="text-lg text-gray-600">Practice your pitch with timed sessions and Q&A preparation.</p>
        </div>

        {/* Timer Section */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <div className="text-center">
            {/* Mode Selection */}
            <div className="flex justify-center gap-4 mb-8">
              {Object.keys(modes).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m as keyof typeof modes)}
                  className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                    mode === m
                      ? 'bg-orange-500 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            {/* Timer Display */}
            <div className="mb-8">
              <div className={`text-6xl sm:text-8xl font-mono mb-4 ${
                timeLeft <= 30 && isRunning ? 'text-red-500' : 'text-gray-900'
              }`}>
                {formatTime(timeLeft)}
              </div>
              
              {timeLeft <= 30 && isRunning && (
                <div className="text-red-500 font-medium animate-pulse">
                  Time running out!
                </div>
              )}
            </div>

            {/* Timer Controls */}
            <div className="flex justify-center gap-4 mb-8">
              {!isRunning ? (
                <button onClick={handleStart} className="btn-primary flex items-center text-lg px-8 py-3">
                  <Play className="h-5 w-5 mr-2" />
                  Start
                </button>
              ) : (
                <button onClick={handlePause} className="btn-secondary flex items-center text-lg px-8 py-3">
                  <Pause className="h-5 w-5 mr-2" />
                  Pause
                </button>
              )}
              
              <button onClick={handleReset} className="btn-secondary flex items-center text-lg px-8 py-3">
                <RotateCcw className="h-5 w-5 mr-2" />
                Reset
              </button>
            </div>

            {/* Run Notes */}
            <div className="max-w-md mx-auto">
              <label className="block text-sm font-medium text-gray-700 mb-2">Session Notes</label>
              <textarea
                value={runNotes}
                onChange={(e) => setRunNotes(e.target.value)}
                rows={3}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                placeholder="How did this rehearsal go? What would you improve?"
              />
            </div>
          </div>
        </div>

        {/* Q&A Section */}
        <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Q&A Generator</h2>
            <button
              onClick={generateQuestions}
              className="btn-primary flex items-center"
            >
              <Plus className="h-4 w-4 mr-2" />
              Generate 5 Questions
            </button>
          </div>

          {questions.length > 0 && (
            <div className="space-y-6">
              {questions.map((q, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <h3 className="font-medium text-gray-900 mb-3">
                    Q{index + 1}: {q.question}
                  </h3>
                  <textarea
                    value={q.notes}
                    onChange={(e) => updateQuestionNotes(index, e.target.value)}
                    rows={3}
                    className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                    placeholder="Your answer notes..."
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Save & Export */}
        {(questions.length > 0 || runNotes.trim()) && (
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <div className="flex gap-4 justify-center">
              <button onClick={handleSaveLog} className="btn-primary">
                Save Rehearsal Log
              </button>
            </div>
          </div>
        )}

        {/* Recent Logs */}
        {logs.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Recent Rehearsals</h2>
              <button onClick={exportLogs} className="btn-secondary flex items-center">
                <Download className="h-4 w-4 mr-2" />
                Export All
              </button>
            </div>

            <div className="space-y-4">
              {logs.slice(-5).reverse().map((log, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">
                      {new Date(log.date).toLocaleDateString()} - {log.mode}
                    </span>
                    <span className="text-sm text-gray-500">
                      {Math.floor(log.duration / 60)}:{(log.duration % 60).toString().padStart(2, '0')}
                    </span>
                  </div>
                  {log.notes && (
                    <p className="text-gray-600 text-sm">{log.notes}</p>
                  )}
                  <div className="text-xs text-gray-500 mt-2">
                    {log.questions.length} questions practiced
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}