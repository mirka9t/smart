import React, { useState, useEffect } from 'react';
import { Search, Filter, Heart, ArrowRight, Building, Users, TrendingUp } from 'lucide-react';
import { toggleFavorite, isFavorite } from '../utils/storage';
import { loadStartups, type Startup } from '../utils/dataLoader';

// Extended interface to handle both JSON structure and dataLoader structure
interface StartupData {
  id: string;
  name: string;
  // Handle both structures
  oneLiner?: string;
  tagline?: string;
  stage: string;
  sector?: string;
  industry?: string;
  metrics?: string;
  founded: string;
  team?: string[];
  founders?: string[];
  problem?: string;
  solution?: string;
  description?: string;
  traction?: Array<{ date: string; metric: string }>;
  lookingForFunding?: boolean;
  contact?: string;
  website?: string;
  location?: string;
  funding?: string;
  employees?: string;
  tags?: string[];
  socialLinks?: {
    linkedin?: string;
    twitter?: string;
    instagram?: string;
  };
}

export function Startups() {
  const [startups, setStartups] = useState<StartupData[]>([]);
  const [filteredStartups, setFilteredStartups] = useState<StartupData[]>([]);
  const [selectedStartup, setSelectedStartup] = useState<StartupData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    stage: '',
    sector: '',
    lookingForFunding: false,
    search: ''
  });
  const [favorites, setFavorites] = useState<Set<string>>(new Set());

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        console.log('🚀 Starting to load startups data...');
        
        // Try to load from JSON first, then fallback to dataLoader
        let data: StartupData[] = [];
        
        try {
          const jsonResponse = await fetch('/data/startups.json');
          if (jsonResponse.ok) {
            const jsonData = await jsonResponse.json();
            if (Array.isArray(jsonData) && jsonData.length > 0) {
              data = jsonData;
              console.log('📊 Loaded startups from JSON:', data.length, 'startups');
            }
          }
        } catch (jsonError) {
          console.log('JSON loading failed, using fallback data');
        }
        
        // If JSON loading failed, use dataLoader fallback
        if (data.length === 0) {
          const fallbackData = await loadStartups();
          // Transform dataLoader format to our unified format
          data = fallbackData.map(startup => ({
            ...startup,
            oneLiner: startup.tagline,
            sector: startup.industry,
            team: startup.founders,
            metrics: startup.funding || 'Early stage',
            lookingForFunding: true,
            traction: [],
            problem: startup.description,
            solution: startup.description,
            contact: `contact@${startup.name.toLowerCase().replace(/\s+/g, '')}.com`
          }));
          console.log('📈 Using fallback startups data:', data.length, 'startups');
        }
        
        if (!data || !Array.isArray(data)) {
          throw new Error('Invalid startups data received');
        }
        
        setStartups(data);
        setFilteredStartups(data);
        setError(null);
        
        // Load favorites
        const favs = new Set<string>();
        data.forEach((startup: StartupData) => {
          if (isFavorite('startups', startup.id)) {
            favs.add(startup.id);
          }
        });
        setFavorites(favs);
        console.log('✅ Successfully loaded startups and favorites');
      } catch (err) {
        console.error('💥 Failed to load startups:', err);
        setError(`Failed to load startups: ${err instanceof Error ? err.message : String(err)}`);
        
        // Even if there's an error, try to set empty array to prevent crashes
        setStartups([]);
        setFilteredStartups([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  useEffect(() => {
    let filtered = startups;

    if (filters.stage) {
      filtered = filtered.filter(s => s.stage.toLowerCase() === filters.stage.toLowerCase());
    }

    if (filters.sector) {
      const sector = filters.sector.toLowerCase();
      filtered = filtered.filter(s => 
        (s.sector && s.sector.toLowerCase() === sector) ||
        (s.industry && s.industry.toLowerCase() === sector)
      );
    }

    if (filters.lookingForFunding) {
      filtered = filtered.filter(s => s.lookingForFunding);
    }

    if (filters.search) {
      const search = filters.search.toLowerCase();
      filtered = filtered.filter(s => 
        s.name.toLowerCase().includes(search) ||
        (s.oneLiner && s.oneLiner.toLowerCase().includes(search)) ||
        (s.tagline && s.tagline.toLowerCase().includes(search)) ||
        (s.sector && s.sector.toLowerCase().includes(search)) ||
        (s.industry && s.industry.toLowerCase().includes(search))
      );
    }

    setFilteredStartups(filtered);
  }, [startups, filters]);

  const handleToggleFavorite = (startupId: string) => {
    const newIsFavorite = toggleFavorite('startups', startupId);
    const newFavorites = new Set(favorites);
    
    if (newIsFavorite) {
      newFavorites.add(startupId);
    } else {
      newFavorites.delete(startupId);
    }
    
    setFavorites(newFavorites);
  };

  // Get unique sectors from both possible property names
  const uniqueSectors = Array.from(new Set(
    startups.map(s => s.sector || s.industry).filter(Boolean)
  ));

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading startups...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="btn-primary"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  if (selectedStartup) {
    return (
      <StartupDetail 
        startup={selectedStartup} 
        onBack={() => setSelectedStartup(null)}
        isFavorited={favorites.has(selectedStartup.id)}
        onToggleFavorite={() => handleToggleFavorite(selectedStartup.id)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Startups Directory</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Discover what our community of student founders is building and get inspired for your own venture.
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="h-5 w-5 text-gray-400" />
            <span className="font-medium text-gray-700">Filters</span>
          </div>
          
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Stage</label>
              <select 
                value={filters.stage} 
                onChange={(e) => setFilters({...filters, stage: e.target.value})}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                <option value="">All Stages</option>
                <option value="idea">Idea</option>
                <option value="mvp">MVP</option>
                <option value="scaling">Scaling</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Sector</label>
              <select 
                value={filters.sector} 
                onChange={(e) => setFilters({...filters, sector: e.target.value})}
                className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
              >
                <option value="">All Sectors</option>
                {uniqueSectors.map(sector => (
                  <option key={sector} value={sector}>{sector}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
              <div className="relative">
                <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input 
                  type="text"
                  value={filters.search}
                  onChange={(e) => setFilters({...filters, search: e.target.value})}
                  placeholder="Search startups..."
                  className="w-full pl-10 pr-3 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
            </div>
            
            <div className="flex items-end">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.lookingForFunding}
                  onChange={(e) => setFilters({...filters, lookingForFunding: e.target.checked})}
                  className="rounded border-gray-300 text-orange-600 focus:ring-orange-500 mr-2"
                />
                <span className="text-sm text-gray-700">Looking for funding</span>
              </label>
            </div>
          </div>
        </div>

        {/* Startups Grid */}
        <div className="smart-grid">
          {filteredStartups.map(startup => (
            <StartupCard 
              key={startup.id} 
              startup={startup} 
              onClick={() => setSelectedStartup(startup)}
              isFavorited={favorites.has(startup.id)}
              onToggleFavorite={() => handleToggleFavorite(startup.id)}
            />
          ))}
        </div>

        {filteredStartups.length === 0 && (
          <div className="text-center py-12">
            <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No startups match your filters. Try adjusting your search criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function StartupCard({ startup, onClick, isFavorited, onToggleFavorite }: {
  startup: StartupData;
  onClick: () => void;
  isFavorited: boolean;
  onToggleFavorite: () => void;
}) {
  const stageColors: Record<string, string> = {
    idea: 'badge-stage-idea',
    mvp: 'badge-stage-mvp',
    scaling: 'badge-stage-scaling'
  };

  // Safely get stage color
  const getStageClass = (stage: string) => {
    const normalizedStage = stage.toLowerCase();
    return stageColors[normalizedStage] || 'badge-stage-idea';
  };

  // Safely get team members
  const getTeamMembers = () => {
    const team = startup.team || startup.founders || [];
    return team.length > 0 ? team.join(', ') : 'Team information not available';
  };

  return (
    <div className="smart-card">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <h3 className="text-lg font-semibold text-gray-900">{startup.name}</h3>
            <span className={getStageClass(startup.stage)}>{startup.stage}</span>
          </div>
          <span className="text-sm text-gray-500">{startup.sector || startup.industry}</span>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
          className={`p-2 rounded-full transition-colors ${
            isFavorited 
              ? 'text-red-500 hover:text-red-600' 
              : 'text-gray-400 hover:text-red-500'
          }`}
        >
          <Heart className={`h-5 w-5 ${isFavorited ? 'fill-current' : ''}`} />
        </button>
      </div>

      <p className="text-gray-600 mb-4">{startup.oneLiner || startup.tagline || startup.description}</p>

      <div className="text-sm text-gray-500 mb-4">
        {startup.metrics && (
          <div className="flex items-center mb-1">
            <TrendingUp className="h-4 w-4 mr-2" />
            {startup.metrics}
          </div>
        )}
        <div className="flex items-center mb-1">
          <Users className="h-4 w-4 mr-2" />
          {getTeamMembers()}
        </div>
        <div className="flex items-center">
          <Building className="h-4 w-4 mr-2" />
          Founded {startup.founded}
        </div>
      </div>

      {startup.lookingForFunding && (
        <div className="mb-4">
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Seeking funding
          </span>
        </div>
      )}

      <button
        onClick={onClick}
        className="w-full btn-secondary flex items-center justify-center"
      >
        View Details
        <ArrowRight className="h-4 w-4 ml-2" />
      </button>
    </div>
  );
}

function StartupDetail({ startup, onBack, isFavorited, onToggleFavorite }: {
  startup: StartupData;
  onBack: () => void;
  isFavorited: boolean;
  onToggleFavorite: () => void;
}) {
  const stageColors: Record<string, string> = {
    idea: 'badge-stage-idea',
    mvp: 'badge-stage-mvp',
    scaling: 'badge-stage-scaling'
  };

  const getStageClass = (stage: string) => {
    const normalizedStage = stage.toLowerCase();
    return stageColors[normalizedStage] || 'badge-stage-idea';
  };

  const getTeamMembers = () => {
    return startup.team || startup.founders || [];
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <button onClick={onBack} className="mb-6 text-orange-600 hover:text-orange-700 flex items-center">
          <ArrowRight className="h-4 w-4 mr-2 rotate-180" />
          Back to Directory
        </button>

        <div className="bg-white rounded-lg shadow-sm p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-4 mb-4">
              <h1 className="text-3xl font-bold text-gray-900">{startup.name}</h1>
              <span className={getStageClass(startup.stage)}>{startup.stage}</span>
              <button
                onClick={onToggleFavorite}
                className={`p-2 rounded-full transition-colors ${
                  isFavorited 
                    ? 'text-red-500 hover:text-red-600' 
                    : 'text-gray-400 hover:text-red-500'
                }`}
              >
                <Heart className={`h-6 w-6 ${isFavorited ? 'fill-current' : ''}`} />
              </button>
            </div>
            <p className="text-xl text-gray-600 mb-4">{startup.oneLiner || startup.tagline}</p>
            <div className="flex justify-center gap-4 text-sm text-gray-500">
              <span>{startup.sector || startup.industry}</span>
              <span>•</span>
              <span>Founded {startup.founded}</span>
              {startup.metrics && (
                <>
                  <span>•</span>
                  <span>{startup.metrics}</span>
                </>
              )}
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Problem & Solution */}
            <div>
              {startup.problem && (
                <>
                  <h3 className="text-lg font-semibold mb-4">The Problem</h3>
                  <p className="text-gray-600 mb-6">{startup.problem}</p>
                </>
              )}
              
              {startup.solution && (
                <>
                  <h3 className="text-lg font-semibold mb-4">Our Solution</h3>
                  <p className="text-gray-600">{startup.solution}</p>
                </>
              )}

              {!startup.problem && !startup.solution && startup.description && (
                <>
                  <h3 className="text-lg font-semibold mb-4">About</h3>
                  <p className="text-gray-600">{startup.description}</p>
                </>
              )}
            </div>

            {/* Team & Traction */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Team</h3>
              <div className="mb-6">
                {getTeamMembers().length > 0 ? (
                  getTeamMembers().map((member, index) => (
                    <div key={index} className="flex items-center mb-2">
                      <div className="w-8 h-8 bg-gray-200 rounded-full mr-3"></div>
                      <span className="text-gray-700">{member}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500">Team information not available</p>
                )}
              </div>

              {startup.lookingForFunding && (
                <div className="mb-6">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                    Looking for funding
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Traction Timeline */}
          {startup.traction && startup.traction.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-4">Traction Timeline</h3>
              <div className="space-y-3">
                {startup.traction.map((item, index) => (
                  <div key={index} className="flex items-center">
                    <div className="w-2 h-2 bg-orange-500 rounded-full mr-4"></div>
                    <span className="text-sm text-gray-500 w-24">
                      {new Date(item.date).toLocaleDateString()}
                    </span>
                    <span className="text-gray-700">{item.metric}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contact */}
          <div className="mt-8 pt-6 border-t border-gray-200 text-center">
            <p className="text-gray-600 mb-4">Interested in learning more?</p>
            <a 
              href={`mailto:${startup.contact || `contact@${startup.name.toLowerCase().replace(/\s+/g, '')}.com`}`}
              className="btn-primary inline-flex items-center"
            >
              Contact Team
              <ArrowRight className="h-4 w-4 ml-2" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}