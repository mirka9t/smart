import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { loadPrograms } from '../utils/dataLoader';
import { useModal } from '../components/modals/ModalSystem';
import { 
  notifications, 
  programNotifications, 
  generalNotifications, 
  showSuccess 
} from '../utils/notifications';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';
import { useAuth } from '../contexts/AuthContext';
import { 
  Calendar, 
  MapPin, 
  Users, 
  DollarSign, 
  Clock, 
  Search, 
  Filter, 
  Bookmark, 
  BookmarkCheck, 
  ExternalLink, 
  Building,
  GraduationCap,
  TrendingUp,
  Award,
  Share2,
  Heart,
  Info
} from 'lucide-react';

interface Program {
  id: string;
  name: string;
  type: string;
  duration: string;
  cohortSize: number;
  equity: string;
  funding: string;
  description: string;
  curriculum: string[];
  benefits: string[];
  requirements: string[];
  applicationDeadline: string;
  startDate: string;
  location: string;
  isAcceptingApplications: boolean;
}

export function Programs() {
  const [programs, setPrograms] = useState<Program[]>([]);
  const [filteredPrograms, setFilteredPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [bookmarkedPrograms, setBookmarkedPrograms] = useState<Set<string>>(new Set());
  const [likedPrograms, setLikedPrograms] = useState<Set<string>>(new Set());
  
  const { openModal } = useModal();
  const { user } = useAuth();

  useEffect(() => {
    async function fetchPrograms() {
      try {
        const data = await loadPrograms();
        setPrograms(data);
        setFilteredPrograms(data);
        
        // Load saved preferences
        const savedBookmarks = localStorage.getItem('smart-bookmarked-programs');
        const savedLikes = localStorage.getItem('smart-liked-programs');
        
        if (savedBookmarks) {
          setBookmarkedPrograms(new Set(JSON.parse(savedBookmarks)));
        }
        if (savedLikes) {
          setLikedPrograms(new Set(JSON.parse(savedLikes)));
        }
      } catch (error) {
        console.error('Error loading programs:', error);
        generalNotifications.error('load programs');
      } finally {
        setLoading(false);
      }
    }
    
    fetchPrograms();
  }, []);

  // Filter programs
  useEffect(() => {
    let filtered = programs;

    if (searchTerm) {
      filtered = filtered.filter(program =>
        program.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        program.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        program.type.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedType) {
      filtered = filtered.filter(program => program.type === selectedType);
    }

    if (selectedLocation) {
      filtered = filtered.filter(program =>
        program.location.toLowerCase().includes(selectedLocation.toLowerCase())
      );
    }

    setFilteredPrograms(filtered);
  }, [programs, searchTerm, selectedType, selectedLocation]);

  const programTypes = Array.from(new Set(programs.map(p => p.type)));
  const locations = Array.from(new Set(programs.map(p => p.location)));

  const handleApplyToProgram = (program: Program) => {
    if (!program.isAcceptingApplications) {
      notifications.warning('Applications Closed', 'This program is not currently accepting applications.');
      return;
    }

    openModal({
      type: 'apply-program',
      title: 'Apply to Program',
      data: { programName: program.name, programId: program.id },
      onConfirm: async (formData) => {
        // Simulate application process
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Track application submission
        if (user) {
          await telegramBot.trackApplication(
            formatUserForTelegram(user), 
            program.name, 
            program.type
          );
        }
        
        programNotifications.applied(program.name);
        console.log('Program application:', { program: program.id, ...formData });
      }
    });
  };

  const handleLearnMore = (program: Program) => {
    openModal({
      type: 'program-details',
      title: program.name,
      data: { program },
      onConfirm: () => {
        // Modal will close automatically
      }
    });
  };

  const handleShareProgram = (program: Program) => {
    const shareData = {
      title: program.name,
      text: program.description,
      url: `${window.location.origin}/programs#${program.id}`,
    };

    openModal({
      type: 'share-content',
      title: 'Share Program',
      data: { 
        contentType: 'Program',
        title: program.name,
        url: shareData.url 
      },
      onConfirm: async () => {
        try {
          if (navigator.share && navigator.canShare(shareData)) {
            await navigator.share(shareData);
            showSuccess('Shared successfully!');
          } else {
            await navigator.clipboard.writeText(shareData.url);
            showSuccess('Link copied!', 'Program link has been copied to clipboard.');
          }
        } catch (error) {
          notifications.error('Sharing failed', 'Please try copying the link manually.');
        }
      }
    });
  };

  const toggleBookmark = async (programId: string) => {
    const program = programs.find(p => p.id === programId);
    const newBookmarks = new Set(bookmarkedPrograms);
    
    const action = newBookmarks.has(programId) ? 'removed' : 'added';
    
    if (newBookmarks.has(programId)) {
      newBookmarks.delete(programId);
      showSuccess('Bookmark Removed', 'Program removed from your bookmarks.');
    } else {
      newBookmarks.add(programId);
      programNotifications.bookmarked(program?.name || 'Program');
    }
    
    // Track favorite action
    if (user && program) {
      await telegramBot.trackFavorite(
        formatUserForTelegram(user),
        'Program',
        program.name,
        action
      );
    }
    
    setBookmarkedPrograms(newBookmarks);
    localStorage.setItem('smart-bookmarked-programs', JSON.stringify(Array.from(newBookmarks)));
  };

  const toggleLike = (programId: string) => {
    const newLikes = new Set(likedPrograms);
    if (newLikes.has(programId)) {
      newLikes.delete(programId);
    } else {
      newLikes.add(programId);
      showSuccess('Thanks for the feedback!', 'Your interest has been noted.');
    }
    
    setLikedPrograms(newLikes);
    localStorage.setItem('smart-liked-programs', JSON.stringify(Array.from(newLikes)));
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedType('');
    setSelectedLocation('');
    showSuccess('Filters Cleared', 'All filters have been reset.');
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'accelerator': return TrendingUp;
      case 'bootcamp': return GraduationCap;
      case 'fellowship': return Award;
      case 'incubator': return Building;
      default: return Building;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'accelerator': return 'bg-blue-100 text-blue-700';
      case 'bootcamp': return 'bg-green-100 text-green-700';
      case 'fellowship': return 'bg-purple-100 text-purple-700';
      case 'incubator': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const isDeadlineApproaching = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    const daysUntilDeadline = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
    return daysUntilDeadline <= 14 && daysUntilDeadline > 0;
  };

  const formatDeadline = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    const daysUntilDeadline = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
    
    if (daysUntilDeadline < 0) {
      return 'Deadline passed';
    } else if (daysUntilDeadline === 0) {
      return 'Due today';
    } else if (daysUntilDeadline === 1) {
      return 'Due tomorrow';
    } else if (daysUntilDeadline <= 7) {
      return `Due in ${daysUntilDeadline} days`;
    } else {
      return deadlineDate.toLocaleDateString();
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading programs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1>Accelerator Programs</h1>
        <p className="text-lg mb-6">
          Join world-class programs designed specifically for student entrepreneurs. Get funding, mentorship, and the network you need to scale your startup.
        </p>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search programs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <select
            className="px-3 py-2 border border-border rounded-md bg-background"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <option value="">All Types</option>
            {programTypes.map(type => (
              <option key={type} value={type}>
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </option>
            ))}
          </select>

          <select
            className="px-3 py-2 border border-border rounded-md bg-background"
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
          >
            <option value="">All Locations</option>
            {locations.map(location => (
              <option key={location} value={location}>{location}</option>
            ))}
          </select>

          <Button variant="outline" className="flex items-center gap-2" onClick={clearAllFilters}>
            <Filter className="w-4 h-4" />
            Clear Filters
          </Button>
        </div>

        {/* Results Summary */}
        <p className="text-muted-foreground">
          Showing {filteredPrograms.length} of {programs.length} programs
        </p>
      </div>

      {/* Programs Grid */}
      <div className="smart-grid">
        {filteredPrograms.map((program) => {
          const IconComponent = getTypeIcon(program.type);
          const isUrgent = isDeadlineApproaching(program.applicationDeadline);
          
          return (
            <Card key={program.id} className={`smart-card ${isUrgent ? 'ring-2 ring-yellow-400' : ''}`}>
              {isUrgent && (
                <div className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium mb-4 inline-block">
                  🔥 Deadline Approaching
                </div>
              )}
              
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3 flex-1">
                  <div className={`w-12 h-12 rounded-lg ${getTypeColor(program.type)} flex items-center justify-center`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-semibold truncate">{program.name}</h3>
                    <p className="text-sm text-muted-foreground capitalize">{program.type}</p>
                  </div>
                </div>
                
                <div className="flex gap-1 ml-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => toggleBookmark(program.id)}
                  >
                    {bookmarkedPrograms.has(program.id) ? (
                      <BookmarkCheck className="w-4 h-4 text-primary" />
                    ) : (
                      <Bookmark className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => toggleLike(program.id)}
                  >
                    <Heart className={`w-4 h-4 ${likedPrograms.has(program.id) ? 'fill-red-500 text-red-500' : ''}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-1 h-8 w-8"
                    onClick={() => handleShareProgram(program)}
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                {program.description}
              </p>

              {/* Key Details */}
              <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span>{program.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span>{program.cohortSize} cohort</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">{program.funding}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-muted-foreground" />
                  <span>{program.equity} equity</span>
                </div>
              </div>

              {/* Location and Deadline */}
              <div className="space-y-2 mb-4 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>{program.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className={`w-4 h-4 ${isUrgent ? 'text-yellow-600' : 'text-muted-foreground'}`} />
                  <span className={isUrgent ? 'text-yellow-700 font-medium' : ''}>
                    {formatDeadline(program.applicationDeadline)}
                  </span>
                </div>
              </div>

              {/* Benefits Preview */}
              <div className="mb-4">
                <p className="text-sm font-medium mb-2">Key Benefits:</p>
                <div className="flex flex-wrap gap-2">
                  {program.benefits.slice(0, 3).map((benefit, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {benefit}
                    </Badge>
                  ))}
                  {program.benefits.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{program.benefits.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>

              {/* Application Status */}
              <div className="mb-4">
                <Badge 
                  className={`${
                    program.isAcceptingApplications 
                      ? 'bg-green-100 text-green-700' 
                      : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {program.isAcceptingApplications ? 'Applications Open' : 'Applications Closed'}
                </Badge>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button 
                  className={`flex-1 ${program.isAcceptingApplications ? 'btn-primary' : ''}`}
                  variant={program.isAcceptingApplications ? "default" : "outline"}
                  onClick={() => handleApplyToProgram(program)}
                  disabled={!program.isAcceptingApplications}
                >
                  {program.isAcceptingApplications ? 'Apply Now' : 'Applications Closed'}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleLearnMore(program)}
                >
                  <Info className="w-4 h-4 mr-1" />
                  Details
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open(`${window.location.origin}/programs#${program.id}`, '_blank')}
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredPrograms.length === 0 && (
        <div className="text-center py-12">
          <Building className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No programs found</h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your search criteria or clearing filters.
          </p>
          <Button 
            variant="outline"
            onClick={clearAllFilters}
          >
            Clear All Filters
          </Button>
        </div>
      )}

      {/* Call to Action */}
      <div className="mt-12 smart-card bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <div className="text-center">
          <h3 className="mb-2">Can't find the right program?</h3>
          <p className="text-muted-foreground mb-4">
            Get personalized program recommendations based on your startup stage and goals.
          </p>
          <Button 
            className="btn-primary"
            onClick={() => generalNotifications.comingSoon('Program recommendation engine')}
          >
            Get Program Recommendations
          </Button>
        </div>
      </div>
    </div>
  );
}