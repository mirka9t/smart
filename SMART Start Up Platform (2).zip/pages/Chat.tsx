import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Textarea } from '../components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Checkbox } from '../components/ui/checkbox';
import { useAuth } from '../contexts/AuthContext';
import { chatManager, type ChatMessage, type ChatUser, type ChatRoom } from '../utils/chatUtils';
import { notificationSystem } from '../utils/notificationSystem';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';
import { notifications } from '../utils/notifications';
import { Loading, InlineLoading } from '../components/ui/Loading';
import {
  Send,
  Search,
  Users,
  MessageCircle,
  Phone,
  Video,
  MoreHorizontal,
  Paperclip,
  Image,
  Smile,
  CheckCircle2,
  Circle,
  Clock,
  Star,
  Pin,
  Archive,
  AlertCircle,
  Settings,
  UserPlus,
  Hash,
  Lock,
  Globe,
  Eye,
  EyeOff,
  Volume2,
  VolumeX,
  Bell,
  BellOff,
  Filter,
  SortAsc,
  RefreshCw,
  Download,
  Upload,
  Edit3,
  Trash2,
  Reply,
  Forward,
  Copy,
  Flag,
  Zap,
  Heart,
  ThumbsUp,
  Laugh,
  Angry,
  Frown,
  Plus,
  Mic,
  MicOff,
  Play,
  Pause,
  X,
  Crown,
  Shield,
  Building2,
  Lightbulb,
  Target,
  TrendingUp
} from 'lucide-react';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface EmojiReaction {
  emoji: string;
  label: string;
  icon: any;
}

const reactions: EmojiReaction[] = [
  { emoji: '❤️', label: 'Love', icon: Heart },
  { emoji: '👍', label: 'Like', icon: ThumbsUp },
  { emoji: '😂', label: 'Laugh', icon: Laugh },
  { emoji: '😢', label: 'Sad', icon: Frown },
  { emoji: '😠', label: 'Angry', icon: Angry },
  { emoji: '⚡', label: 'Wow', icon: Zap }
];

const roomTypes = [
  { value: 'startup', label: 'Startup Team', icon: Building2, description: 'Private space for your startup team' },
  { value: 'project', label: 'Project Room', icon: Lightbulb, description: 'Collaborate on specific projects' },
  { value: 'study', label: 'Study Group', icon: Target, description: 'Learning and knowledge sharing' },
  { value: 'networking', label: 'Networking', icon: TrendingUp, description: 'Connect with other entrepreneurs' },
  { value: 'public', label: 'Public Discussion', icon: Globe, description: 'Open community discussions' }
];

export function Chat() {
  const { user, allUsers, trackAction } = useAuth();
  const [activeTab, setActiveTab] = useState('direct');
  const [selectedUser, setSelectedUser] = useState<ChatUser | null>(null);
  const [selectedRoom, setSelectedRoom] = useState<ChatRoom | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchResults, setGlobalSearchResults] = useState<ChatUser[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [chatUsers, setChatUsers] = useState<ChatUser[]>([]);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);
  const [replyToMessage, setReplyToMessage] = useState<ChatMessage | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'starred'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'name' | 'online'>('recent');
  const [isRecording, setIsRecording] = useState(false);
  
  // Room creation states
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [newRoomType, setNewRoomType] = useState('startup');
  const [newRoomDescription, setNewRoomDescription] = useState('');
  const [newRoomParticipants, setNewRoomParticipants] = useState<string[]>([]);
  const [roomIsPublic, setRoomIsPublic] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();
  const messageInputRef = useRef<HTMLTextAreaElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Load data on mount
  useEffect(() => {
    loadChatData();
    setupRealtimeUpdates();

    // Track page view
    if (user) {
      trackAction('page_view', { page: 'Team Chat', path: '/chat' });
    }

    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, [user]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load conversation when user/room is selected
  useEffect(() => {
    if (selectedUser) {
      loadConversation(selectedUser.id);
      setActiveTab('direct');
    } else if (selectedRoom) {
      loadRoomConversation(selectedRoom.id);
      setActiveTab('rooms');
    }
  }, [selectedUser, selectedRoom]);

  // Global user search
  useEffect(() => {
    if (globalSearchQuery.trim()) {
      const filtered = allUsers.filter(u => 
        u.id !== user?.id && (
          u.name.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
          u.email.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
          u.university?.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
          u.skills?.some(skill => skill.toLowerCase().includes(globalSearchQuery.toLowerCase()))
        )
      );
      setGlobalSearchResults(filtered);
    } else {
      setGlobalSearchResults([]);
    }
  }, [globalSearchQuery, allUsers, user]);

  const loadChatData = async () => {
    try {
      setLoading(true);
      const users = chatManager.getChatUsers();
      const rooms = chatManager.getUserRooms(user?.id || '');
      
      setChatUsers(users);
      setChatRooms(rooms);

      // If no conversation selected, try to load from URL params
      const urlParams = new URLSearchParams(window.location.search);
      const userId = urlParams.get('user');
      const roomId = urlParams.get('room');

      if (userId) {
        const targetUser = users.find(u => u.id === userId);
        if (targetUser) {
          setSelectedUser(targetUser);
        }
      } else if (roomId) {
        const targetRoom = rooms.find(r => r.id === roomId);
        if (targetRoom) {
          setSelectedRoom(targetRoom);
        }
      }
    } catch (error) {
      console.error('Error loading chat data:', error);
      notifications.error('Error', 'Failed to load chat data');
    } finally {
      setLoading(false);
    }
  };

  const loadConversation = async (otherUserId: string) => {
    try {
      const conversationMessages = chatManager.getConversationMessages(user?.id || '', otherUserId);
      setMessages(conversationMessages);
      
      // Mark messages as read
      chatManager.markMessagesAsRead(user?.id || '', otherUserId);
      
      // Update URL
      window.history.replaceState({}, '', `/chat?user=${otherUserId}`);
    } catch (error) {
      console.error('Error loading conversation:', error);
      notifications.error('Error', 'Failed to load conversation');
    }
  };

  const loadRoomConversation = async (roomId: string) => {
    try {
      const roomMessages = chatManager.getConversationMessages('', undefined, roomId);
      setMessages(roomMessages);
      
      // Mark room messages as read
      chatManager.markMessagesAsRead(user?.id || '', undefined, roomId);
      
      // Update URL
      window.history.replaceState({}, '', `/chat?room=${roomId}`);
    } catch (error) {
      console.error('Error loading room conversation:', error);
      notifications.error('Error', 'Failed to load room conversation');
    }
  };

  const setupRealtimeUpdates = () => {
    // Subscribe to new messages
    const unsubscribeMessages = chatManager.onNewMessage((message) => {
      // Update messages if it's for current conversation
      if (selectedUser && (message.fromUserId === selectedUser.id || message.toUserId === selectedUser.id)) {
        setMessages(prev => [...prev, message]);
        chatManager.markMessagesAsRead(user?.id || '', selectedUser.id);
      } else if (selectedRoom && message.roomId === selectedRoom.id) {
        setMessages(prev => [...prev, message]);
        chatManager.markMessagesAsRead(user?.id || '', undefined, selectedRoom.id);
      }

      // Play notification sound
      if (soundEnabled && message.fromUserId !== user?.id) {
        playNotificationSound();
      }

      // Show notification if not in current conversation
      if (notificationsEnabled && message.fromUserId !== user?.id) {
        const isCurrentConversation = 
          (selectedUser && message.fromUserId === selectedUser.id) ||
          (selectedRoom && message.roomId === selectedRoom.id);
        
        if (!isCurrentConversation) {
          notificationSystem.show({
            type: 'message',
            title: `New message from ${message.fromUserName}`,
            message: message.message.substring(0, 100),
            priority: 'medium',
            actionUrl: message.roomId ? `/chat?room=${message.roomId}` : `/chat?user=${message.fromUserId}`
          });
        }
      }

      // Refresh chat users list
      setChatUsers(chatManager.getChatUsers());
    });

    return unsubscribeMessages;
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user) return;

    try {
      setLoading(true);
      
      let message: ChatMessage;
      
      if (selectedUser) {
        // Send direct message
        message = await chatManager.sendMessage(
          user.id,
          user.name,
          user.email,
          user.role,
          newMessage.trim(),
          selectedUser.id,
          undefined,
          'text',
          undefined,
          replyToMessage?.id
        );
      } else if (selectedRoom) {
        // Send room message
        message = await chatManager.sendMessage(
          user.id,
          user.name,
          user.email,
          user.role,
          newMessage.trim(),
          undefined,
          selectedRoom.id,
          'text',
          undefined,
          replyToMessage?.id
        );
      } else {
        return;
      }

      setMessages(prev => [...prev, message]);
      setNewMessage('');
      setReplyToMessage(null);
      
      // Clear typing indicator
      setIsTyping(false);
      if (selectedUser) {
        chatManager.setTyping(user.id, false, selectedUser.id);
      } else if (selectedRoom) {
        chatManager.setTyping(user.id, false, undefined, selectedRoom.id);
      }

      // Track action
      await trackAction('team_chat_message_sent', {
        recipientType: selectedUser ? 'user' : 'room',
        recipientId: selectedUser?.id || selectedRoom?.id,
        roomType: selectedRoom?.type,
        messageLength: newMessage.length,
        hasReply: !!replyToMessage
      });

      // Update stats
      if (user.stats) {
        user.stats.chatMessages++;
      }

      notifications.success('Message sent', 'Your message has been delivered');
    } catch (error) {
      console.error('Error sending message:', error);
      notifications.error('Error', 'Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRoom = async () => {
    if (!newRoomName.trim() || !user) return;

    try {
      setLoading(true);

      const roomSettings = {
        public: roomIsPublic,
        allowFiles: true,
        allowImages: true,
        maxParticipants: roomIsPublic ? 1000 : 50
      };

      const room = await chatManager.createRoom(
        newRoomName.trim(),
        roomIsPublic ? 'public' : 'group',
        user.id,
        newRoomParticipants,
        roomSettings
      );

      setChatRooms(prev => [room, ...prev]);
      setSelectedRoom(room);
      
      // Clear form
      setNewRoomName('');
      setNewRoomDescription('');
      setNewRoomParticipants([]);
      setRoomIsPublic(false);
      setShowCreateRoom(false);

      // Track room creation
      await trackAction('startup_room_created', {
        roomType: newRoomType,
        roomName: newRoomName,
        participantCount: newRoomParticipants.length,
        isPublic: roomIsPublic
      });

      notifications.success('Room created!', `"${newRoomName}" has been created successfully`);
    } catch (error) {
      console.error('Error creating room:', error);
      notifications.error('Error', 'Failed to create room');
    } finally {
      setLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        await sendVoiceMessage(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      notifications.info('Recording', 'Voice message recording started');
    } catch (error) {
      console.error('Error starting recording:', error);
      notifications.error('Error', 'Failed to start voice recording');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const sendVoiceMessage = async (audioBlob: Blob) => {
    if (!user) return;

    try {
      // Convert blob to base64 for storage
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Audio = reader.result as string;
        
        if (selectedUser) {
          const voiceMessage = await chatManager.sendMessage(
            user.id,
            user.name,
            user.email,
            user.role,
            '🎤 Voice message',
            selectedUser.id,
            undefined,
            'audio',
            [{
              type: 'audio',
              url: base64Audio,
              name: `voice-${Date.now()}.wav`,
              size: audioBlob.size
            }]
          );
          setMessages(prev => [...prev, voiceMessage]);
        } else if (selectedRoom) {
          const voiceMessage = await chatManager.sendMessage(
            user.id,
            user.name,
            user.email,
            user.role,
            '🎤 Voice message',
            undefined,
            selectedRoom.id,
            'audio',
            [{
              type: 'audio',
              url: base64Audio,
              name: `voice-${Date.now()}.wav`,
              size: audioBlob.size
            }]
          );
          setMessages(prev => [...prev, voiceMessage]);
        }
        
        await trackAction('voice_message_sent', {
          duration: Math.round(audioBlob.size / 1000), // approximate duration
          recipient: selectedUser ? 'user' : 'room'
        });

        notifications.success('Voice message sent', 'Your voice message has been sent');
      };
      
      reader.readAsDataURL(audioBlob);
    } catch (error) {
      console.error('Error sending voice message:', error);
      notifications.error('Error', 'Failed to send voice message');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    // Check file size (25MB limit for team chat)
    if (file.size > 25 * 1024 * 1024) {
      notifications.error('File too large', 'Please select a file smaller than 25MB');
      return;
    }

    try {
      setLoading(true);
      
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64File = reader.result as string;
        const fileType = file.type.startsWith('image/') ? 'image' : 'file';
        
        if (selectedUser) {
          const fileMessage = await chatManager.sendMessage(
            user.id,
            user.name,
            user.email,
            user.role,
            fileType === 'image' ? '📷 Image shared' : `📎 ${file.name}`,
            selectedUser.id,
            undefined,
            fileType,
            [{
              type: fileType,
              url: base64File,
              name: file.name,
              size: file.size
            }]
          );
          setMessages(prev => [...prev, fileMessage]);
        } else if (selectedRoom) {
          const fileMessage = await chatManager.sendMessage(
            user.id,
            user.name,
            user.email,
            user.role,
            fileType === 'image' ? '📷 Image shared' : `📎 ${file.name}`,
            undefined,
            selectedRoom.id,
            fileType,
            [{
              type: fileType,
              url: base64File,
              name: file.name,
              size: file.size
            }]
          );
          setMessages(prev => [...prev, fileMessage]);
        }
        
        await trackAction('file_shared_team_chat', {
          fileType,
          fileName: file.name,
          fileSize: file.size,
          recipient: selectedUser ? 'user' : 'room'
        });

        notifications.success('File shared', 'Your file has been shared successfully');
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading file:', error);
      notifications.error('Error', 'Failed to upload file');
    } finally {
      setLoading(false);
    }
  };

  const handleUserSelect = (chatUser: ChatUser) => {
    setSelectedUser(chatUser);
    setSelectedRoom(null);
    setMessages([]);
  };

  const handleRoomSelect = (room: ChatRoom) => {
    setSelectedRoom(room);
    setSelectedUser(null);
    setMessages([]);
  };

  const handleGlobalUserSelect = (selectedGlobalUser: any) => {
    // Convert global user to chat user and start conversation
    const chatUser: ChatUser = {
      id: selectedGlobalUser.id,
      name: selectedGlobalUser.name,
      email: selectedGlobalUser.email,
      role: selectedGlobalUser.role,
      isOnline: false,
      lastSeen: new Date().toISOString(),
      profileCompleteness: selectedGlobalUser.profileCompleteness || 0,
      status: 'available',
      unreadCount: 0,
      blockedUsers: [],
      preferences: {
        notifications: true,
        sounds: true,
        emailAlerts: true,
        showTyping: true
      }
    };

    handleUserSelect(chatUser);
    setGlobalSearchQuery('');
    setActiveTab('direct');
  };

  const handleReaction = async (messageId: string, emoji: string) => {
    try {
      // Add reaction to message (simplified implementation)
      const updatedMessages = messages.map(msg => {
        if (msg.id === messageId) {
          const existingReactions = msg.reactions || [];
          const userReaction = existingReactions.find(r => r.userId === user?.id);
          
          if (userReaction) {
            // Update existing reaction
            userReaction.emoji = emoji;
          } else {
            // Add new reaction
            existingReactions.push({
              emoji,
              userId: user?.id || '',
              timestamp: new Date().toISOString()
            });
          }
          
          return { ...msg, reactions: existingReactions };
        }
        return msg;
      });
      
      setMessages(updatedMessages);
      notifications.success('Reaction added', 'Your reaction has been recorded');
    } catch (error) {
      console.error('Error adding reaction:', error);
      notifications.error('Error', 'Failed to add reaction');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const playNotificationSound = () => {
    try {
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+LyvmwhBSyBzvLYiTcIGWi77eefTQwMUKfj8LZjHAY4kdfyy3YJGWi77eefTQwMUKfj8LZjHAY4kdfyy3ksBSR3x/DdkEAKFF606+uoVRQKRp/i8r5sIQU=');
      audio.volume = 0.3;
      audio.play().catch(() => {
        // Ignore audio play errors
      });
    } catch (error) {
      // Ignore audio errors
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const filteredUsers = chatUsers.filter(u => {
    if (filter === 'unread' && u.unreadCount === 0) return false;
    if (filter === 'starred') return false; // TODO: Implement starred conversations
    
    return u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
           u.email.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'online':
        if (a.isOnline && !b.isOnline) return -1;
        if (!a.isOnline && b.isOnline) return 1;
        return 0;
      case 'recent':
      default:
        return new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime();
    }
  });

  if (loading && !user) {
    return <Loading message="Loading team chat..." type="loading" fullScreen />;
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-80 border-r border-border flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Building2 className="w-6 h-6 text-primary" />
              <h1 className="text-lg font-semibold">Team Chat</h1>
            </div>
            <div className="flex items-center space-x-2">
              <Dialog open={showCreateRoom} onOpenChange={setShowCreateRoom}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Create New Room</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Room Name</Label>
                      <Input
                        value={newRoomName}
                        onChange={(e) => setNewRoomName(e.target.value)}
                        placeholder="Enter room name..."
                      />
                    </div>

                    <div>
                      <Label>Room Type</Label>
                      <Select value={newRoomType} onValueChange={setNewRoomType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {roomTypes.map((type) => {
                            const IconComponent = type.icon;
                            return (
                              <SelectItem key={type.value} value={type.value}>
                                <div className="flex items-center space-x-2">
                                  <IconComponent className="w-4 h-4" />
                                  <div>
                                    <div className="font-medium">{type.label}</div>
                                    <div className="text-xs text-muted-foreground">{type.description}</div>
                                  </div>
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Description (Optional)</Label>
                      <Textarea
                        value={newRoomDescription}
                        onChange={(e) => setNewRoomDescription(e.target.value)}
                        placeholder="Describe the purpose of this room..."
                        rows={3}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="public-room"
                        checked={roomIsPublic}
                        onCheckedChange={(checked) => setRoomIsPublic(checked as boolean)}
                      />
                      <Label htmlFor="public-room" className="text-sm">
                        Make this room public (anyone can join)
                      </Label>
                    </div>

                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        onClick={() => setShowCreateRoom(false)}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleCreateRoom}
                        disabled={!newRoomName.trim() || loading}
                        className="flex-1 btn-primary"
                      >
                        {loading ? <InlineLoading /> : 'Create Room'}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Global User Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search all users globally..."
                value={globalSearchQuery}
                onChange={(e) => setGlobalSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {/* Global Search Results */}
            {globalSearchResults.length > 0 && (
              <div className="mt-2 bg-popover border border-border rounded-lg shadow-lg max-h-64 overflow-y-auto">
                <div className="p-2 border-b border-border">
                  <p className="text-xs font-medium text-muted-foreground">
                    Found {globalSearchResults.length} users
                  </p>
                </div>
                {globalSearchResults.map((globalUser) => (
                  <div
                    key={globalUser.id}
                    className="p-3 hover:bg-muted/50 cursor-pointer border-b border-border last:border-0"
                    onClick={() => handleGlobalUserSelect(globalUser)}
                  >
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>{getInitials(globalUser.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{globalUser.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{globalUser.email}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {globalUser.role}
                          </Badge>
                          {globalUser.university && (
                            <Badge variant="secondary" className="text-xs">
                              {globalUser.university}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Local Search */}
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-2 mt-3">
            <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
              <SelectTrigger className="w-24">
                <Filter className="w-4 h-4 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="unread">Unread</SelectItem>
                <SelectItem value="starred">Starred</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
              <SelectTrigger className="w-24">
                <SortAsc className="w-4 h-4 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Recent</SelectItem>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="online">Online</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="ghost"
              size="sm"
              onClick={loadChatData}
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="mx-4 mt-2">
            <TabsTrigger value="direct" className="flex-1">
              <MessageCircle className="w-4 h-4 mr-2" />
              Direct
            </TabsTrigger>
            <TabsTrigger value="rooms" className="flex-1">
              <Hash className="w-4 h-4 mr-2" />
              Rooms
            </TabsTrigger>
          </TabsList>

          {/* Direct Messages */}
          <TabsContent value="direct" className="flex-1 overflow-hidden">
            <div className="overflow-y-auto h-full px-2">
              {sortedUsers.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {searchQuery ? 'No users found' : 'No conversations yet'}
                  <p className="text-xs mt-2">Use global search above to find any user</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {sortedUsers.map((chatUser) => (
                    <motion.div
                      key={chatUser.id}
                      whileHover={{ x: 4 }}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedUser?.id === chatUser.id 
                          ? 'bg-primary/10 border border-primary' 
                          : 'hover:bg-muted/50'
                      }`}
                      onClick={() => handleUserSelect(chatUser)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>
                              {getInitials(chatUser.name)}
                            </AvatarFallback>
                          </Avatar>
                          {chatUser.isOnline && (
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="font-medium truncate">{chatUser.name}</p>
                            <div className="flex items-center space-x-1">
                              {chatUser.unreadCount > 0 && (
                                <Badge className="bg-destructive text-destructive-foreground text-xs px-1 py-0">
                                  {chatUser.unreadCount}
                                </Badge>
                              )}
                              <span className="text-xs text-muted-foreground">
                                {formatTime(chatUser.lastSeen)}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-xs">
                              {chatUser.role}
                            </Badge>
                            <p className="text-sm text-muted-foreground truncate">
                              {chatUser.customStatus || 'Available'}
                            </p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Room Messages */}
          <TabsContent value="rooms" className="flex-1 overflow-hidden">
            <div className="overflow-y-auto h-full px-2">
              {chatRooms.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Building2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No startup rooms yet</p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => setShowCreateRoom(true)}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Room
                  </Button>
                </div>
              ) : (
                <div className="space-y-1">
                  {chatRooms.map((room) => {
                    const roomTypeInfo = roomTypes.find(t => t.value === room.type) || roomTypes[0];
                    const RoomIcon = roomTypeInfo.icon;
                    
                    return (
                      <motion.div
                        key={room.id}
                        whileHover={{ x: 4 }}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedRoom?.id === room.id 
                            ? 'bg-primary/10 border border-primary' 
                            : 'hover:bg-muted/50'
                        }`}
                        onClick={() => handleRoomSelect(room)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                            <RoomIcon className="w-5 h-5 text-primary" />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-medium truncate">{room.name}</p>
                              <div className="flex items-center space-x-1">
                                {room.type === 'public' && <Globe className="w-3 h-3 text-green-500" />}
                                {room.type === 'group' && <Lock className="w-3 h-3 text-blue-500" />}
                                <span className="text-xs text-muted-foreground">
                                  {room.lastMessage ? formatTime(room.lastMessage.timestamp) : ''}
                                </span>
                              </div>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline" className="text-xs">
                                {room.participants.length} members
                              </Badge>
                              <Badge variant="secondary" className="text-xs">
                                {roomTypeInfo.label}
                              </Badge>
                              <p className="text-sm text-muted-foreground truncate">
                                {room.lastMessage?.message || 'No messages yet'}
                              </p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedUser || selectedRoom ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-border bg-muted/30">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>
                      {selectedUser ? getInitials(selectedUser.name) : 
                       selectedRoom ? roomTypes.find(t => t.value === selectedRoom.type)?.icon ? 
                       React.createElement(roomTypes.find(t => t.value === selectedRoom.type)!.icon, { className: "w-5 h-5" }) : '#' : '#'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="font-semibold">
                      {selectedUser ? selectedUser.name : selectedRoom?.name}
                    </h2>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      {selectedUser ? (
                        <>
                          <div className={`w-2 h-2 rounded-full ${selectedUser.isOnline ? 'bg-green-500' : 'bg-gray-400'}`} />
                          <span>{selectedUser.isOnline ? 'Online' : `Last seen ${formatTime(selectedUser.lastSeen)}`}</span>
                          <Badge variant="outline" className="text-xs">
                            {selectedUser.role}
                          </Badge>
                        </>
                      ) : (
                        <>
                          <Users className="w-4 h-4" />
                          <span>{selectedRoom?.participants.length} members</span>
                          <Badge variant="outline" className="text-xs">
                            {roomTypes.find(t => t.value === selectedRoom?.type)?.label}
                          </Badge>
                          {selectedRoom?.type === 'public' && (
                            <Badge variant="secondary" className="text-xs">
                              Public Room
                            </Badge>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Phone className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Video className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Search className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-semibold mb-2">
                      {selectedUser ? `Start collaborating with ${selectedUser.name}` : `Welcome to ${selectedRoom?.name}`}
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      {selectedUser 
                        ? "Connect, share ideas, and build something amazing together!"
                        : selectedRoom?.type === 'startup' 
                          ? "This is your startup team's private space. Share ideas, discuss strategy, and collaborate on your venture."
                          : "Collaborate with your team, share resources, and drive your project forward."
                      }
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span>Voice messages and file sharing</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span>Real-time collaboration tools</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        <span>Reactions and interactive features</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <AnimatePresence initial={false}>
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`flex ${message.fromUserId === user?.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-xs lg:max-w-md ${message.fromUserId === user?.id ? 'order-2' : 'order-1'}`}>
                        {/* Message bubble */}
                        <div
                          className={`relative rounded-2xl px-4 py-3 cursor-pointer group ${
                            message.fromUserId === user?.id 
                              ? 'bg-primary text-primary-foreground' 
                              : 'bg-muted text-foreground border border-border'
                          }`}
                          onClick={() => setSelectedMessage(
                            selectedMessage === message.id ? null : message.id
                          )}
                        >
                          {/* Reply indicator */}
                          {message.replyToId && (
                            <div className="text-xs opacity-70 mb-2 border-l-2 border-current pl-2">
                              Replying to message
                            </div>
                          )}

                          {/* Message content */}
                          {message.messageType === 'text' && (
                            <p className="text-sm break-words">{message.message}</p>
                          )}

                          {/* Voice message */}
                          {message.messageType === 'audio' && message.attachments?.[0] && (
                            <div className="flex items-center space-x-3">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-8 h-8 p-0 rounded-full"
                              >
                                <Play className="w-4 h-4" />
                              </Button>
                              <div className="flex-1">
                                <div className="w-32 h-1 bg-current opacity-30 rounded" />
                                <p className="text-xs opacity-70 mt-1">Voice message</p>
                              </div>
                            </div>
                          )}

                          {/* Image attachment */}
                          {message.messageType === 'image' && message.attachments?.[0] && (
                            <div className="space-y-2">
                              <img 
                                src={message.attachments[0].url} 
                                alt="Shared image"
                                className="max-w-full h-auto rounded-lg"
                              />
                              {message.message !== '📷 Image shared' && (
                                <p className="text-sm">{message.message}</p>
                              )}
                            </div>
                          )}

                          {/* File attachment */}
                          {message.messageType === 'file' && message.attachments?.[0] && (
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 rounded-lg bg-current/20 flex items-center justify-center">
                                <Paperclip className="w-5 h-5" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">
                                  {message.attachments[0].name}
                                </p>
                                <p className="text-xs opacity-70">
                                  {Math.round(message.attachments[0].size / 1024)} KB
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="w-8 h-8 p-0"
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                          
                          <div className="flex items-center justify-end mt-2 space-x-1">
                            <span className={`text-xs ${
                              message.fromUserId === user?.id 
                                ? 'text-primary-foreground/70' 
                                : 'text-muted-foreground'
                            }`}>
                              {formatTime(message.timestamp)}
                            </span>
                            {message.fromUserId === user?.id && (
                              <>
                                {message.isRead ? (
                                  <CheckCircle2 className="w-3 h-3" />
                                ) : (
                                  <Circle className="w-3 h-3" />
                                )}
                              </>
                            )}
                          </div>

                          {/* Message actions */}
                          {selectedMessage === message.id && (
                            <motion.div
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              className="absolute -top-12 left-0 right-0 flex justify-center"
                            >
                              <div className="bg-popover border border-border rounded-lg shadow-lg p-1 flex space-x-1">
                                {reactions.map((reaction) => (
                                  <Button
                                    key={reaction.emoji}
                                    variant="ghost"
                                    size="sm"
                                    className="w-8 h-8 p-0"
                                    onClick={() => handleReaction(message.id, reaction.emoji)}
                                  >
                                    <span className="text-sm">{reaction.emoji}</span>
                                  </Button>
                                ))}
                                <div className="border-l border-border mx-1" />
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-8 h-8 p-0"
                                  onClick={() => setReplyToMessage(message)}
                                >
                                  <Reply className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="w-8 h-8 p-0"
                                  onClick={() => {
                                    navigator.clipboard.writeText(message.message);
                                    notifications.success('Copied', 'Message copied to clipboard');
                                  }}
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            </motion.div>
                          )}
                        </div>

                        {/* Reactions */}
                        {message.reactions && message.reactions.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {message.reactions.map((reaction, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="h-6 px-2 text-xs"
                                onClick={() => handleReaction(message.id, reaction.emoji)}
                              >
                                {reaction.emoji} 1
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Avatar for other users */}
                      {message.fromUserId !== user?.id && (
                        <Avatar className="h-8 w-8 mr-2 order-2">
                          <AvatarFallback className="text-xs">
                            {getInitials(message.fromUserName)}
                          </AvatarFallback>
                        </Avatar>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Reply Preview */}
            {replyToMessage && (
              <div className="px-4 py-3 bg-muted/30 border-t border-border">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Reply className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Replying to {replyToMessage.fromUserName}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setReplyToMessage(null)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm bg-muted rounded px-2 py-1 mt-1 truncate">
                  {replyToMessage.message}
                </p>
              </div>
            )}

            {/* Message Input */}
            <div className="p-4 border-t border-border">
              <div className="flex items-end space-x-3">
                <div className="flex-1">
                  <Textarea
                    ref={messageInputRef}
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder={`Message ${selectedUser ? selectedUser.name : selectedRoom?.name}...`}
                    className="min-h-[50px] max-h-32 resize-none"
                    rows={2}
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  {/* File upload */}
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    onChange={handleFileUpload}
                    accept="*/*"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => document.getElementById('file-upload')?.click()}
                  >
                    <Paperclip className="w-4 h-4" />
                  </Button>

                  {/* Image upload */}
                  <input
                    type="file"
                    id="image-upload"
                    className="hidden"
                    onChange={handleFileUpload}
                    accept="image/*"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => document.getElementById('image-upload')?.click()}
                  >
                    <Image className="w-4 h-4" />
                  </Button>

                  {/* Voice recording */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onMouseDown={startRecording}
                    onMouseUp={stopRecording}
                    onMouseLeave={stopRecording}
                    className={isRecording ? 'bg-destructive text-destructive-foreground' : ''}
                  >
                    {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </Button>

                  {/* Emoji picker */}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                  >
                    <Smile className="w-4 h-4" />
                  </Button>

                  {/* Send button */}
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim() || loading}
                    className="btn-primary"
                  >
                    {loading ? (
                      <InlineLoading />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>

              {isRecording && (
                <div className="mt-3 p-3 bg-destructive/10 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-destructive rounded-full animate-pulse" />
                    <span className="text-sm text-destructive font-medium">
                      Recording voice message... (Hold to record, release to send)
                    </span>
                  </div>
                </div>
              )}
            </div>
          </>
        ) : (
          /* No conversation selected */
          <div className="flex items-center justify-center h-full">
            <div className="text-center max-w-md">
              <Building2 className="w-16 h-16 mx-auto mb-4 text-primary opacity-50" />
              <h2 className="text-2xl font-semibold mb-2">Welcome to Team Chat</h2>
              <p className="text-muted-foreground mb-6">
                Connect with your startup team, create project rooms, and collaborate with fellow entrepreneurs. 
                Select a conversation or create a new room to get started.
              </p>
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span>Real-time team collaboration</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span>Voice messages and file sharing</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span>Startup-focused room types</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                  <span>Global user search and discovery</span>
                </div>
              </div>
              
              <div className="mt-6">
                <Button 
                  onClick={() => setShowCreateRoom(true)}
                  className="btn-primary"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Your First Room
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <motion.div
          initial={{ x: 300, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 300, opacity: 0 }}
          className="w-80 border-l border-border bg-muted/30 p-4"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Chat Settings</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings(false)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Sound notifications</p>
                <p className="text-sm text-muted-foreground">Play sound for new messages</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </Button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Push notifications</p>
                <p className="text-sm text-muted-foreground">Show desktop notifications</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              >
                {notificationsEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
              </Button>
            </div>

            <div className="pt-4 border-t border-border">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  const data = chatManager.exportChatData();
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `team-chat-export-${new Date().toISOString().split('T')[0]}.json`;
                  document.body.appendChild(a);
                  a.click();
                  document.body.removeChild(a);
                  URL.revokeObjectURL(url);
                  notifications.success('Export complete', 'Team chat data exported successfully');
                }}
              >
                <Download className="w-4 h-4 mr-2" />
                Export Chat Data
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

export default Chat;