import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Switch } from '../components/ui/switch';
import { Progress } from '../components/ui/progress';
import { Separator } from '../components/ui/separator';
import { Alert, AlertDescription } from '../components/ui/alert';
import { useAuth } from '../contexts/AuthContext';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';
import { chatManager, type ChatMessage, type ChatUser } from '../utils/chatUtils';
import { notifications } from '../utils/notifications';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Users, 
  FileText, 
  MessageCircle,
  Award,
  Send,
  Eye,
  Download,
  Settings,
  BarChart3,
  Search,
  UserCheck,
  UserX,
  Mail,
  Phone,
  Calendar,
  CheckCircle,
  XCircle,
  Edit,
  Trash2,
  PlusCircle,
  AlertTriangle,
  Clock,
  Reply,
  Archive,
  Star,
  Filter,
  RefreshCw,
  Bell,
  Activity,
  Database,
  Lock,
  Zap,
  TrendingUp,
  Globe,
  Server,
  HardDrive,
  Wifi,
  AlertCircle,
  Info,
  CheckCircle2,
  Upload,
  FileDown,
  Copy,
  ExternalLink,
  Key,
  UserPlus,
  UserMinus,
  MoreHorizontal,
  Pause,
  Play,
  RotateCcw,
  Save,
  Loader2
} from 'lucide-react';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface StoredUser {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin' | 'moderator';
  lastLogin: string;
  status: 'active' | 'suspended' | 'pending' | 'banned';
  createdAt: string;
  profileCompleteness: number;
  permissions?: string[];
  loginAttempts?: number;
  lastActivity?: string;
  ipAddress?: string;
  device?: string;
}

interface SystemLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warning' | 'error' | 'critical';
  category: string;
  message: string;
  userId?: string;
  metadata?: Record<string, any>;
}

interface PlatformSettings {
  maintenanceMode: boolean;
  allowRegistrations: boolean;
  emailNotifications: boolean;
  telegramNotifications: boolean;
  autoApproval: boolean;
  maxLoginAttempts: number;
  sessionTimeout: number;
  backupFrequency: 'daily' | 'weekly' | 'monthly';
  featureFlags: Record<string, boolean>;
}

interface ContentItem {
  id: string;
  type: 'startup' | 'mentor' | 'program' | 'resource';
  title: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedBy: string;
  submittedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  content: any;
}

interface Certificate {
  id: string;
  recipientId: string;
  recipientEmail: string;
  recipientName: string;
  certificateType: string;
  issuedDate: string;
  customMessage?: string;
  issuedBy: string;
}

export function Admin() {
  const { user, isAdmin } = useAuth();
  
  // State management
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Data states
  const [users, setUsers] = useState<StoredUser[]>([]);
  const [systemLogs, setSystemLogs] = useState<SystemLog[]>([]);
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>({
    maintenanceMode: false,
    allowRegistrations: true,
    emailNotifications: true,
    telegramNotifications: true,
    autoApproval: false,
    maxLoginAttempts: 5,
    sessionTimeout: 24,
    backupFrequency: 'daily',
    featureFlags: {
      betaFeatures: false,
      advancedAnalytics: true,
      aiAssistant: false,
      experimentalUI: false
    }
  });
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [chatUsers, setChatUsers] = useState<ChatUser[]>([]);
  const [selectedChatUser, setSelectedChatUser] = useState<ChatUser | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newChatMessage, setNewChatMessage] = useState('');

  // Form states
  const [userForm, setUserForm] = useState({
    email: '',
    name: '',
    role: 'user' as 'user' | 'admin' | 'moderator',
    permissions: [] as string[]
  });

  const [certificateForm, setCertificateForm] = useState({
    recipientEmail: '',
    certificateType: '',
    customMessage: ''
  });

  const [bulkAction, setBulkAction] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  // Load data on mount
  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadUsers(),
        loadSystemLogs(),
        loadPlatformSettings(),
        loadContentItems(),
        loadCertificates(),
        loadChatData()
      ]);
    } catch (error) {
      console.error('Error loading admin data:', error);
      notifications.error('Error', 'Failed to load admin data');
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const storedUsers = localStorage.getItem('smart-admin-users') || '[]';
      const parsedUsers = JSON.parse(storedUsers);
      
      if (parsedUsers.length === 0) {
        const mockUsers: StoredUser[] = [
          {
            id: 'user-1',
            name: 'John Doe',
            email: 'john@example.com',
            role: 'user',
            status: 'active',
            createdAt: '2024-01-15T00:00:00Z',
            lastLogin: new Date().toISOString(),
            profileCompleteness: 85,
            permissions: ['read', 'write'],
            loginAttempts: 0,
            lastActivity: new Date().toISOString(),
            ipAddress: '192.168.1.1',
            device: 'Chrome on Windows'
          },
          {
            id: 'user-2',
            name: 'Jane Smith',
            email: 'jane@example.com',
            role: 'user',
            status: 'active',
            createdAt: '2024-01-10T00:00:00Z',
            lastLogin: new Date(Date.now() - 86400000).toISOString(),
            profileCompleteness: 92,
            permissions: ['read', 'write'],
            loginAttempts: 1,
            lastActivity: new Date(Date.now() - 3600000).toISOString(),
            ipAddress: '192.168.1.2',
            device: 'Safari on macOS'
          },
          {
            id: 'user-3',
            name: 'Mike Johnson',
            email: 'mike@example.com',
            role: 'moderator',
            status: 'active',
            createdAt: '2024-01-05T00:00:00Z',
            lastLogin: new Date(Date.now() - 172800000).toISOString(),
            profileCompleteness: 78,
            permissions: ['read', 'write', 'moderate'],
            loginAttempts: 0,
            lastActivity: new Date(Date.now() - 7200000).toISOString(),
            ipAddress: '192.168.1.3',
            device: 'Firefox on Linux'
          }
        ];
        setUsers(mockUsers);
        localStorage.setItem('smart-admin-users', JSON.stringify(mockUsers));
      } else {
        setUsers(parsedUsers);
      }
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadSystemLogs = async () => {
    try {
      const storedLogs = localStorage.getItem('smart-system-logs') || '[]';
      const parsedLogs = JSON.parse(storedLogs);
      
      if (parsedLogs.length === 0) {
        const mockLogs: SystemLog[] = [
          {
            id: 'log-1',
            timestamp: new Date().toISOString(),
            level: 'info',
            category: 'User Activity',
            message: 'User john@example.com logged in successfully',
            userId: 'user-1',
            metadata: { ipAddress: '192.168.1.1', userAgent: 'Chrome/119.0' }
          },
          {
            id: 'log-2',
            timestamp: new Date(Date.now() - 3600000).toISOString(),
            level: 'warning',
            category: 'Security',
            message: 'Failed login attempt for admin@example.com',
            metadata: { ipAddress: '192.168.1.100', attempts: 3 }
          },
          {
            id: 'log-3',
            timestamp: new Date(Date.now() - 7200000).toISOString(),
            level: 'error',
            category: 'System',
            message: 'Database connection timeout',
            metadata: { duration: '5000ms', query: 'SELECT * FROM users' }
          }
        ];
        setSystemLogs(mockLogs);
        localStorage.setItem('smart-system-logs', JSON.stringify(mockLogs));
      } else {
        setSystemLogs(parsedLogs);
      }
    } catch (error) {
      console.error('Error loading system logs:', error);
    }
  };

  const loadPlatformSettings = async () => {
    try {
      const stored = localStorage.getItem('smart-platform-settings');
      if (stored) {
        setPlatformSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading platform settings:', error);
    }
  };

  const loadContentItems = async () => {
    try {
      const stored = localStorage.getItem('smart-content-items') || '[]';
      const parsed = JSON.parse(stored);
      
      if (parsed.length === 0) {
        const mockContent: ContentItem[] = [
          {
            id: 'content-1',
            type: 'startup',
            title: 'AI-Powered Learning Platform',
            status: 'pending',
            submittedBy: 'john@example.com',
            submittedAt: new Date().toISOString(),
            content: { description: 'Revolutionary AI learning platform for students' }
          },
          {
            id: 'content-2',
            type: 'mentor',
            title: 'Tech Industry Veteran - Sarah Wilson',
            status: 'approved',
            submittedBy: 'jane@example.com',
            submittedAt: new Date(Date.now() - 86400000).toISOString(),
            reviewedBy: user?.email,
            reviewedAt: new Date(Date.now() - 3600000).toISOString(),
            content: { experience: '15 years in tech industry' }
          }
        ];
        setContentItems(mockContent);
        localStorage.setItem('smart-content-items', JSON.stringify(mockContent));
      } else {
        setContentItems(parsed);
      }
    } catch (error) {
      console.error('Error loading content items:', error);
    }
  };

  const loadCertificates = async () => {
    try {
      const storedCertificates = localStorage.getItem('smart-admin-certificates') || '[]';
      setCertificates(JSON.parse(storedCertificates));
    } catch (error) {
      console.error('Error loading certificates:', error);
    }
  };

  const loadChatData = () => {
    try {
      const users = chatManager.getChatUsers();
      setChatUsers(users);
    } catch (error) {
      console.error('Error loading chat data:', error);
    }
  };

  // User management functions
  const handleCreateUser = async () => {
    if (!userForm.email || !userForm.name || !user) {
      notifications.error('Missing Information', 'Please fill in all required fields.');
      return;
    }

    try {
      setLoading(true);
      const newUser: StoredUser = {
        id: `user-${Date.now()}`,
        email: userForm.email,
        name: userForm.name,
        role: userForm.role,
        status: 'active',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        profileCompleteness: 30,
        permissions: userForm.permissions,
        loginAttempts: 0,
        lastActivity: new Date().toISOString(),
        ipAddress: '0.0.0.0',
        device: 'Created by admin'
      };

      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      localStorage.setItem('smart-admin-users', JSON.stringify(updatedUsers));

      // Track the action
      await telegramBot.trackAdminAction(
        formatUserForTelegram(user),
        'User Created',
        {
          userEmail: newUser.email,
          userName: newUser.name,
          role: newUser.role
        }
      );

      // Reset form
      setUserForm({
        email: '',
        name: '',
        role: 'user',
        permissions: []
      });

      notifications.success('User Created', `User ${newUser.name} has been created successfully.`);
    } catch (error) {
      console.error('Error creating user:', error);
      notifications.error('Error', 'Failed to create user.');
    } finally {
      setLoading(false);
    }
  };

  const handleIssueCertificate = async () => {
    if (!certificateForm.recipientEmail || !certificateForm.certificateType || !user) {
      notifications.error('Missing Information', 'Please fill in all required fields.');
      return;
    }

    setLoading(true);
    try {
      const newCertificate: Certificate = {
        id: `cert-${Date.now()}`,
        recipientId: `user-${Date.now()}`,
        recipientEmail: certificateForm.recipientEmail,
        recipientName: certificateForm.recipientEmail.split('@')[0],
        certificateType: certificateForm.certificateType,
        issuedDate: new Date().toISOString(),
        customMessage: certificateForm.customMessage,
        issuedBy: user.name
      };

      const updatedCertificates = [...certificates, newCertificate];
      setCertificates(updatedCertificates);
      localStorage.setItem('smart-admin-certificates', JSON.stringify(updatedCertificates));

      // Send Telegram notification
      await telegramBot.trackAdminAction(
        formatUserForTelegram(user),
        'Certificate Issued',
        {
          recipient: certificateForm.recipientEmail,
          type: certificateForm.certificateType,
          message: certificateForm.customMessage || 'No custom message'
        }
      );

      // Reset form
      setCertificateForm({
        recipientEmail: '',
        certificateType: '',
        customMessage: ''
      });

      notifications.success('Certificate Issued', `Certificate sent to ${certificateForm.recipientEmail}`);
    } catch (error) {
      console.error('Error issuing certificate:', error);
      notifications.error('Error', 'Failed to issue certificate');
    } finally {
      setLoading(false);
    }
  };

  // Settings management
  const handleSettingChange = async (key: keyof PlatformSettings, value: any) => {
    try {
      const newSettings = { ...platformSettings, [key]: value };
      setPlatformSettings(newSettings);
      localStorage.setItem('smart-platform-settings', JSON.stringify(newSettings));
      
      // Track in Telegram
      if (user) {
        await telegramBot.trackAdminAction(
          formatUserForTelegram(user),
          'Settings Updated',
          { setting: key, newValue: value }
        );
      }

      notifications.success('Settings Updated', `${key} has been updated successfully.`);
    } catch (error) {
      console.error('Error updating settings:', error);
      notifications.error('Error', 'Failed to update settings.');
    }
  };

  // Chat functions
  const handleChatUserSelect = (chatUser: ChatUser) => {
    setSelectedChatUser(chatUser);
    const messages = chatManager.getUserMessages(chatUser.id);
    setChatMessages(messages);
    chatManager.markMessagesAsRead(chatUser.id, true);
  };

  const handleSendChatMessage = async () => {
    if (!selectedChatUser || !newChatMessage.trim() || !user) return;

    try {
      const message = await chatManager.sendMessage(
        selectedChatUser.id,
        selectedChatUser.name,
        selectedChatUser.email,
        newChatMessage.trim(),
        true,
        user
      );

      setChatMessages(prev => [...prev, message]);
      setNewChatMessage('');
      loadChatData();
      
      notifications.success('Message Sent', 'Your message has been sent to the user.');
    } catch (error) {
      console.error('Error sending chat message:', error);
      notifications.error('Error', 'Failed to send message.');
    }
  };

  // Utility functions
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'suspended': return 'bg-yellow-500';
      case 'banned': return 'bg-red-500';
      case 'pending': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const getLogLevelColor = (level: SystemLog['level']) => {
    switch (level) {
      case 'info': return 'text-blue-600 bg-blue-50';
      case 'warning': return 'text-yellow-600 bg-yellow-50';
      case 'error': return 'text-red-600 bg-red-50';
      case 'critical': return 'text-purple-600 bg-purple-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  // Access check
  if (!isAdmin) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center py-12">
          <div className="w-16 h-16 mx-auto mb-4">
            <img src={smartLogo} alt="SMART" className="w-full h-full object-contain opacity-50" />
          </div>
          <Shield className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">This page requires admin access.</p>
          <div className="mt-6 p-4 bg-muted rounded-lg">
            <p className="text-sm font-medium mb-2">Admin Login Credentials:</p>
            <p className="text-sm text-muted-foreground">Email: admin2025@gmail.com</p>
            <p className="text-sm text-muted-foreground">Password: admin2025@)@%</p>
          </div>
        </div>
      </div>
    );
  }

  // Calculate stats
  const stats = [
    { 
      title: 'Total Users', 
      value: users.length.toString(), 
      change: '+12%', 
      icon: Users,
      color: 'text-blue-600'
    },
    { 
      title: 'Active Sessions', 
      value: users.filter(u => u.status === 'active').length.toString(), 
      change: '+5%', 
      icon: Activity,
      color: 'text-green-600'
    },
    { 
      title: 'Chat Messages', 
      value: chatManager.getChatStats().totalMessages.toString(), 
      change: '+23%', 
      icon: MessageCircle,
      color: 'text-purple-600'
    },
    { 
      title: 'Certificates', 
      value: certificates.length.toString(), 
      change: '+8%', 
      icon: Award,
      color: 'text-emerald-600'
    }
  ];

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingContent = contentItems.filter(item => item.status === 'pending');

  return (
    <div className="max-w-[1400px] mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8">
            <img src={smartLogo} alt="SMART" className="w-full h-full object-contain" />
          </div>
          <Shield className="w-6 h-6 text-destructive" />
          <h1 className="text-3xl font-bold">Admin Control Center</h1>
        </div>
        <p className="text-muted-foreground">
          Comprehensive platform management and monitoring dashboard
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold mb-1">{stat.value}</p>
                  <p className="text-xs text-green-600 font-medium">{stat.change}</p>
                </div>
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color} bg-opacity-10`}>
                  <IconComponent className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="users" className="relative">
            Users
            {users.filter(u => u.status === 'pending').length > 0 && (
              <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs bg-red-500">
                {users.filter(u => u.status === 'pending').length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="chat" className="relative">
            Chat
            {chatManager.getAdminUnreadCount() > 0 && (
              <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs bg-red-500">
                {chatManager.getAdminUnreadCount()}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="content" className="relative">
            Content
            {pendingContent.length > 0 && (
              <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 text-xs bg-orange-500">
                {pendingContent.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Quick Actions */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
              <div className="grid grid-cols-2 gap-3">
                <Button className="btn-primary justify-start" onClick={() => setActiveTab('users')}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add User
                </Button>
                <Button variant="outline" onClick={() => setActiveTab('certificates')}>
                  <Award className="w-4 h-4 mr-2" />
                  Issue Certificate
                </Button>
                <Button variant="outline" onClick={() => setActiveTab('content')}>
                  <Eye className="w-4 h-4 mr-2" />
                  Review Content
                </Button>
                <Button variant="outline" onClick={() => setActiveTab('settings')}>
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </Card>

            {/* System Status */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">System Status</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Platform Status</span>
                  </div>
                  <Badge variant="outline" className="text-green-600">Operational</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm">Database</span>
                  </div>
                  <Badge variant="outline" className="text-green-600">Connected</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${telegramBot.getStatus().enabled ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                    <span className="text-sm">Telegram Bot</span>
                  </div>
                  <Badge variant="outline" className={telegramBot.getStatus().enabled ? "text-green-600" : "text-yellow-600"}>
                    {telegramBot.getStatus().enabled ? 'Active' : 'Disabled'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${platformSettings.maintenanceMode ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
                    <span className="text-sm">Maintenance Mode</span>
                  </div>
                  <Badge variant="outline" className={platformSettings.maintenanceMode ? "text-yellow-600" : "text-green-600"}>
                    {platformSettings.maintenanceMode ? 'Enabled' : 'Disabled'}
                  </Badge>
                </div>
              </div>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {systemLogs.slice(0, 5).map((log) => (
                <div key={log.id} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                  <div className={`w-2 h-2 rounded-full ${log.level === 'error' ? 'bg-red-500' : log.level === 'warning' ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{log.message}</p>
                    <p className="text-xs text-muted-foreground">{log.category} • {formatTime(log.timestamp)}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Users Tab */}
        <TabsContent value="users" className="space-y-6">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* User List */}
            <div className="flex-1">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold">User Management</h3>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search users..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {filteredUsers.map((user) => (
                    <div key={user.id} className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-muted/30 transition-colors">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-medium truncate">{user.name}</p>
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(user.status)}`}></div>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {user.role}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {user.profileCompleteness}%
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            Last: {formatTime(user.lastLogin)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="outline">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Edit className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>

            {/* Add User Form */}
            <div className="lg:w-80">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Add New User</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <Input
                      type="email"
                      value={userForm.email}
                      onChange={(e) => setUserForm(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="user@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Full Name</label>
                    <Input
                      value={userForm.name}
                      onChange={(e) => setUserForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Role</label>
                    <Select 
                      value={userForm.role} 
                      onValueChange={(value: 'user' | 'admin' | 'moderator') => 
                        setUserForm(prev => ({ ...prev, role: value }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="moderator">Moderator</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    className="btn-primary w-full" 
                    onClick={handleCreateUser}
                    disabled={loading}
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <UserPlus className="w-4 h-4 mr-2" />
                    )}
                    Create User
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Chat Tab */}
        <TabsContent value="chat" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
            {/* Chat Users List */}
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Chat Users ({chatUsers.length})</h3>
                <Button size="sm" variant="outline" onClick={loadChatData}>
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="space-y-2 overflow-y-auto max-h-[500px]">
                {chatUsers.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No chat conversations yet</p>
                  </div>
                ) : (
                  chatUsers.map((chatUser) => (
                    <div
                      key={chatUser.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedChatUser?.id === chatUser.id 
                          ? 'bg-primary/10 border border-primary' 
                          : 'hover:bg-muted'
                      }`}
                      onClick={() => handleChatUserSelect(chatUser)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3 flex-1 min-w-0">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback>
                              {getInitials(chatUser.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{chatUser.name}</p>
                            <p className="text-sm text-muted-foreground truncate">
                              {chatUser.lastMessage || 'No messages yet'}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end space-y-1">
                          {chatUser.lastMessageTime && (
                            <span className="text-xs text-muted-foreground">
                              {formatTime(chatUser.lastMessageTime)}
                            </span>
                          )}
                          {chatUser.unreadCount > 0 && (
                            <Badge className="bg-destructive text-destructive-foreground text-xs">
                              {chatUser.unreadCount}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>

            {/* Chat Messages */}
            <Card className="lg:col-span-2 flex flex-col">
              {selectedChatUser ? (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-border">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>
                            {getInitials(selectedChatUser.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{selectedChatUser.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {selectedChatUser.email}
                          </p>
                        </div>
                      </div>
                      <Badge variant={selectedChatUser.isOnline ? 'default' : 'secondary'}>
                        {selectedChatUser.isOnline ? 'Online' : 'Offline'}
                      </Badge>
                    </div>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {chatMessages.length === 0 ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="text-center">
                          <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                          <p className="text-sm text-muted-foreground">No messages yet</p>
                        </div>
                      </div>
                    ) : (
                      <AnimatePresence initial={false}>
                        {chatMessages.map((message) => (
                          <motion.div
                            key={message.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex ${message.isFromAdmin ? 'justify-end' : 'justify-start'}`}
                          >
                            <div className={`max-w-xs lg:max-w-md rounded-2xl px-4 py-2 ${
                              message.isFromAdmin 
                                ? 'bg-primary text-primary-foreground' 
                                : 'bg-muted text-foreground'
                            }`}>
                              <p className="text-sm">{message.message}</p>
                              <div className="flex items-center justify-end mt-1 space-x-1">
                                <span className={`text-xs ${
                                  message.isFromAdmin 
                                    ? 'text-primary-foreground/70' 
                                    : 'text-muted-foreground'
                                }`}>
                                  {formatTime(message.timestamp)}
                                </span>
                                {message.isFromAdmin && (
                                  <CheckCircle className="w-3 h-3" />
                                )}
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                    )}
                  </div>

                  {/* Message Input */}
                  <div className="p-4 border-t border-border">
                    <div className="flex space-x-2">
                      <Input
                        value={newChatMessage}
                        onChange={(e) => setNewChatMessage(e.target.value)}
                        placeholder="Type your message..."
                        className="flex-1"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendChatMessage();
                          }
                        }}
                      />
                      <Button 
                        onClick={handleSendChatMessage}
                        disabled={!newChatMessage.trim() || loading}
                        className="btn-primary"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Select a conversation</h3>
                    <p className="text-muted-foreground">Choose a user from the left to start chatting</p>
                  </div>
                </div>
              )}
            </Card>
          </div>
        </TabsContent>

        {/* Certificates Tab */}
        <TabsContent value="certificates" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-6">Issue New Certificate</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Recipient Email</label>
                  <Input 
                    placeholder="user@example.com"
                    value={certificateForm.recipientEmail}
                    onChange={(e) => setCertificateForm(prev => ({ ...prev, recipientEmail: e.target.value }))}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Certificate Type</label>
                  <Select 
                    value={certificateForm.certificateType}
                    onValueChange={(value) => setCertificateForm(prev => ({ ...prev, certificateType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select certificate type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="course-completion">Course Completion</SelectItem>
                      <SelectItem value="program-graduate">Program Graduate</SelectItem>
                      <SelectItem value="achievement-award">Achievement Award</SelectItem>
                      <SelectItem value="mentorship-certificate">Mentorship Certificate</SelectItem>
                      <SelectItem value="startup-pitch">Startup Pitch Excellence</SelectItem>
                      <SelectItem value="leadership">Leadership Recognition</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">Custom Message (Optional)</label>
                  <Textarea 
                    placeholder="Add a personal message..."
                    rows={3}
                    value={certificateForm.customMessage}
                    onChange={(e) => setCertificateForm(prev => ({ ...prev, customMessage: e.target.value }))}
                  />
                </div>
                
                <Button 
                  className="btn-primary w-full"
                  onClick={handleIssueCertificate}
                  disabled={loading}
                >
                  <Award className="w-4 h-4 mr-2" />
                  {loading ? 'Issuing...' : 'Issue Certificate'}
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-6">Recent Certificates</h3>
              
              <div className="space-y-4">
                {certificates.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Award className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No certificates issued yet</p>
                  </div>
                ) : (
                  certificates.slice(-5).reverse().map((cert) => (
                    <div key={cert.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">{cert.recipientName}</p>
                        <Badge variant="outline">{cert.certificateType}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">{cert.recipientEmail}</p>
                      <p className="text-xs text-muted-foreground">
                        Issued {new Date(cert.issuedDate).toLocaleDateString()}
                      </p>
                      {cert.customMessage && (
                        <p className="text-sm mt-2 p-2 bg-muted rounded">
                          "{cert.customMessage}"
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </Card>
          </div>
        </TabsContent>

        {/* Content Tab */}
        <TabsContent value="content">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-6">Content Moderation</h3>
            <div className="space-y-4">
              {contentItems.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No content to review</p>
                </div>
              ) : (
                contentItems.map((item) => (
                  <div key={item.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{item.title}</h4>
                      <Badge variant={
                        item.status === 'approved' ? 'default' : 
                        item.status === 'rejected' ? 'destructive' : 'secondary'
                      }>
                        {item.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Type: {item.type} • Submitted by: {item.submittedBy}
                    </p>
                    <p className="text-xs text-muted-foreground mb-3">
                      Submitted: {formatTime(item.submittedAt)}
                    </p>
                    {item.status === 'pending' && (
                      <div className="flex gap-2">
                        <Button size="sm" className="btn-primary">
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Approve
                        </Button>
                        <Button size="sm" variant="destructive">
                          <XCircle className="w-4 h-4 mr-1" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <div className="text-center py-12">
            <BarChart3 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Analytics Dashboard</h3>
            <p className="text-muted-foreground">Comprehensive analytics and reporting tools coming soon.</p>
          </div>
        </TabsContent>

        {/* Logs Tab */}
        <TabsContent value="logs">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">System Logs</h3>
              <Button variant="outline" size="sm" onClick={loadSystemLogs}>
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
            <div className="space-y-2">
              {systemLogs.slice(0, 20).map((log) => (
                <div key={log.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                  <Badge className={`text-xs ${getLogLevelColor(log.level)}`}>
                    {log.level.toUpperCase()}
                  </Badge>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{log.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground">{log.category}</span>
                      <span className="text-xs text-muted-foreground">•</span>
                      <span className="text-xs text-muted-foreground">{formatTime(log.timestamp)}</span>
                      {log.userId && (
                        <>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground">User: {log.userId}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Platform Settings</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Maintenance Mode</p>
                    <p className="text-sm text-muted-foreground">Temporarily disable platform access</p>
                  </div>
                  <Switch
                    checked={platformSettings.maintenanceMode}
                    onCheckedChange={(checked) => handleSettingChange('maintenanceMode', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Allow Registrations</p>
                    <p className="text-sm text-muted-foreground">Enable new user signups</p>
                  </div>
                  <Switch
                    checked={platformSettings.allowRegistrations}
                    onCheckedChange={(checked) => handleSettingChange('allowRegistrations', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Email Notifications</p>
                    <p className="text-sm text-muted-foreground">Send email notifications to users</p>
                  </div>
                  <Switch
                    checked={platformSettings.emailNotifications}
                    onCheckedChange={(checked) => handleSettingChange('emailNotifications', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Telegram Notifications</p>
                    <p className="text-sm text-muted-foreground">Send admin notifications via Telegram</p>
                  </div>
                  <Switch
                    checked={platformSettings.telegramNotifications}
                    onCheckedChange={(checked) => handleSettingChange('telegramNotifications', checked)}
                  />
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Telegram Bot Control</h3>
              <div className="space-y-4">
                <div className="p-4 bg-muted/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Bot Status</span>
                    <Badge variant={telegramBot.getStatus().enabled ? 'default' : 'secondary'}>
                      {telegramBot.getStatus().enabled ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">
                    Queue: {telegramBot.getStatus().queueLength} messages
                  </p>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      onClick={() => telegramBot.setEnabled(!telegramBot.getStatus().enabled)}
                      variant={telegramBot.getStatus().enabled ? 'destructive' : 'default'}
                    >
                      {telegramBot.getStatus().enabled ? 'Disable' : 'Enable'}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => telegramBot.sendTestMessage()}>
                      Test
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => telegramBot.clearQueue()}>
                      Clear Queue
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}