import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { useAuth } from '../contexts/AuthContext';
import { 
  FileText, 
  Search, 
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  ExternalLink,
  Download,
  Edit,
  Eye,
  Plus
} from 'lucide-react';

interface Application {
  id: string;
  programId: string;
  programName: string;
  programType: 'Accelerator' | 'Incubator' | 'Fellowship' | 'Competition';
  status: 'draft' | 'submitted' | 'under_review' | 'interview' | 'accepted' | 'rejected' | 'waitlisted';
  submittedAt?: string;
  lastUpdated: string;
  deadline: string;
  completionPercentage: number;
  nextSteps?: string;
  feedback?: string;
  interviewDate?: string;
  programUrl?: string;
  estimatedResponse?: string;
}

export function MyApplications() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [applications, setApplications] = useState<Application[]>([]);

  useEffect(() => {
    // Load applications from localStorage or API
    const savedApplications = localStorage.getItem(`applications-${user?.id}`);
    if (savedApplications) {
      setApplications(JSON.parse(savedApplications));
    } else {
      // Demo data
      setApplications([
        {
          id: 'app-1',
          programId: 'techstars-2024',
          programName: 'Techstars Accelerator Program',
          programType: 'Accelerator',
          status: 'under_review',
          submittedAt: '2024-01-15T10:00:00Z',
          lastUpdated: '2024-01-20T14:30:00Z',
          deadline: '2024-03-15T23:59:59Z',
          completionPercentage: 100,
          nextSteps: 'Waiting for initial review. You will hear back within 2-3 weeks.',
          estimatedResponse: '2024-02-05T23:59:59Z'
        },
        {
          id: 'app-2',
          programId: 'ycombinator-2024',
          programName: 'Y Combinator W24 Batch',
          programType: 'Accelerator',
          status: 'interview',
          submittedAt: '2024-01-10T16:00:00Z',
          lastUpdated: '2024-01-25T09:15:00Z',
          deadline: '2024-04-01T23:59:59Z',
          completionPercentage: 100,
          nextSteps: 'Interview scheduled. Prepare your 2-minute pitch and demo.',
          interviewDate: '2024-02-10T15:00:00Z'
        },
        {
          id: 'app-3',
          programId: 'founder-fellowship',
          programName: 'Student Founder Fellowship',
          programType: 'Fellowship',
          status: 'draft',
          lastUpdated: '2024-01-28T11:20:00Z',
          deadline: '2024-03-30T23:59:59Z',
          completionPercentage: 65,
          nextSteps: 'Complete the business model section and submit your pitch video.'
        },
        {
          id: 'app-4',
          programId: 'startup-competition',
          programName: 'National Student Startup Competition',
          programType: 'Competition',
          status: 'accepted',
          submittedAt: '2024-01-05T12:00:00Z',
          lastUpdated: '2024-01-30T10:00:00Z',
          deadline: '2024-02-28T23:59:59Z',
          completionPercentage: 100,
          nextSteps: 'Congratulations! Prepare for the demo day on March 15th.',
          feedback: 'Excellent application! We were impressed by your traction and market validation.'
        },
        {
          id: 'app-5',
          programId: 'local-incubator',
          programName: 'City Tech Incubator',
          programType: 'Incubator',
          status: 'rejected',
          submittedAt: '2023-12-20T14:00:00Z',
          lastUpdated: '2024-01-15T16:30:00Z',
          deadline: '2024-01-31T23:59:59Z',
          completionPercentage: 100,
          feedback: 'Strong concept but needs more market validation. We encourage you to reapply next cycle with additional traction.'
        }
      ]);
    }
  }, [user?.id]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft': return <Edit className="w-4 h-4 text-gray-500" />;
      case 'submitted': return <Clock className="w-4 h-4 text-blue-500" />;
      case 'under_review': return <Eye className="w-4 h-4 text-orange-500" />;
      case 'interview': return <Calendar className="w-4 h-4 text-purple-500" />;
      case 'accepted': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'rejected': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'waitlisted': return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      default: return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      draft: 'bg-gray-100 text-gray-800',
      submitted: 'bg-blue-100 text-blue-800',
      under_review: 'bg-orange-100 text-orange-800',
      interview: 'bg-purple-100 text-purple-800',
      accepted: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      waitlisted: 'bg-yellow-100 text-yellow-800'
    };
    return variants[status] || variants.draft;
  };

  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.programName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || app.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const statusCount = (status: string) => {
    if (status === 'all') return applications.length;
    return applications.filter(app => app.status === status).length;
  };

  const getDaysUntilDeadline = (deadline: string) => {
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (!user) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Please log in to view your applications.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-6 h-6 text-primary" />
              <h1 className="text-3xl font-bold">My Applications</h1>
            </div>
            <p className="text-muted-foreground">
              Track and manage all your program applications in one place.
            </p>
          </div>
          <Button className="btn-primary">
            <Plus className="w-4 h-4 mr-2" />
            New Application
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card className="p-4">
          <div className="text-2xl font-bold text-blue-600">{statusCount('submitted')}</div>
          <div className="text-sm text-muted-foreground">Submitted</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-orange-600">{statusCount('under_review')}</div>
          <div className="text-sm text-muted-foreground">Under Review</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-green-600">{statusCount('accepted')}</div>
          <div className="text-sm text-muted-foreground">Accepted</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-gray-600">{statusCount('draft')}</div>
          <div className="text-sm text-muted-foreground">Drafts</div>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="p-6 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search applications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Tabs value={selectedStatus} onValueChange={setSelectedStatus} className="w-full md:w-auto">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="draft">Drafts</TabsTrigger>
              <TabsTrigger value="submitted">Active</TabsTrigger>
              <TabsTrigger value="accepted">Accepted</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </Card>

      {/* Applications List */}
      {filteredApplications.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">
            {searchQuery ? 'No matching applications' : 'No applications yet'}
          </h3>
          <p className="text-muted-foreground mb-6">
            {searchQuery 
              ? 'Try adjusting your search terms'
              : 'Start by applying to programs that match your startup stage'
            }
          </p>
          <Button className="btn-primary">
            <Plus className="w-4 h-4 mr-2" />
            Create First Application
          </Button>
        </Card>
      ) : (
        <div className="space-y-6">
          {filteredApplications.map((application) => (
            <Card key={application.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {getStatusIcon(application.status)}
                    <h3 className="font-semibold text-lg">{application.programName}</h3>
                    <Badge className={`text-xs ${getStatusBadge(application.status)}`}>
                      {application.status.replace('_', ' ')}
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {application.programType}
                    </Badge>
                  </div>
                  
                  {application.nextSteps && (
                    <p className="text-muted-foreground mb-2">{application.nextSteps}</p>
                  )}
                  
                  {application.feedback && (
                    <div className="bg-muted p-3 rounded-lg mb-2">
                      <p className="text-sm font-medium mb-1">Feedback:</p>
                      <p className="text-sm text-muted-foreground">{application.feedback}</p>
                    </div>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Button size="sm" variant="outline">
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  {application.status === 'draft' && (
                    <Button size="sm" variant="outline">
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                  )}
                  <Button size="sm" variant="outline">
                    <Download className="w-4 h-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Progress</div>
                  <div className="flex items-center gap-2">
                    <Progress value={application.completionPercentage} className="flex-1" />
                    <span className="text-sm text-muted-foreground">
                      {application.completionPercentage}%
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-sm font-medium">Deadline</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(application.deadline).toLocaleDateString()}
                    {getDaysUntilDeadline(application.deadline) > 0 && (
                      <span className={`ml-2 ${getDaysUntilDeadline(application.deadline) <= 7 ? 'text-red-600' : 'text-green-600'}`}>
                        ({getDaysUntilDeadline(application.deadline)} days left)
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-sm font-medium">Last Updated</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(application.lastUpdated).toLocaleDateString()}
                  </div>
                </div>
              </div>

              {application.interviewDate && (
                <div className="bg-purple-50 border border-purple-200 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-purple-800">
                    <Calendar className="w-4 h-4" />
                    <span className="font-medium">Interview Scheduled</span>
                  </div>
                  <p className="text-sm text-purple-700 mt-1">
                    {new Date(application.interviewDate).toLocaleString()}
                  </p>
                </div>
              )}

              {application.estimatedResponse && application.status === 'under_review' && (
                <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-blue-800">
                    <Clock className="w-4 h-4" />
                    <span className="font-medium">Expected Response</span>
                  </div>
                  <p className="text-sm text-blue-700 mt-1">
                    By {new Date(application.estimatedResponse).toLocaleDateString()}
                  </p>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}