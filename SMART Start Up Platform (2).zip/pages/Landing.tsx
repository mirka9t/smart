import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { 
  ArrowRight, 
  Star, 
  Users, 
  Target, 
  Award,
  BookOpen,
  MessageCircle,
  TrendingUp,
  CheckCircle,
  Play,
  ChevronRight,
  Lightbulb,
  Rocket,
  Globe
} from 'lucide-react';
import { AuthModal } from '../components/auth/AuthModals';
import { useAuth } from '../contexts/AuthContext';

export function Landing() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('signup');
  const [email, setEmail] = useState('');
  
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      // Navigate to dashboard if already logged in
      window.history.pushState({}, '', '/dashboard');
      window.dispatchEvent(new PopStateEvent('popstate'));
    } else {
      setAuthMode('signup');
      setAuthModalOpen(true);
    }
  };

  const handleSignIn = () => {
    setAuthMode('login');
    setAuthModalOpen(true);
  };

  const stats = [
    { number: '1000+', label: 'Student Founders', icon: Users },
    { number: '500+', label: 'Successful Pitches', icon: Target },
    { number: '100+', label: 'Expert Mentors', icon: MessageCircle },
    { number: '95%', label: 'Success Rate', icon: Award }
  ];

  const features = [
    {
      icon: BookOpen,
      title: 'Comprehensive Curriculum',
      description: 'Learn from industry experts with our structured program covering every aspect of startup building.'
    },
    {
      icon: Target,
      title: 'GPS v1.0 Deck Generator',
      description: 'Create professional pitch decks using our proven framework and templates.'
    },
    {
      icon: Users,
      title: 'Expert Mentorship',
      description: 'Connect with successful entrepreneurs and industry leaders for personalized guidance.'
    },
    {
      icon: Rocket,
      title: 'Funding Opportunities',
      description: 'Access exclusive funding programs and investor networks to scale your startup.'
    },
    {
      icon: TrendingUp,
      title: 'Performance Tracking',
      description: 'Monitor your progress with detailed analytics and milestone tracking.'
    },
    {
      icon: Globe,
      title: 'Global Community',
      description: 'Join a worldwide network of student entrepreneurs and innovators.'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Founder, EcoTech Solutions',
      university: 'Stanford University',
      content: 'SMART Start Up transformed my idea into a funded startup. The mentorship and resources are incredible!',
      rating: 5,
      avatar: '👩‍💼'
    },
    {
      name: 'Marcus Chen',
      role: 'Co-founder, HealthAI',
      university: 'MIT',
      content: 'The pitch deck generator and rehearsal studio helped me secure $2M in seed funding.',
      rating: 5,
      avatar: '👨‍💻'
    },
    {
      name: 'Alex Rivera',
      role: 'CEO, GreenLogistics',
      university: 'UC Berkeley',
      content: 'Best investment in my entrepreneurial journey. The curriculum is practical and actionable.',
      rating: 5,
      avatar: '🧑‍🚀'
    }
  ];

  const ctaSteps = [
    { step: '1', title: 'Sign Up', description: 'Create your free account' },
    { step: '2', title: 'Learn', description: 'Access our curriculum' },
    { step: '3', title: 'Build', description: 'Create your pitch deck' },
    { step: '4', title: 'Launch', description: 'Present to investors' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-background via-background to-primary/5 py-20 lg:py-32">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto">
            <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 px-4 py-2">
              🚀 The Global Pitch Standard for Student Founders
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 leading-tight">
              Turn Your <span className="text-primary">Ideas</span> Into
              <br />
              <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                Funded Startups
              </span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              The comprehensive platform for student founders aged 14-22. Learn, build, and pitch 
              your way to startup success with our proven SMART methodology.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg" 
                className="btn-primary text-lg px-8 py-6 rounded-full"
                onClick={handleGetStarted}
              >
                {isAuthenticated ? 'Go to Dashboard' : 'Start Your Journey'}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              
              {!isAuthenticated && (
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="text-lg px-8 py-6 rounded-full"
                  onClick={handleSignIn}
                >
                  <Play className="mr-2 w-5 h-5" />
                  Watch Demo
                </Button>
              )}
            </div>

            {/* Newsletter Signup */}
            <div className="max-w-md mx-auto">
              <div className="flex gap-2">
                <Input
                  type="email"
                  placeholder="Enter your email for updates"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="rounded-full"
                />
                <Button type="submit" className="rounded-full px-6">
                  Subscribe
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Join 10,000+ student founders getting weekly insights
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-2">{stat.number}</div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              🎯 Everything You Need
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Built for Student Entrepreneurs
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our platform combines education, tools, and community to give you everything 
              needed to build and launch your startup successfully.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={index} className="p-8 text-center hover:shadow-lg transition-all duration-300 border-0 bg-background/50 backdrop-blur">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <IconComponent className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              💬 Success Stories
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Trusted by Student Founders Worldwide
            </h2>
            <p className="text-xl text-muted-foreground">
              See how SMART Start Up has helped students turn ideas into successful startups
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-8 border-0 bg-background">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 italic">"{testimonial.content}"</p>
                <div className="flex items-center gap-4">
                  <div className="text-2xl">{testimonial.avatar}</div>
                  <div>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-sm text-primary">{testimonial.role}</div>
                    <div className="text-xs text-muted-foreground">{testimonial.university}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary via-primary to-primary/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-6">
            Ready to Build Your Startup?
          </h2>
          <p className="text-xl text-primary-foreground/80 mb-12 max-w-3xl mx-auto">
            Join thousands of student entrepreneurs who are already building the future with SMART Start Up
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {ctaSteps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-primary-foreground/20 rounded-full flex items-center justify-center mx-auto mb-4 text-primary-foreground font-bold text-lg">
                  {step.step}
                </div>
                <h3 className="font-semibold text-primary-foreground mb-2">{step.title}</h3>
                <p className="text-primary-foreground/70 text-sm">{step.description}</p>
              </div>
            ))}
          </div>

          <Button 
            size="lg" 
            variant="secondary"
            className="text-lg px-8 py-6 rounded-full bg-background text-foreground hover:bg-background/90"
            onClick={handleGetStarted}
          >
            {isAuthenticated ? 'Access Dashboard' : 'Get Started Now'}
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
        onSwitchMode={setAuthMode}
      />
    </div>
  );
}