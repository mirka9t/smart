import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { useAuth } from '../contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { 
  User, 
  Mail, 
  Calendar, 
  MapPin, 
  Link, 
  Edit3, 
  Save, 
  X,
  Award,
  TrendingUp,
  Users,
  Download,
  GraduationCap,
  Building,
  Linkedin,
  Camera,
  Star,
  Target,
  Zap
} from 'lucide-react';
import { showSuccess } from '../utils/notifications';

export function Profile() {
  const { user, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    university: user?.university || '',
    major: user?.major || '',
    graduationYear: user?.graduationYear || '',
    linkedinUrl: user?.linkedinUrl || '',
    interests: user?.interests?.join(', ') || '',
    skills: user?.skills?.join(', ') || '',
    startupExperience: user?.startupExperience || ''
  });

  if (!user) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center py-12">
          <p>Please log in to view your profile.</p>
        </div>
      </div>
    );
  }

  const handleSave = () => {
    const interests = editData.interests.split(',').map(s => s.trim()).filter(s => s);
    const skills = editData.skills.split(',').map(s => s.trim()).filter(s => s);
    
    updateProfile({
      name: editData.name,
      bio: editData.bio,
      university: editData.university,
      major: editData.major,
      graduationYear: editData.graduationYear,
      linkedinUrl: editData.linkedinUrl,
      interests,
      skills,
      startupExperience: editData.startupExperience
    });
    
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      name: user?.name || '',
      bio: user?.bio || '',
      university: user?.university || '',
      major: user?.major || '',
      graduationYear: user?.graduationYear || '',
      linkedinUrl: user?.linkedinUrl || '',
      interests: user?.interests?.join(', ') || '',
      skills: user?.skills?.join(', ') || '',
      startupExperience: user?.startupExperience || ''
    });
    setIsEditing(false);
  };

  const handleImageUpload = () => {
    showSuccess('Feature Coming Soon!', 'Profile image upload will be available soon.');
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const achievements = [
    { id: 1, title: 'First Application', description: 'Submitted your first program application', earned: true, date: '2024-01-15' },
    { id: 2, title: 'Networking Pro', description: 'Connected with 5+ mentors', earned: true, date: '2024-01-20' },
    { id: 3, title: 'Pitch Perfect', description: 'Generated your first pitch deck', earned: user.stats.certificatesEarned > 0, date: user.stats.certificatesEarned > 0 ? '2024-01-25' : null },
    { id: 4, title: 'Knowledge Seeker', description: 'Downloaded 10+ resources', earned: user.stats.resourcesDownloaded >= 10, date: user.stats.resourcesDownloaded >= 10 ? '2024-02-01' : null },
    { id: 5, title: 'Super Applicant', description: 'Applied to 10+ opportunities', earned: user.stats.applicationsSubmitted >= 10, date: user.stats.applicationsSubmitted >= 10 ? '2024-02-10' : null },
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Profile Header */}
      <div className="smart-card mb-8">
        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex flex-col items-center md:items-start">
            <div className="relative group">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                  {getInitials(user.name)}
                </AvatarFallback>
              </Avatar>
              <button 
                onClick={handleImageUpload}
                className="absolute inset-0 flex items-center justify-center bg-black/50 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-full"
              >
                <Camera className="w-6 h-6" />
              </button>
            </div>
            
            <div className="mt-4 text-center md:text-left">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant={user.role === 'admin' ? 'destructive' : 'default'}>
                  {user.role === 'admin' ? 'Admin' : 'Student Founder'}
                </Badge>
                <Badge variant="outline">
                  Member since {new Date(user.createdAt).getFullYear()}
                </Badge>
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="flex items-start justify-between mb-4">
              {isEditing ? (
                <div className="flex-1 space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={editData.name}
                      onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      placeholder="Tell us about yourself..."
                      value={editData.bio}
                      onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                      rows={3}
                    />
                  </div>
                </div>
              ) : (
                <div className="flex-1">
                  <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                  <p className="text-muted-foreground mb-4">
                    {user.bio || 'No bio available. Click edit to add one!'}
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="w-4 h-4 text-muted-foreground" />
                      <span>{user.email}</span>
                    </div>
                    
                    {user.university && (
                      <div className="flex items-center gap-2 text-sm">
                        <GraduationCap className="w-4 h-4 text-muted-foreground" />
                        <span>{user.university}</span>
                      </div>
                    )}
                    
                    {user.major && (
                      <div className="flex items-center gap-2 text-sm">
                        <Building className="w-4 h-4 text-muted-foreground" />
                        <span>{user.major}</span>
                      </div>
                    )}
                    
                    {user.graduationYear && (
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <span>Graduating {user.graduationYear}</span>
                      </div>
                    )}
                    
                    {user.linkedinUrl && (
                      <div className="flex items-center gap-2 text-sm">
                        <Linkedin className="w-4 h-4 text-muted-foreground" />
                        <a 
                          href={user.linkedinUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          LinkedIn Profile
                        </a>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2 text-sm">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span>Joined {new Date(user.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                {isEditing ? (
                  <>
                    <Button size="sm" onClick={handleSave} className="btn-primary">
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleCancel}>
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  </>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                )}
              </div>
            </div>

            {/* Profile Completion */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Profile Completeness</span>
                <span className="text-sm text-muted-foreground">{user.profileCompleteness}%</span>
              </div>
              <Progress value={user.profileCompleteness} className="h-2" />
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Applications</p>
                  <p className="text-2xl font-bold">{user.stats.applicationsSubmitted}</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Mentoring Sessions</p>
                  <p className="text-2xl font-bold">{user.stats.mentoringSessions}</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Download className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Resources</p>
                  <p className="text-2xl font-bold">{user.stats.resourcesDownloaded}</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Certificates</p>
                  <p className="text-2xl font-bold">{user.stats.certificatesEarned}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-16 flex-col">
                <Target className="w-5 h-5 mb-2" />
                <span>Update Goals</span>
              </Button>
              <Button variant="outline" className="h-16 flex-col">
                <Zap className="w-5 h-5 mb-2" />
                <span>Share Profile</span>
              </Button>
              <Button variant="outline" className="h-16 flex-col">
                <TrendingUp className="w-5 h-5 mb-2" />
                <span>View Analytics</span>
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-6">
          {isEditing ? (
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Edit Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="university">University</Label>
                  <Input
                    id="university"
                    placeholder="Your university"
                    value={editData.university}
                    onChange={(e) => setEditData({ ...editData, university: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="major">Major</Label>
                  <Input
                    id="major"
                    placeholder="Your major"
                    value={editData.major}
                    onChange={(e) => setEditData({ ...editData, major: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="graduationYear">Graduation Year</Label>
                  <Input
                    id="graduationYear"
                    placeholder="e.g., 2025"
                    value={editData.graduationYear}
                    onChange={(e) => setEditData({ ...editData, graduationYear: e.target.value })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
                  <Input
                    id="linkedinUrl"
                    placeholder="https://linkedin.com/in/yourprofile"
                    value={editData.linkedinUrl}
                    onChange={(e) => setEditData({ ...editData, linkedinUrl: e.target.value })}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="interests">Interests (comma-separated)</Label>
                  <Input
                    id="interests"
                    placeholder="AI, Fintech, Sustainability, etc."
                    value={editData.interests}
                    onChange={(e) => setEditData({ ...editData, interests: e.target.value })}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="skills">Skills (comma-separated)</Label>
                  <Input
                    id="skills"
                    placeholder="React, Python, Marketing, etc."
                    value={editData.skills}
                    onChange={(e) => setEditData({ ...editData, skills: e.target.value })}
                  />
                </div>
                
                <div className="md:col-span-2">
                  <Label htmlFor="startupExperience">Startup Experience</Label>
                  <Textarea
                    id="startupExperience"
                    placeholder="Describe your entrepreneurial experience..."
                    value={editData.startupExperience}
                    onChange={(e) => setEditData({ ...editData, startupExperience: e.target.value })}
                    rows={3}
                  />
                </div>
              </div>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Interests */}
              <Card className="p-6">
                <h3 className="font-semibold mb-4">Interests</h3>
                {user.interests && user.interests.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {user.interests.map((interest, index) => (
                      <Badge key={index} variant="outline">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No interests added yet.</p>
                )}
              </Card>

              {/* Skills */}
              <Card className="p-6">
                <h3 className="font-semibold mb-4">Skills</h3>
                {user.skills && user.skills.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {user.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No skills added yet.</p>
                )}
              </Card>

              {/* Startup Experience */}
              <Card className="p-6 md:col-span-2">
                <h3 className="font-semibold mb-4">Startup Experience</h3>
                {user.startupExperience ? (
                  <p className="text-muted-foreground">{user.startupExperience}</p>
                ) : (
                  <p className="text-muted-foreground">No startup experience added yet.</p>
                )}
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="achievements" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {achievements.map((achievement) => (
              <Card key={achievement.id} className={`p-6 ${achievement.earned ? 'border-primary' : 'opacity-60'}`}>
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    achievement.earned ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                  }`}>
                    <Award className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground mb-2">{achievement.description}</p>
                    {achievement.earned && achievement.date && (
                      <Badge variant="outline" className="text-xs">
                        Earned {new Date(achievement.date).toLocaleDateString()}
                      </Badge>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Recent Activity</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <Target className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Applied to TechStars Accelerator</p>
                  <p className="text-sm text-muted-foreground">2 days ago</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <Users className="w-4 h-4 text-green-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Completed mentoring session with Sarah Chen</p>
                  <p className="text-sm text-muted-foreground">1 week ago</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                  <Download className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Downloaded Pitch Deck Template</p>
                  <p className="text-sm text-muted-foreground">2 weeks ago</p>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}