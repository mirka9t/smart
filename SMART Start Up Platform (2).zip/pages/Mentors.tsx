import React, { useState, useEffect } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { loadMentors } from '../utils/dataLoader';
import { useModal } from '../components/modals/ModalSystem';
import { 
  notifications, 
  mentorNotifications, 
  generalNotifications, 
  showSuccess 
} from '../utils/notifications';
import { MapPin, Linkedin, Calendar, MessageCircle, Search, Filter, Star, Users, Award, Bookmark, BookmarkCheck, Heart, ExternalLink } from 'lucide-react';

interface Mentor {
  id: string;
  name: string;
  title: string;
  company: string;
  expertise: string[];
  bio: string;
  location: string;
  availableFor: string[];
  linkedin: string;
  rating?: number;
  sessionCount?: number;
  responseTime?: string;
  price?: string;
}

// Extended mentor data with additional fallback mentors
const EXTENDED_MENTOR_DATA: Mentor[] = [
  {
    id: "sarah-chen",
    name: "Sarah Chen",
    title: "Former VP Product at Airbnb",
    company: "Airbnb",
    expertise: ["Product Management", "Growth", "User Experience"],
    bio: "Led product growth at Airbnb from 10M to 100M+ users. Passionate about helping student founders build user-centric products.",
    location: "San Francisco, CA",
    availableFor: ["1-on-1 mentoring", "Product reviews", "Growth strategy"],
    linkedin: "https://linkedin.com/in/sarahchen",
    rating: 4.9,
    sessionCount: 150,
    responseTime: "< 2 hours",
    price: "Free for students"
  },
  {
    id: "marcus-johnson",
    name: "Marcus Johnson",
    title: "Founder & CEO",
    company: "TechStars Graduate",
    expertise: ["Fundraising", "B2B Sales", "Team Building"],
    bio: "Founded two successful startups, raised $50M+ in funding. Now helping the next generation of entrepreneurs.",
    location: "New York, NY",
    availableFor: ["Fundraising prep", "Investor intros", "Strategy sessions"],
    linkedin: "https://linkedin.com/in/marcusjohnson",
    rating: 4.8,
    sessionCount: 200,
    responseTime: "< 4 hours",
    price: "Free for students"
  },
  {
    id: "maria-rodriguez",
    name: "Maria Rodriguez",
    title: "Head of Engineering",
    company: "Stripe",
    expertise: ["Technical Leadership", "Engineering", "Scaling Teams"],
    bio: "Led engineering teams from 5 to 200+ engineers. Expert in building scalable products and technical cultures.",
    location: "Austin, TX",
    availableFor: ["Technical reviews", "CTO guidance", "Engineering culture"],
    linkedin: "https://linkedin.com/in/mariarodriguez",
    rating: 4.9,
    sessionCount: 85,
    responseTime: "< 6 hours",
    price: "Free for students"
  },
  {
    id: "david-kim",
    name: "David Kim",
    title: "Partner",
    company: "Bessemer Venture Partners",
    expertise: ["Venture Capital", "Due Diligence", "Market Analysis"],
    bio: "15+ years in venture capital with investments in 50+ startups. Specialized in early-stage SaaS and marketplaces.",
    location: "Boston, MA",
    availableFor: ["Pitch feedback", "Market insights", "Investor prep"],
    linkedin: "https://linkedin.com/in/davidkim",
    rating: 4.7,
    sessionCount: 120,
    responseTime: "< 1 day",
    price: "Free for students"
  },
  {
    id: "alexandra-foster",
    name: "Alexandra Foster",
    title: "CMO",
    company: "HubSpot",
    expertise: ["Marketing", "Brand Building", "Growth Marketing"],
    bio: "Built marketing teams at three unicorn startups. Expert in go-to-market strategy and brand development.",
    location: "Remote",
    availableFor: ["Marketing strategy", "Brand development", "Growth tactics"],
    linkedin: "https://linkedin.com/in/alexandrafoster",
    rating: 4.8,
    sessionCount: 95,
    responseTime: "< 3 hours",
    price: "Free for students"
  },
  {
    id: "james-wilson",
    name: "James Wilson",
    title: "Serial Entrepreneur",
    company: "3x Successful Exits",
    expertise: ["Operations", "Business Strategy", "Exit Planning"],
    bio: "Founded and sold three companies including two to Fortune 500s. Now focusing on mentoring the next generation.",
    location: "Seattle, WA",
    availableFor: ["Business strategy", "Operations", "Exit planning"],
    linkedin: "https://linkedin.com/in/jameswilson",
    rating: 4.9,
    sessionCount: 175,
    responseTime: "< 2 hours",
    price: "Free for students"
  }
];

export function Mentors() {
  const [mentors, setMentors] = useState<Mentor[]>([]);
  const [filteredMentors, setFilteredMentors] = useState<Mentor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExpertise, setSelectedExpertise] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [bookmarkedMentors, setBookmarkedMentors] = useState<Set<string>>(new Set());
  const [likedMentors, setLikedMentors] = useState<Set<string>>(new Set());
  
  const { openModal } = useModal();

  useEffect(() => {
    async function fetchMentors() {
      try {
        const data = await loadMentors();
        const mentorsWithExtras = [...EXTENDED_MENTOR_DATA];
        setMentors(mentorsWithExtras);
        setFilteredMentors(mentorsWithExtras);
        
        // Load saved preferences
        const savedBookmarks = localStorage.getItem('smart-bookmarked-mentors');
        const savedLikes = localStorage.getItem('smart-liked-mentors');
        
        if (savedBookmarks) {
          setBookmarkedMentors(new Set(JSON.parse(savedBookmarks)));
        }
        if (savedLikes) {
          setLikedMentors(new Set(JSON.parse(savedLikes)));
        }
      } catch (error) {
        console.error('Error loading mentors:', error);
        setMentors(EXTENDED_MENTOR_DATA);
        setFilteredMentors(EXTENDED_MENTOR_DATA);
        generalNotifications.error('load mentors');
      } finally {
        setLoading(false);
      }
    }
    
    fetchMentors();
  }, []);

  // Filter mentors based on search and filters
  useEffect(() => {
    let filtered = mentors;

    if (searchTerm) {
      filtered = filtered.filter(mentor =>
        mentor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        mentor.expertise.some(exp => exp.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (selectedExpertise) {
      filtered = filtered.filter(mentor =>
        mentor.expertise.includes(selectedExpertise)
      );
    }

    if (selectedLocation) {
      filtered = filtered.filter(mentor =>
        mentor.location.includes(selectedLocation)
      );
    }

    setFilteredMentors(filtered);
  }, [mentors, searchTerm, selectedExpertise, selectedLocation]);

  // Get unique expertise areas
  const allExpertise = Array.from(new Set(mentors.flatMap(mentor => mentor.expertise)));
  const allLocations = Array.from(new Set(mentors.map(mentor => mentor.location.split(',')[1]?.trim() || mentor.location)));

  const handleBookSession = (mentor: Mentor) => {
    openModal({
      type: 'book-session',
      title: 'Book Session',
      data: { mentorName: mentor.name, mentorId: mentor.id },
      onConfirm: async (formData) => {
        // Simulate booking process
        await new Promise(resolve => setTimeout(resolve, 1500));
        mentorNotifications.booked(mentor.name);
        
        // In a real app, this would make an API call to book the session
        console.log('Booking session:', { mentor: mentor.id, ...formData });
      }
    });
  };

  const handleContactMentor = (mentor: Mentor) => {
    openModal({
      type: 'contact-mentor',
      title: 'Contact Mentor',
      data: { mentorName: mentor.name, mentorId: mentor.id },
      onConfirm: async (formData) => {
        // Simulate sending message
        await new Promise(resolve => setTimeout(resolve, 1000));
        mentorNotifications.contacted(mentor.name);
        
        // In a real app, this would send the message via API
        console.log('Sending message:', { mentor: mentor.id, ...formData });
      }
    });
  };

  const handleViewProfile = (mentor: Mentor) => {
    notifications.info('Profile View', `Opening ${mentor.name}'s full profile...`);
    // In a real app, this would navigate to a detailed mentor profile page
    console.log('Viewing mentor profile:', mentor.id);
  };

  const toggleBookmark = (mentorId: string) => {
    const newBookmarks = new Set(bookmarkedMentors);
    if (newBookmarks.has(mentorId)) {
      newBookmarks.delete(mentorId);
      showSuccess('Bookmark Removed', 'Mentor removed from your bookmarks.');
    } else {
      newBookmarks.add(mentorId);
      showSuccess('Mentor Bookmarked!', 'Mentor added to your bookmarks.');
    }
    
    setBookmarkedMentors(newBookmarks);
    localStorage.setItem('smart-bookmarked-mentors', JSON.stringify(Array.from(newBookmarks)));
  };

  const toggleLike = (mentorId: string) => {
    const newLikes = new Set(likedMentors);
    if (newLikes.has(mentorId)) {
      newLikes.delete(mentorId);
    } else {
      newLikes.add(mentorId);
      showSuccess('Thanks for the feedback!', 'Your appreciation has been noted.');
    }
    
    setLikedMentors(newLikes);
    localStorage.setItem('smart-liked-mentors', JSON.stringify(Array.from(newLikes)));
  };

  const handleApplyToBecomeMentor = () => {
    openModal({
      type: 'apply-mentor',
      title: 'Become a Mentor',
      data: {},
      onConfirm: async (formData) => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        mentorNotifications.applied();
        console.log('Mentor application:', formData);
      }
    });
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedExpertise('');
    setSelectedLocation('');
    showSuccess('Filters Cleared', 'All filters have been reset.');
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading mentors...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1>Expert Mentors</h1>
        <p className="text-lg mb-6">
          Connect with experienced entrepreneurs, investors, and industry leaders who are passionate about helping student founders succeed.
        </p>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search mentors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <select
            className="px-3 py-2 border border-border rounded-md bg-background"
            value={selectedExpertise}
            onChange={(e) => setSelectedExpertise(e.target.value)}
          >
            <option value="">All Expertise</option>
            {allExpertise.map(expertise => (
              <option key={expertise} value={expertise}>{expertise}</option>
            ))}
          </select>

          <select
            className="px-3 py-2 border border-border rounded-md bg-background"
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
          >
            <option value="">All Locations</option>
            {allLocations.map(location => (
              <option key={location} value={location}>{location}</option>
            ))}
          </select>

          <Button variant="outline" className="flex items-center gap-2" onClick={clearAllFilters}>
            <Filter className="w-4 h-4" />
            Clear Filters
          </Button>
        </div>

        {/* Results Summary */}
        <p className="text-muted-foreground">
          Showing {filteredMentors.length} of {mentors.length} mentors
        </p>
      </div>

      {/* Mentors Grid */}
      <div className="smart-grid">
        {filteredMentors.map((mentor) => (
          <Card key={mentor.id} className="smart-card">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center text-primary-foreground font-semibold text-lg">
                {mentor.name.split(' ').map(n => n[0]).join('')}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-1">
                  <h3 className="font-semibold truncate">{mentor.name}</h3>
                  <div className="flex gap-1 ml-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-1 h-8 w-8"
                      onClick={() => toggleBookmark(mentor.id)}
                    >
                      {bookmarkedMentors.has(mentor.id) ? (
                        <BookmarkCheck className="w-4 h-4 text-primary" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-1 h-8 w-8"
                      onClick={() => toggleLike(mentor.id)}
                    >
                      <Heart className={`w-4 h-4 ${likedMentors.has(mentor.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-1">{mentor.title}</p>
                <p className="text-sm font-medium text-primary">{mentor.company}</p>
              </div>
            </div>

            {/* Rating and Stats */}
            <div className="flex items-center gap-4 mb-4 text-sm">
              {mentor.rating && (
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{mentor.rating}</span>
                </div>
              )}
              {mentor.sessionCount && (
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span>{mentor.sessionCount} sessions</span>
                </div>
              )}
              {mentor.responseTime && (
                <div className="flex items-center gap-1">
                  <MessageCircle className="w-4 h-4 text-muted-foreground" />
                  <span>{mentor.responseTime}</span>
                </div>
              )}
            </div>

            <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
              {mentor.bio}
            </p>

            {/* Expertise Tags */}
            <div className="flex flex-wrap gap-2 mb-4">
              {mentor.expertise.slice(0, 3).map((exp) => (
                <Badge key={exp} variant="outline" className="text-xs">
                  {exp}
                </Badge>
              ))}
              {mentor.expertise.length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{mentor.expertise.length - 3} more
                </Badge>
              )}
            </div>

            {/* Available For */}
            <div className="mb-4">
              <p className="text-sm font-medium mb-2">Available for:</p>
              <div className="space-y-1">
                {mentor.availableFor.slice(0, 2).map((service) => (
                  <div key={service} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Award className="w-3 h-3" />
                    {service}
                  </div>
                ))}
              </div>
            </div>

            {/* Location and Price */}
            <div className="flex items-center justify-between text-sm mb-4">
              <div className="flex items-center gap-1 text-muted-foreground">
                <MapPin className="w-3 h-3" />
                {mentor.location}
              </div>
              {mentor.price && (
                <span className="font-medium text-green-600">{mentor.price}</span>
              )}
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button 
                className="flex-1 btn-primary"
                onClick={() => handleBookSession(mentor)}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Book Session
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleContactMentor(mentor)}
              >
                <MessageCircle className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.open(mentor.linkedin, '_blank')}
              >
                <Linkedin className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => handleViewProfile(mentor)}
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredMentors.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No mentors found</h3>
          <p className="text-muted-foreground mb-4">
            Try adjusting your search criteria or clearing filters.
          </p>
          <Button 
            variant="outline"
            onClick={clearAllFilters}
          >
            Clear All Filters
          </Button>
        </div>
      )}

      {/* Become a Mentor CTA */}
      <div className="mt-12 smart-card bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <div className="text-center">
          <h3 className="mb-2">Want to become a mentor?</h3>
          <p className="text-muted-foreground mb-4">
            Share your expertise and help the next generation of student entrepreneurs.
          </p>
          <Button className="btn-primary" onClick={handleApplyToBecomeMentor}>
            Apply to be a Mentor
          </Button>
        </div>
      </div>
    </div>
  );
}