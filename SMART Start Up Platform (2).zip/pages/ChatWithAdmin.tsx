import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Textarea } from '../components/ui/textarea';
import { useAuth } from '../contexts/AuthContext';
import { chatManager, type ChatMessage } from '../utils/chatUtils';
import { telegramBot, formatUserForTelegram } from '../utils/telegramBot';
import { notifications } from '../utils/notifications';
import { InlineLoading } from '../components/ui/Loading';
import {
  Send,
  MessageCircle,
  CheckCircle2,
  Circle,
  Clock,
  Settings,
  Paperclip,
  Image,
  Smile,
  Mic,
  MicOff,
  Play,
  Pause,
  Download,
  Reply,
  Copy,
  Heart,
  ThumbsUp,
  Laugh,
  Angry,
  Frown,
  Zap,
  AlertCircle,
  Shield,
  Phone,
  Video
} from 'lucide-react';
import smartLogo from 'figma:asset/1b53314fceb43ebca3d39c2903c7383e19f927a5.png';

interface EmojiReaction {
  emoji: string;
  label: string;
  icon: any;
}

const reactions: EmojiReaction[] = [
  { emoji: '❤️', label: 'Love', icon: Heart },
  { emoji: '👍', label: 'Like', icon: ThumbsUp },
  { emoji: '😂', label: 'Laugh', icon: Laugh },
  { emoji: '😢', label: 'Sad', icon: Frown },
  { emoji: '😠', label: 'Angry', icon: Angry },
  { emoji: '⚡', label: 'Wow', icon: Zap }
];

export function ChatWithAdmin() {
  const { user, trackAction } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<string | null>(null);
  const [replyToMessage, setReplyToMessage] = useState<ChatMessage | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLTextAreaElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Admin user ID for direct messaging
  const ADMIN_USER_ID = 'admin-1';

  useEffect(() => {
    loadAdminChat();
    
    // Track page view
    if (user) {
      trackAction('page_view', { page: 'Chat with Admin', path: '/chat-admin' });
    }
  }, [user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadAdminChat = async () => {
    try {
      if (!user) return;
      
      // Load conversation with admin
      const adminMessages = chatManager.getConversationMessages(user.id, ADMIN_USER_ID);
      setMessages(adminMessages);
      
      // Mark messages from admin as read
      chatManager.markMessagesAsRead(user.id, ADMIN_USER_ID);
    } catch (error) {
      console.error('Error loading admin chat:', error);
      notifications.error('Error', 'Failed to load chat with admin');
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user) return;

    try {
      setLoading(true);
      
      const message = await chatManager.sendMessage(
        user.id,
        user.name,
        user.email,
        user.role,
        newMessage.trim(),
        ADMIN_USER_ID,
        undefined,
        'text',
        undefined,
        replyToMessage?.id
      );

      setMessages(prev => [...prev, message]);
      setNewMessage('');
      setReplyToMessage(null);
      
      // Track action
      await trackAction('admin_message_sent', {
        messageLength: newMessage.length,
        hasReply: !!replyToMessage
      });

      // Send Telegram notification to admin
      await telegramBot.trackChatMessage(
        formatUserForTelegram(user),
        newMessage.trim(),
        'Admin'
      );

      notifications.success('Message sent', 'Your message has been sent to the admin');
    } catch (error) {
      console.error('Error sending message:', error);
      notifications.error('Error', 'Failed to send message');
    } finally {
      setLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        await sendVoiceMessage(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      notifications.info('Recording', 'Voice message recording started');
    } catch (error) {
      console.error('Error starting recording:', error);
      notifications.error('Error', 'Failed to start voice recording');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const sendVoiceMessage = async (audioBlob: Blob) => {
    if (!user) return;

    try {
      // Convert blob to base64 for storage
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Audio = reader.result as string;
        
        const voiceMessage = await chatManager.sendMessage(
          user.id,
          user.name,
          user.email,
          user.role,
          '🎤 Voice message',
          ADMIN_USER_ID,
          undefined,
          'audio',
          [{
            type: 'audio',
            url: base64Audio,
            name: `voice-${Date.now()}.wav`,
            size: audioBlob.size
          }]
        );

        setMessages(prev => [...prev, voiceMessage]);
        
        await trackAction('voice_message_sent', {
          duration: Math.round(audioBlob.size / 1000), // approximate duration
          recipient: 'admin'
        });

        notifications.success('Voice message sent', 'Your voice message has been sent to the admin');
      };
      
      reader.readAsDataURL(audioBlob);
    } catch (error) {
      console.error('Error sending voice message:', error);
      notifications.error('Error', 'Failed to send voice message');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    // Check file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      notifications.error('File too large', 'Please select a file smaller than 10MB');
      return;
    }

    try {
      setLoading(true);
      
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64File = reader.result as string;
        const fileType = file.type.startsWith('image/') ? 'image' : 'file';
        
        const fileMessage = await chatManager.sendMessage(
          user.id,
          user.name,
          user.email,
          user.role,
          fileType === 'image' ? '📷 Image attachment' : `📎 ${file.name}`,
          ADMIN_USER_ID,
          undefined,
          fileType,
          [{
            type: fileType,
            url: base64File,
            name: file.name,
            size: file.size
          }]
        );

        setMessages(prev => [...prev, fileMessage]);
        
        await trackAction('file_sent_to_admin', {
          fileType,
          fileName: file.name,
          fileSize: file.size
        });

        notifications.success('File sent', 'Your file has been sent to the admin');
      };
      
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading file:', error);
      notifications.error('Error', 'Failed to upload file');
    } finally {
      setLoading(false);
    }
  };

  const handleReaction = async (messageId: string, emoji: string) => {
    try {
      // Add reaction to message (simplified implementation)
      const updatedMessages = messages.map(msg => {
        if (msg.id === messageId) {
          const existingReactions = msg.reactions || [];
          const userReaction = existingReactions.find(r => r.userId === user?.id);
          
          if (userReaction) {
            // Update existing reaction
            userReaction.emoji = emoji;
          } else {
            // Add new reaction
            existingReactions.push({
              emoji,
              userId: user?.id || '',
              timestamp: new Date().toISOString()
            });
          }
          
          return { ...msg, reactions: existingReactions };
        }
        return msg;
      });
      
      setMessages(updatedMessages);
      notifications.success('Reaction added', 'Your reaction has been recorded');
    } catch (error) {
      console.error('Error adding reaction:', error);
      notifications.error('Error', 'Failed to add reaction');
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Shield className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h2 className="text-2xl font-semibold mb-2">Access Required</h2>
          <p className="text-muted-foreground">Please sign in to chat with admin</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto h-screen flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border bg-muted/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold flex items-center space-x-2">
                  <span>Chat with Admin</span>
                  <Badge variant="outline" className="text-xs">
                    Direct Support
                  </Badge>
                </h1>
                <p className="text-muted-foreground">
                  Get help and support from the SMART Admin team
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Phone className="w-4 h-4 mr-2" />
                Schedule Call
              </Button>
              <Button variant="outline" size="sm">
                <Video className="w-4 h-4 mr-2" />
                Video Chat
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center max-w-md">
                <img src={smartLogo} alt="SMART" className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">Welcome to Admin Support</h3>
                <p className="text-muted-foreground mb-6">
                  This is your direct line to the SMART Admin team. We're here to help with any questions,
                  technical issues, or guidance you need for your startup journey.
                </p>
                <div className="grid grid-cols-1 gap-3 text-sm">
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span>24/7 support available</span>
                  </div>
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span>Voice messages and file sharing</span>
                  </div>
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <CheckCircle2 className="w-4 h-4 text-green-500" />
                    <span>Direct connection to admin team</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <AnimatePresence initial={false}>
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className={`flex ${message.fromUserId === user.id ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-xs lg:max-w-md ${message.fromUserId === user.id ? 'order-2' : 'order-1'}`}>
                    {/* Message bubble */}
                    <div
                      className={`relative rounded-2xl px-4 py-3 cursor-pointer group ${
                        message.fromUserId === user.id 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted text-foreground border border-border'
                      }`}
                      onClick={() => setSelectedMessage(
                        selectedMessage === message.id ? null : message.id
                      )}
                    >
                      {/* Reply indicator */}
                      {message.replyToId && (
                        <div className="text-xs opacity-70 mb-2 border-l-2 border-current pl-2">
                          Replying to message
                        </div>
                      )}

                      {/* Message content */}
                      {message.messageType === 'text' && (
                        <p className="text-sm break-words">{message.message}</p>
                      )}

                      {/* Voice message */}
                      {message.messageType === 'audio' && message.attachments?.[0] && (
                        <div className="flex items-center space-x-3">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-8 h-8 p-0 rounded-full"
                          >
                            <Play className="w-4 h-4" />
                          </Button>
                          <div className="flex-1">
                            <div className="w-32 h-1 bg-current opacity-30 rounded" />
                            <p className="text-xs opacity-70 mt-1">Voice message</p>
                          </div>
                        </div>
                      )}

                      {/* Image attachment */}
                      {message.messageType === 'image' && message.attachments?.[0] && (
                        <div className="space-y-2">
                          <img 
                            src={message.attachments[0].url} 
                            alt="Shared image"
                            className="max-w-full h-auto rounded-lg"
                          />
                          {message.message !== '📷 Image attachment' && (
                            <p className="text-sm">{message.message}</p>
                          )}
                        </div>
                      )}

                      {/* File attachment */}
                      {message.messageType === 'file' && message.attachments?.[0] && (
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-lg bg-current/20 flex items-center justify-center">
                            <Paperclip className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">
                              {message.attachments[0].name}
                            </p>
                            <p className="text-xs opacity-70">
                              {Math.round(message.attachments[0].size / 1024)} KB
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-8 h-8 p-0"
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-end mt-2 space-x-1">
                        <span className={`text-xs ${
                          message.fromUserId === user.id 
                            ? 'text-primary-foreground/70' 
                            : 'text-muted-foreground'
                        }`}>
                          {formatTime(message.timestamp)}
                        </span>
                        {message.fromUserId === user.id && (
                          <>
                            {message.isRead ? (
                              <CheckCircle2 className="w-3 h-3" />
                            ) : (
                              <Circle className="w-3 h-3" />
                            )}
                          </>
                        )}
                      </div>

                      {/* Message actions */}
                      {selectedMessage === message.id && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="absolute -top-12 left-0 right-0 flex justify-center"
                        >
                          <div className="bg-popover border border-border rounded-lg shadow-lg p-1 flex space-x-1">
                            {reactions.map((reaction) => (
                              <Button
                                key={reaction.emoji}
                                variant="ghost"
                                size="sm"
                                className="w-8 h-8 p-0"
                                onClick={() => handleReaction(message.id, reaction.emoji)}
                              >
                                <span className="text-sm">{reaction.emoji}</span>
                              </Button>
                            ))}
                            <div className="border-l border-border mx-1" />
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-8 h-8 p-0"
                              onClick={() => setReplyToMessage(message)}
                            >
                              <Reply className="w-3 h-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-8 h-8 p-0"
                              onClick={() => {
                                navigator.clipboard.writeText(message.message);
                                notifications.success('Copied', 'Message copied to clipboard');
                              }}
                            >
                              <Copy className="w-3 h-3" />
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* Reactions */}
                    {message.reactions && message.reactions.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {message.reactions.map((reaction, index) => (
                          <Button
                            key={index}
                            variant="outline"
                            size="sm"
                            className="h-6 px-2 text-xs"
                            onClick={() => handleReaction(message.id, reaction.emoji)}
                          >
                            {reaction.emoji} 1
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Avatar for admin messages */}
                  {message.fromUserId !== user.id && (
                    <Avatar className="h-8 w-8 mr-2 order-2">
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        <Shield className="w-4 h-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Reply Preview */}
        {replyToMessage && (
          <div className="px-6 py-3 bg-muted/30 border-t border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Reply className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  Replying to {replyToMessage.fromUserName}
                </span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setReplyToMessage(null)}
              >
                <AlertCircle className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-sm bg-muted rounded px-2 py-1 mt-1 truncate">
              {replyToMessage.message}
            </p>
          </div>
        )}

        {/* Message Input */}
        <div className="p-6 border-t border-border bg-muted/30">
          <div className="flex items-end space-x-3">
            <div className="flex-1">
              <Textarea
                ref={messageInputRef}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Type your message to admin..."
                className="min-h-[50px] max-h-32 resize-none"
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2">
              {/* File upload */}
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={handleFileUpload}
                accept="image/*,.pdf,.doc,.docx,.txt"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                <Paperclip className="w-4 h-4" />
              </Button>

              {/* Image upload */}
              <input
                type="file"
                id="image-upload"
                className="hidden"
                onChange={handleFileUpload}
                accept="image/*"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => document.getElementById('image-upload')?.click()}
              >
                <Image className="w-4 h-4" />
              </Button>

              {/* Voice recording */}
              <Button
                variant="ghost"
                size="sm"
                onMouseDown={startRecording}
                onMouseUp={stopRecording}
                onMouseLeave={stopRecording}
                className={isRecording ? 'bg-destructive text-destructive-foreground' : ''}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>

              {/* Emoji picker */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              >
                <Smile className="w-4 h-4" />
              </Button>

              {/* Send button */}
              <Button 
                onClick={handleSendMessage}
                disabled={!newMessage.trim() || loading}
                className="btn-primary"
              >
                {loading ? (
                  <InlineLoading />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>

          {isRecording && (
            <div className="mt-3 p-3 bg-destructive/10 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-destructive rounded-full animate-pulse" />
                <span className="text-sm text-destructive font-medium">
                  Recording voice message... (Hold to record, release to send)
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ChatWithAdmin;